"use strict";
// 바로보기 웹 번역 팝업(Chrome·Whale 공통): 번역 시작/원문 보기, 언어·OCR 언어·글꼴·이미지/페이지 글자 설정,
// 번역 엔진 창 열기(두 브라우저 공통), Chrome에서는 사이드패널로 열기도 제공한다.
// 번역 대상 탭은 팝업을 연 창의 활성 웹 탭으로 고정한다(엔진 창을 열어도 바뀌지 않음).
const $ = (id) => document.getElementById(id);
const ALL_URLS = "<all_urls>";
let tabId = null;
let origin = null;

function showError(message) {
  $("error").textContent = message || "";
  $("error").hidden = !message;
}

async function call(message) {
  const response = await chrome.runtime.sendMessage({ ...message, tabId });
  if (!response || response.ok !== true) throw new Error(response?.message || "요청을 처리하지 못했습니다.");
  return response;
}

function render(state) {
  const engine = $("engine");
  const model = state.engine?.model;
  if (!state.engine || !state.engine.connected) {
    engine.textContent = "엔진 꺼짐";
    engine.className = "pill bad";
  } else if (state.engine.error) {
    engine.textContent = "엔진 응답 없음";
    engine.className = "pill bad";
  } else if (model && model.cache !== "complete") {
    engine.textContent = model.download === "running" ? `모델 받는 중 ${Math.floor((model.done / model.total) * 100)}%` : "모델 필요";
    engine.className = "pill bad";
  } else if (model && model.runtime === "loading") {
    engine.textContent = "모델 불러오는 중";
    engine.className = "pill";
  } else if (model && model.runtime === "ready") {
    engine.textContent = "엔진 준비됨";
    engine.className = "pill ok";
  } else {
    engine.textContent = "엔진 켜짐";
    engine.className = "pill";
  }
  $("target").value = state.settings.target;
  $("source").value = state.settings.source;
  $("ocrLang").value = state.settings.ocrLang;
  $("pageText").checked = state.settings.pageText === true;
  $("fontStyle").value = state.settings.fontStyle;
  $("images").checked = state.settings.images !== false;
  $("autoAll").checked = state.settings.automaticEnabled === true;
  $("translate").disabled = tabId === null;
  const isTranslated = state.page?.view === "translated";
  $("translate").classList.toggle("active", isTranslated);
  $("original").classList.toggle("active", !isTranslated && !!state.page);
  const running = state.page?.running === true;
  $("spinner").hidden = !running;
  $("translateSpinner").hidden = !running;
  let status = "";
  if (state.page) {
    status = state.page.error || state.page.warning || state.page.status || "";
  } else if (!origin) {
    status = "이 페이지는 번역할 수 없습니다.";
  } else if (!state.engine?.connected) {
    status = "'번역 엔진 창 열기'로 엔진을 먼저 켜 주세요.";
  } else if (model && model.cache !== "complete") {
    status = "번역 엔진 창에서 로컬 번역 모델(약 640MB)을 먼저 내려받아 주세요.";
  }
  $("statusText").textContent = status;
  const inventory = state.page?.inventory;
  const parts = [];
  if (Number.isInteger(inventory?.textSentences)) parts.push(`일반 ${inventory.textSentences}문장`);
  if (Number.isInteger(inventory?.imageSentences)) parts.push(`이미지 속 ${inventory.imageSentences}문장`);
  $("summary").textContent = parts.join(" · ");
  $("summary").hidden = parts.length === 0;
  if (running) setTimeout(refresh, 1200);
}

async function refresh() {
  try {
    const response = await call({ cmd: "popupState" });
    render(response);
  } catch (error) {
    showError(error.message);
  }
}

$("target").addEventListener("change", async (event) => {
  await call({ cmd: "setTarget", target: event.target.value }).catch((e) => showError(e.message));
  refresh();
});

$("source").addEventListener("change", async (event) => {
  await call({ cmd: "setSource", source: event.target.value }).catch((e) => showError(e.message));
  refresh();
});

$("ocrLang").addEventListener("change", async (event) => {
  await call({ cmd: "setOcrLang", ocrLang: event.target.value }).catch((e) => showError(e.message));
  refresh();
});

$("pageText").addEventListener("change", async (event) => {
  await call({ cmd: "setPageText", pageText: event.target.checked }).catch((e) => showError(e.message));
  refresh();
});

$("fontStyle").addEventListener("change", async (event) => {
  await call({ cmd: "setFontStyle", fontStyle: event.target.value }).catch((e) => showError(e.message));
  refresh();
});

$("images").addEventListener("change", async (event) => {
  await call({ cmd: "setImages", images: event.target.checked }).catch((e) => showError(e.message));
  refresh();
});

$("autoAll").addEventListener("change", async (event) => {
  const want = event.target.checked;
  showError("");
  if (!want) {
    await call({ cmd: "toggleOriginal" }).catch((e) => showError(e.message));
    refresh();
    return;
  }
  let granted = false;
  try { granted = await chrome.permissions.request({ origins: [ALL_URLS] }); } catch { granted = false; }
  if (!granted) {
    event.target.checked = false;
    showError("모든 웹사이트 접근을 허용해야 자동 번역을 켤 수 있습니다.");
    return;
  }
  try {
    await call({ cmd: "translateNow", automatic: true, trigger: "button", clickedAt: Date.now() });
  } catch (error) {
    showError(error.message);
  }
  refresh();
});

$("translate").addEventListener("click", async () => {
  showError("");
  $("translate").disabled = true;
  try {
    await call({ cmd: "translateNow", automatic: false, tabOnly: true, trigger: "button", clickedAt: Date.now() });
  } catch (error) {
    showError(error.message);
  } finally {
    $("translate").disabled = false;
    refresh();
  }
});

$("original").addEventListener("click", async () => {
  showError("");
  try { await call({ cmd: "toggleOriginal" }); } catch (error) { showError(error.message); }
  refresh();
});

$("openEngine").addEventListener("click", async () => {
  showError("");
  try {
    await call({ cmd: "openEngine" });
    window.close();
  } catch (error) {
    showError(error.message);
  }
});

// Chrome 패키지에만 sidePanel 권한이 있다(Whale 패키지에는 없음). 사용자 클릭 직후 await 없이 바로 부른다.
if (chrome.sidePanel && typeof chrome.sidePanel.open === "function") {
  $("openSidePanel").hidden = false;
  $("openSidePanel").addEventListener("click", () => {
    if (tabId === null) return;
    chrome.sidePanel.open({ tabId }).then(() => window.close(), (error) => showError(error.message));
  });
}

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = Number.isInteger(tab?.id) ? tab.id : null;
  try {
    const url = new URL(tab?.url || "");
    origin = url.protocol === "http:" || url.protocol === "https:" ? url.origin : null;
  } catch {
    origin = null;
  }
  refresh();
})();
