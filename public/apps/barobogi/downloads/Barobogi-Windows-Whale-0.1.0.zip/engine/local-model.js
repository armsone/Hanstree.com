"use strict";
// 바로보기 웹 번역 — 공통 로컬 번역 엔진 제어(엔진 문서 전용, Chrome·Whale 공통).
// - 다운로드: download-worker.js(전용 Worker)가 고정 파일만 받아 검증 후 Cache API에 둔다. 취소는 Worker terminate.
// - 실행: model-worker.js(전용 module Worker)가 Transformers.js + ONNX Runtime Web(WASM, 단일 스레드)로 M2M100을 돌린다.
//   UI 스레드는 막히지 않고, 멈추면(토큰이 오래 나오지 않으면) Worker를 끝내고 새로 만들 수 있다.
// - 번역할 글자는 Worker 메시지로만 오가며 저장하지 않는다(이 문서 메모리 안의 짧은 결과 캐시만, 문서를 닫으면 사라짐).

const MODEL = globalThis.BAROBOGI_MODEL;
const MODEL_TOTAL = globalThis.BAROBOGI_MODEL_TOTAL;
const STALL_MS = 120000;       // 한 조각 번역 중 새 토큰이 이만큼 없으면 멈춘 것으로 보고 Worker를 다시 만든다
const LOAD_STALL_MS = 600000;  // 모델 불러오기(WASM 세션 생성) 중 진행 신호가 이만큼 없으면 실패로 본다
const MAX_CHUNK = 300;         // 한 번에 모델에 넣는 원문 글자 수 상한(문장 경계 우선)
const RESULT_CACHE_LIMIT = 2000;

const listeners = new Set();
const model = {
  cache: "unknown",   // unknown|checking|missing|partial|complete|error
  cachedBytes: 0,
  download: "idle",   // idle|running|failed|cancelled|done
  downloadDone: 0,
  downloadError: "",
  runtime: "idle",    // idle|loading|ready|error
  runtimeError: "",
  loadFile: "",
  loadLoaded: null,
  loadTotal: null
};

function emit() { for (const fn of listeners) { try { fn(snapshot()); } catch { /* UI 오류 무시 */ } } }
function snapshot() { return { ...model, total: MODEL_TOTAL }; }
function onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }

// MARK: 캐시 상태(네트워크 요청 없음)

async function checkCache() {
  model.cache = "checking";
  emit();
  try {
    const cache = await caches.open(MODEL.cacheName);
    const ready = await cache.match(globalThis.BAROBOGI_MODEL_READY_URL);
    let bytes = 0;
    for (const file of MODEL.files) {
      const url = globalThis.BAROBOGI_MODEL_URL(file.path);
      const [entry, mark] = await Promise.all([cache.match(url), cache.match(url + globalThis.BAROBOGI_VERIFIED_SUFFIX)]);
      if (entry && mark) bytes += file.size;
    }
    model.cachedBytes = bytes;
    model.cache = ready && bytes === MODEL_TOTAL ? "complete" : bytes > 0 ? "partial" : "missing";
  } catch (error) {
    model.cache = "error";
    model.downloadError = String((error && error.message) || error);
  }
  emit();
  return model.cache;
}

async function deleteCache() {
  terminateModel("모델 캐시를 지웠습니다.");
  cancelDownload();
  await caches.delete(MODEL.cacheName).catch(() => false);
  model.download = "idle";
  model.downloadDone = 0;
  model.downloadError = "";
  model.runtime = "idle";
  model.runtimeError = "";
  await checkCache();
}

// MARK: 다운로드

let downloadWorker = null;
let downloadPromise = null;

/** 사용자 클릭에서 부른다. 이미 받은(검증된) 파일은 건너뛴다. */
function startDownload() {
  if (downloadPromise) return downloadPromise;
  model.download = "running";
  model.downloadError = "";
  model.downloadDone = model.cachedBytes;
  emit();
  downloadPromise = new Promise((resolve) => {
    const worker = new Worker(chrome.runtime.getURL("engine/download-worker.js"));
    downloadWorker = worker;
    const finish = (state, error = "") => {
      if (downloadWorker === worker) downloadWorker = null;
      worker.terminate();
      model.download = state;
      model.downloadError = error;
      downloadPromise = null;
      emit();
      checkCache().then(() => resolve(model.download));
    };
    worker.onmessage = (event) => {
      const message = event.data || {};
      if (message.type === "progress") {
        model.downloadDone = Number(message.done) || 0;
        emit();
      } else if (message.type === "done") {
        model.downloadDone = MODEL_TOTAL;
        finish("done");
      } else if (message.type === "error") {
        finish("failed", String(message.message || "내려받지 못했습니다."));
      }
    };
    worker.onerror = (event) => finish("failed", event.message || "다운로드 Worker 오류");
    worker._finish = finish;
    worker.postMessage({ type: "start" });
  });
  return downloadPromise;
}

function cancelDownload() {
  const worker = downloadWorker;
  if (!worker) return;
  worker._finish("cancelled", "사용자가 취소했습니다. 다시 받으면 검증을 마친 파일은 건너뜁니다.");
}

// MARK: 모델 Worker

let modelWorker = null;
let loadPromise = null;
let jobSeq = 0;
const jobs = new Map(); // jobId → { resolve, reject, timer, onTokens }

function terminateModel(reason) {
  const worker = modelWorker;
  modelWorker = null;
  loadPromise = null;
  const pendingLoad = worker && worker._load;
  if (worker) { worker._load = null; worker.terminate(); }
  if (pendingLoad) pendingLoad({ type: "terminated", message: reason || "번역 Worker를 다시 시작했습니다." });
  for (const [id, job] of jobs) {
    clearTimeout(job.timer);
    job.reject(Object.assign(new Error(reason || "번역 Worker를 다시 시작했습니다."), { code: "engine_restarted" }));
    jobs.delete(id);
  }
  if (model.runtime !== "error") model.runtime = "idle";
  model.loadFile = "";
  model.loadLoaded = null;
  model.loadTotal = null;
  emit();
}

function ensureWorker() {
  if (modelWorker) return modelWorker;
  const worker = new Worker(chrome.runtime.getURL("engine/model-worker.js"), { type: "module" });
  modelWorker = worker;
  worker.onmessage = (event) => {
    if (modelWorker !== worker) return;
    const message = event.data || {};
    if (message.type === "tokens" || message.type === "result" || message.type === "error") {
      const job = jobs.get(message.jobId);
      if (!job) return;
      if (message.type === "tokens") { job.touch(); job.onTokens?.(message.count); return; }
      clearTimeout(job.timer);
      jobs.delete(message.jobId);
      if (message.type === "result") job.resolve(String(message.text || ""));
      else job.reject(Object.assign(new Error(message.message || "번역하지 못했습니다."), { code: message.code || "translate_failed" }));
    } else if (worker._load) {
      worker._load(message);
    }
  };
  worker.onerror = (event) => {
    if (modelWorker !== worker) return;
    model.runtime = "error";
    model.runtimeError = event.message || "번역 Worker 오류";
    if (worker._load) {
      const pendingLoad = worker._load;
      worker._load = null;
      pendingLoad({ type: "loadError", code: "load_failed", message: model.runtimeError });
    }
    terminateModel(model.runtimeError);
  };
  return worker;
}

/** 캐시가 완료된 경우에만 모델을 불러온다(네트워크 요청 없음). 진행 신호(파일별 읽은 바이트·세션 생성 단계)를 그대로 보여 준다. */
function loadModel() {
  if (model.runtime === "ready" && modelWorker) return Promise.resolve();
  if (loadPromise) return loadPromise;
  if (model.cache !== "complete") {
    return Promise.reject(Object.assign(new Error("로컬 번역 모델을 아직 내려받지 않았습니다."), { code: "model_missing" }));
  }
  const worker = ensureWorker();
  model.runtime = "loading";
  model.runtimeError = "";
  emit();
  loadPromise = new Promise((resolve, reject) => {
    let timer = 0;
    const arm = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        worker._load = null;
        model.runtime = "error";
        model.runtimeError = "모델을 불러오는 중 진행 신호가 10분 동안 없어 중단했습니다.";
        terminateModel(model.runtimeError);
        reject(Object.assign(new Error(model.runtimeError), { code: "load_stalled" }));
      }, LOAD_STALL_MS);
    };
    arm();
    worker._load = (message) => {
      if (message.type === "loadProgress") {
        arm();
        model.loadFile = message.file || model.loadFile;
        model.loadLoaded = message.loaded;
        model.loadTotal = message.total;
        emit();
      } else if (message.type === "loaded") {
        clearTimeout(timer);
        worker._load = null;
        model.runtime = "ready";
        model.loadFile = "";
        emit();
        resolve();
      } else if (message.type === "terminated") {
        clearTimeout(timer);
        reject(Object.assign(new Error(message.message), { code: "engine_restarted" }));
      } else if (message.type === "loadError") {
        clearTimeout(timer);
        worker._load = null;
        model.runtime = "error";
        model.runtimeError = message.message || "모델을 불러오지 못했습니다.";
        terminateModel(model.runtimeError);
        model.runtime = "error";
        emit();
        reject(Object.assign(new Error(model.runtimeError), { code: message.code || "load_failed" }));
      }
    };
    worker.postMessage({ type: "load" });
  });
  loadPromise.catch(() => {});
  return loadPromise;
}

function runChunk(text, src, tgt, onTokens) {
  const worker = modelWorker;
  if (!worker || model.runtime !== "ready") {
    return Promise.reject(Object.assign(new Error("모델이 준비되지 않았습니다."), { code: "model_not_ready" }));
  }
  const jobId = `j${++jobSeq}`;
  const maxNewTokens = Math.max(32, Math.min(256, 16 + Math.ceil(text.length * 2.5)));
  return new Promise((resolve, reject) => {
    const job = { resolve, reject, onTokens, timer: 0 };
    job.touch = () => {
      clearTimeout(job.timer);
      job.timer = setTimeout(() => {
        // 토큰이 오래 나오지 않으면 WASM 계산이 멈췄거나 매우 느린 것이다: Worker를 다시 만들어 대기열을 풀어 준다.
        terminateModel("번역 조각 처리 중 2분 동안 진행이 없어 번역 Worker를 다시 시작했습니다.");
      }, STALL_MS);
    };
    job.touch();
    jobs.set(jobId, job);
    worker.postMessage({ type: "translate", jobId, text, src, tgt, maxNewTokens });
  });
}

// MARK: 문장 나누기·조각 번역

/** 긴 원문을 문장 경계(。．！？.!? 줄바꿈)에서 MAX_CHUNK 이하 조각으로 나눈다. 경계가 없으면 공백, 그것도 없으면 글자 수로 자른다. */
function splitChunks(text) {
  const pieces = String(text).match(/[^。．！？!?.\n]+[。．！？!?.\n]*|[。．！？!?.\n]+/gu) || [String(text)];
  const chunks = [];
  let current = "";
  const push = (value) => { if (value.trim()) chunks.push(value); };
  for (let piece of pieces) {
    while (piece.length > MAX_CHUNK) {
      let cut = piece.lastIndexOf(" ", MAX_CHUNK);
      if (cut < MAX_CHUNK / 2) cut = MAX_CHUNK;
      if (current) { push(current); current = ""; }
      push(piece.slice(0, cut));
      piece = piece.slice(cut);
    }
    if ((current + piece).length > MAX_CHUNK) { push(current); current = ""; }
    current += piece;
  }
  push(current);
  return chunks;
}

const resultCache = new Map();
function cacheKey(text, src, tgt) { return `${src}>${tgt}\u0001${text}`; }

/** 하나의 원문을 조각별로 번역해 합친다. isCancelled()가 참이면 다음 조각 전에 멈춘다(지금 조각은 끝까지 기다림).
 *  onChunk(doneChunks, totalChunks, tokens)는 실제 진행(조각 완료·토큰 생성)에서만 불린다. */
async function translateText(text, src, tgt, { isCancelled, onChunk } = {}) {
  const key = cacheKey(text, src, tgt);
  if (resultCache.has(key)) return resultCache.get(key);
  await loadModel();
  const chunks = splitChunks(text);
  const out = [];
  for (let i = 0; i < chunks.length; i += 1) {
    if (isCancelled && isCancelled()) throw Object.assign(new Error(""), { code: "cancelled" });
    const chunk = chunks[i];
    const lead = chunk.match(/^\s*/)[0], trail = chunk.match(/\s*$/)[0];
    const translated = await runChunk(chunk.trim(), src, tgt, (tokens) => onChunk && onChunk(i, chunks.length, tokens));
    out.push(lead + translated.trim() + trail);
    if (onChunk) onChunk(i + 1, chunks.length, 0);
  }
  const joined = out.join(""); // 각 조각이 원래 앞뒤 공백을 그대로 지니므로 그냥 잇는다
  if (resultCache.size >= RESULT_CACHE_LIMIT) resultCache.delete(resultCache.keys().next().value);
  resultCache.set(key, joined);
  return joined;
}

function clearResultCache() { resultCache.clear(); }

globalThis.BarobogiLocalModel = {
  MODEL, MODEL_TOTAL, snapshot, onChange, checkCache, deleteCache,
  startDownload, cancelDownload, loadModel, terminateModel, translateText, splitChunks, clearResultCache
};
