// 바로보기 웹 번역 — 점진(스트리밍) SHA-256. crypto.subtle.digest는 한 번에 전체 버퍼가 필요해 수백 MB 모델 파일을
// 메모리에 통째로 올려야 하므로, 내려받는 조각마다 갱신하는 표준 FIPS 180-4 구현을 둔다(다운로드 Worker 전용).
(() => {
  "use strict";
  const K = new Uint32Array([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ]);

  class Sha256 {
    constructor() {
      this.h = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
      this.block = new Uint8Array(64);
      this.blockLength = 0;
      this.bytes = 0;
      this.w = new Uint32Array(64);
    }

    compress(data, offset) {
      const w = this.w, h = this.h;
      for (let i = 0; i < 16; i += 1) {
        const j = offset + i * 4;
        w[i] = (data[j] << 24) | (data[j + 1] << 16) | (data[j + 2] << 8) | data[j + 3];
      }
      for (let i = 16; i < 64; i += 1) {
        const a = w[i - 15], b = w[i - 2];
        const s0 = ((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3);
        const s1 = ((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
      }
      let a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], k = h[7];
      for (let i = 0; i < 64; i += 1) {
        const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
        const t1 = (k + S1 + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
        const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
        const t2 = (S0 + ((a & b) ^ (a & c) ^ (b & c))) | 0;
        k = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      h[0] = (h[0] + a) | 0; h[1] = (h[1] + b) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0;
      h[4] = (h[4] + e) | 0; h[5] = (h[5] + f) | 0; h[6] = (h[6] + g) | 0; h[7] = (h[7] + k) | 0;
    }

    update(data) {
      let offset = 0;
      this.bytes += data.length;
      if (this.blockLength) {
        const take = Math.min(64 - this.blockLength, data.length);
        this.block.set(data.subarray(0, take), this.blockLength);
        this.blockLength += take;
        offset = take;
        if (this.blockLength < 64) return;
        this.compress(this.block, 0);
        this.blockLength = 0;
      }
      for (; offset + 64 <= data.length; offset += 64) this.compress(data, offset);
      if (offset < data.length) {
        this.block.set(data.subarray(offset), 0);
        this.blockLength = data.length - offset;
      }
    }

    hex() {
      const bitsHigh = Math.floor(this.bytes / 0x20000000), bitsLow = (this.bytes * 8) >>> 0;
      const pad = new Uint8Array(((this.blockLength < 56 ? 56 : 120) - this.blockLength) + 8);
      pad[0] = 0x80;
      const n = pad.length;
      pad[n - 8] = bitsHigh >>> 24; pad[n - 7] = bitsHigh >>> 16; pad[n - 6] = bitsHigh >>> 8; pad[n - 5] = bitsHigh;
      pad[n - 4] = bitsLow >>> 24; pad[n - 3] = bitsLow >>> 16; pad[n - 2] = bitsLow >>> 8; pad[n - 1] = bitsLow;
      const bytes = this.bytes;
      this.update(pad);
      this.bytes = bytes;
      return Array.from(this.h, (v) => (v >>> 0).toString(16).padStart(8, "0")).join("");
    }
  }

  globalThis.BarobogiSha256 = Sha256;
})();
