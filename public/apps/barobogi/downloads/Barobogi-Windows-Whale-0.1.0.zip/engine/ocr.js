"use strict";
// 바로보기 웹 번역 — 이미지 OCR 모듈(엔진 문서에서만 불러온다).
// Tesseract.js(WebAssembly, 패키지에 포함된 worker·core·언어 데이터만 사용, 원격 코드 없음)로 이미지 속 글자를 읽는다.
// 공식 저장소: https://github.com/naptha/tesseract.js
// 결과 문단 상자(x,y,w,h)·낱말 상자(g)는 모두 "넘겨받은 그 자른 이미지" 기준 0~1 비율 좌표다(별도 좌표계 변환 없음).
// 실제로 검출되지 않은 상자는 만들어 넣지 않는다(문단 전체 상자로만 폴백).
// 주의: Tesseract가 주는 g는 낱말(세로쓰기에서는 대개 열 조각) 상자이지 Mac Vision처럼 글자 하나하나의 상자가 아니다.
// 그래서 원문 가림·글자 크기 추정이 Mac판보다 거칠다(README 알려진 제한).

// vertical: 이 프로필로 읽은 문단을 세로쓰기로 그린다(사용자가 고른 프로필에서 오는 실제 신호. jpn_vert는 Tesseract
// PSM 5 "세로로 정렬된 한 덩어리 글"로 읽는다). hint: 번역 원문 언어 자동 감지에 넘기는 힌트.
const OCR_PROFILES = {
  eng: { label: "영어", tess: "eng", psm: "3", vertical: false, hint: "en" },
  jpn: { label: "일본어(가로쓰기)", tess: "jpn", psm: "3", vertical: false, hint: "ja" },
  jpn_vert: { label: "일본어(세로쓰기)", tess: "jpn_vert", psm: "5", vertical: true, hint: "ja" },
  chi_sim: { label: "중국어(간체)", tess: "chi_sim", psm: "3", vertical: false, hint: "zh" },
  kor: { label: "한국어", tess: "kor", psm: "3", vertical: false, hint: "ko" }
};
const RECOGNIZE_STALL_MS = 120000; // 한 영역 인식이 이보다 오래 걸리면 OCR Worker를 끝내 대기열을 풀어 준다

let worker = null;
let workerLang = null;
let state = { state: "unchecked", progress: null, message: "" };

function snapshot() { return { ...state, lang: workerLang }; }

function baseUrl(path) { return chrome.runtime.getURL(path); }

/** worker·core·언어 데이터를 패키지 안에서 불러온다(원격 다운로드 없음, 사용자 클릭이 없어도 된다).
 *  OCR 요청이 왔는데 고른 언어로 준비돼 있지 않으면 엔진 문서가 이 함수를 자동으로 부른다. */
let preparing = null;
function prepare(lang, onProgress) {
  if (preparing && preparing.lang === lang) return preparing.promise;
  const promise = (preparing ? preparing.promise.catch(() => {}) : Promise.resolve()).then(() => prepareNow(lang, onProgress));
  const entry = { lang, promise };
  preparing = entry;
  promise.finally(() => { if (preparing === entry) preparing = null; }).catch(() => {});
  return promise;
}

async function prepareNow(lang, onProgress) {
  const profile = OCR_PROFILES[lang];
  if (!profile) { state = { state: "unsupported", progress: null, message: "지원하지 않는 OCR 언어입니다." }; return snapshot(); }
  if (worker && workerLang === lang && state.state === "available") return snapshot();
  if (typeof Tesseract === "undefined" || typeof Tesseract.createWorker !== "function") {
    state = { state: "unsupported", progress: null, message: "OCR 실행 파일을 불러오지 못했습니다(패키지 손상 가능)." };
    return snapshot();
  }
  state = { state: "downloading", progress: 0, message: "" };
  try {
    if (worker) { await worker.terminate().catch(() => {}); worker = null; workerLang = null; }
    const nextWorker = await Tesseract.createWorker(profile.tess, 1 /* OEM.LSTM_ONLY */, {
      workerPath: baseUrl("ocr/worker.min.js"),
      corePath: baseUrl("ocr/tesseract-core-simd-lstm.wasm.js"),
      langPath: baseUrl("ocr/lang/"),
      workerBlobURL: false,
      gzip: true,
      cacheMethod: "none",
      logger: (m) => {
        if (!m || typeof m !== "object") return;
        const progress = Number.isFinite(m.progress) ? Math.max(0, Math.min(1, m.progress)) : null;
        state.progress = progress;
        if (typeof onProgress === "function") onProgress(progress, m.status);
      }
    });
    await nextWorker.setParameters({ tessedit_pageseg_mode: profile.psm });
    worker = nextWorker;
    workerLang = lang;
    state = { state: "available", progress: null, message: "" };
  } catch (error) {
    worker = null;
    workerLang = null;
    state = { state: "error", progress: null, message: error && error.message ? String(error.message) : "OCR 엔진을 준비하지 못했습니다." };
  }
  return snapshot();
}

// MARK: 배경·글자색 표본화 — Barobogi Mac(ImageTextRecognizer.sampleColors)의 그리드 다수결 방식을 Canvas로 옮긴 것.
// 문단 상자 둘레에 패딩을 더한 영역을 10x10으로 줄여 색을 양자화해 다수결 버킷을 찾는다(여백 샘플은 3배 더 신뢰).
function sampleColors(ctx, cw, ch, boxFrac) {
  const gridSize = 10;
  const boxPx = { x: boxFrac.x * cw, y: boxFrac.y * ch, w: Math.max(boxFrac.w * cw, 1), h: Math.max(boxFrac.h * ch, 1) };
  const pad = Math.min(Math.max(Math.min(boxPx.w, boxPx.h) * 0.25, 2), 12);
  const px0 = Math.max(0, Math.floor(boxPx.x - pad));
  const py0 = Math.max(0, Math.floor(boxPx.y - pad));
  const px1 = Math.min(cw, Math.ceil(boxPx.x + boxPx.w + pad));
  const py1 = Math.min(ch, Math.ceil(boxPx.y + boxPx.h + pad));
  const pw = px1 - px0, ph = py1 - py0;
  if (pw < 1 || ph < 1) return { bg: "#FFFFFF", fg: "#000000" };
  let pixels;
  try { pixels = ctx.getImageData(px0, py0, pw, ph).data; } catch { return { bg: "#FFFFFF", fg: "#000000" }; }
  const localMinX = (boxPx.x - px0) / pw, localMaxX = (boxPx.x + boxPx.w - px0) / pw;
  const localMinY = (boxPx.y - py0) / ph, localMaxY = (boxPx.y + boxPx.h - py0) / ph;
  const buckets = new Map();
  for (let gy = 0; gy < gridSize; gy += 1) {
    for (let gx = 0; gx < gridSize; gx += 1) {
      const sx = Math.min(pw - 1, Math.floor(((gx + 0.5) / gridSize) * pw));
      const sy = Math.min(ph - 1, Math.floor(((gy + 0.5) / gridSize) * ph));
      const idx = (sy * pw + sx) * 4;
      const a = pixels[idx + 3];
      if (a <= 10) continue;
      const r = pixels[idx] / 255, g = pixels[idx + 1] / 255, b = pixels[idx + 2] / 255;
      const fx = (gx + 0.5) / gridSize, fy = (gy + 0.5) / gridSize;
      const interior = fx > localMinX && fx < localMaxX && fy > localMinY && fy < localMaxY;
      const weight = interior ? 1 : 3;
      const key = (Math.round(r * 7) << 6) | (Math.round(g * 7) << 3) | Math.round(b * 7);
      const bucket = buckets.get(key) || { weight: 0, r: 0, g: 0, b: 0 };
      bucket.weight += weight; bucket.r += r * weight; bucket.g += g * weight; bucket.b += b * weight;
      buckets.set(key, bucket);
    }
  }
  let best = null;
  for (const bucket of buckets.values()) { if (!best || bucket.weight > best.weight) best = bucket; }
  if (!best || best.weight <= 0) return { bg: "#FFFFFF", fg: "#000000" };
  const r = best.r / best.weight, g = best.g / best.weight, b = best.b / best.weight;
  const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
  const hex = (v) => Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, "0").toUpperCase();
  return { bg: `#${hex(r)}${hex(g)}${hex(b)}`, fg: luminance > 0.55 ? "#000000" : "#FFFFFF" };
}

const MIN_CONFIDENCE = 35;

/** canvas(이미 잘라낸 한 이미지 영역)를 OCR해 문단 단위 항목을 돌려준다. 신뢰도가 낮거나 글자가 없는 문단은 뺀다
 *  (상자를 지어내지 않는다). 글자 상자(g)는 실제로 검출된 낱말 상자만 담는다(문단에 낱말이 없으면 g는 빈 배열). */
async function recognizeRegion(canvas) {
  if (!worker) throw Object.assign(new Error("OCR 엔진이 준비되지 않았습니다."), { code: "ocr_not_ready" });
  const vertical = OCR_PROFILES[workerLang]?.vertical === true;
  const cw = canvas.width, ch = canvas.height;
  let timer = 0;
  const { data } = await Promise.race([
    worker.recognize(canvas, {}, { text: false, blocks: true }),
    new Promise((_, reject) => {
      timer = setTimeout(() => {
        abort();
        reject(Object.assign(new Error("이미지 글자 인식이 2분 넘게 끝나지 않아 OCR 엔진을 다시 시작합니다."), { code: "ocr_stalled" }));
      }, RECOGNIZE_STALL_MS);
    })
  ]).finally(() => clearTimeout(timer));
  const ctx = canvas.getContext("2d");
  const items = [];
  const paragraphs = [];
  for (const block of data.blocks || []) {
    for (const paragraph of block.paragraphs || []) paragraphs.push(paragraph);
  }
  for (const paragraph of paragraphs) {
    const text = String(paragraph.text || "").replace(/\s+/g, " ").trim();
    if (!text || !(paragraph.confidence >= MIN_CONFIDENCE)) continue;
    const box = paragraph.bbox;
    if (!box || box.x1 <= box.x0 || box.y1 <= box.y0) continue;
    const frac = { x: box.x0 / cw, y: box.y0 / ch, w: (box.x1 - box.x0) / cw, h: (box.y1 - box.y0) / ch };
    const words = [];
    for (const line of paragraph.lines || []) {
      for (const word of line.words || []) {
        const wb = word.bbox;
        if (!wb || wb.x1 <= wb.x0 || wb.y1 <= wb.y0) continue;
        if (!(word.confidence >= MIN_CONFIDENCE)) continue;
        words.push([wb.x0 / cw, wb.y0 / ch, (wb.x1 - wb.x0) / cw, (wb.y1 - wb.y0) / ch]);
      }
    }
    const { bg, fg } = sampleColors(ctx, cw, ch, frac);
    items.push({
      x: frac.x, y: frac.y, w: frac.w, h: frac.h, o: text.slice(0, 700), v: vertical ? 1 : 0,
      bg, fg, ...(words.length ? { g: words, gl: "1".repeat(words.length) } : {})
    });
  }
  return items;
}

/** 진행 중인 OCR 작업을 즉시 멈춘다(취소 때 대기열이 막히지 않게 worker를 끝낸다). 다시 쓰려면 prepare()를 다시 불러야 한다. */
function abort() {
  const toKill = worker;
  worker = null;
  workerLang = null;
  state = { state: "unchecked", progress: null, message: "" };
  if (toKill) toKill.terminate().catch(() => {});
}

/** 고른 OCR 언어로 준비돼 있지 않으면 준비한다(패키지 자원만 사용). 실패하면 false. */
async function ensure(lang) {
  if (worker && workerLang === lang && state.state === "available") return true;
  const result = await prepare(lang);
  return result.state === "available";
}

globalThis.BarobogiOcr = { OCR_PROFILES, prepare, ensure, snapshot, recognizeRegion, abort };
