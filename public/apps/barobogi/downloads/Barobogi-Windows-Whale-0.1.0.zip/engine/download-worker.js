"use strict";
// 바로보기 웹 번역 — 모델 다운로드 전용 Worker(엔진 문서가 만들고, 취소하면 terminate한다).
// - model-spec.js에 고정된 파일만, 고정 리비전 URL에서만 받는다. 요청에는 쿠키·리퍼러·번역할 내용이 없다(credentials: omit).
// - 받는 동안 바이트 수·SHA-256(큰 파일)·git blob SHA-1(작은 JSON)을 확인하고, 크기·해시가 맞을 때만 "검증됨" 표시를 남긴다.
//   검증 표시가 없는 항목은 다음 실행 때 다시 받는다(중간에 꺼져 생긴 불완전한 항목을 쓰지 않음).
// - 모든 파일이 검증되면 완료 표시(readyMarker)를 남긴다. 엔진은 완료 표시가 있을 때만 모델을 불러온다.
importScripts("model-spec.js", "sha256.js");

const SPEC = self.BAROBOGI_MODEL;
const urlOf = self.BAROBOGI_MODEL_URL;
const VERIFIED_SUFFIX = self.BAROBOGI_VERIFIED_SUFFIX;
const READY_URL = self.BAROBOGI_MODEL_READY_URL;
const PROGRESS_INTERVAL = 250;

function hex(buffer) {
  return Array.from(new Uint8Array(buffer), (b) => b.toString(16).padStart(2, "0")).join("");
}

async function isVerified(cache, file) {
  const [entry, mark] = await Promise.all([cache.match(urlOf(file.path)), cache.match(urlOf(file.path) + VERIFIED_SUFFIX)]);
  if (!entry || !mark) return false;
  try { return (await mark.json()).size === file.size; } catch { return false; }
}

function codedError(code, message) {
  return Object.assign(new Error(message), { code });
}

async function fetchFile(file) {
  let response;
  try {
    response = await fetch(urlOf(file.path), {
      credentials: "omit", cache: "no-store", redirect: "follow", referrerPolicy: "no-referrer", mode: "cors"
    });
  } catch (error) {
    throw codedError("network", `내려받기 연결 실패(${file.path}): ${error && error.message ? error.message : error}`);
  }
  if (response.status !== 200 || !response.body) {
    throw codedError("http", `내려받기 실패(${file.path}): HTTP ${response.status}`);
  }
  return response;
}

/** 작은 JSON 파일: 메모리에 받아 git blob SHA-1을 확인한 뒤 저장한다. */
async function downloadSmall(cache, file, report) {
  const response = await fetchFile(file);
  const body = new Uint8Array(await response.arrayBuffer());
  report(body.length);
  if (body.length !== file.size) throw codedError("size", `크기가 다릅니다(${file.path}): ${body.length} ≠ ${file.size}`);
  const header = new TextEncoder().encode(`blob ${body.length}\0`);
  const joined = new Uint8Array(header.length + body.length);
  joined.set(header, 0);
  joined.set(body, header.length);
  const sha1 = hex(await crypto.subtle.digest("SHA-1", joined));
  if (sha1 !== file.gitSha1) throw codedError("hash", `해시가 다릅니다(${file.path})`);
  await cache.put(urlOf(file.path), new Response(body, {
    headers: { "content-type": "application/json", "content-length": String(body.length) }
  }));
}

/** 큰 ONNX 파일: 스트림으로 받으면서 SHA-256을 갱신하고, 같은 스트림을 그대로 Cache API에 쓴다(전체를 메모리에 두지 않음). */
async function downloadLarge(cache, file, report) {
  const response = await fetchFile(file);
  const reader = response.body.getReader();
  const hasher = new self.BarobogiSha256();
  let received = 0;
  const stream = new ReadableStream({
    async pull(controller) {
      const { done, value } = await reader.read();
      if (done) { controller.close(); return; }
      received += value.length;
      if (received > file.size) {
        const error = codedError("size", `받은 크기가 예상보다 큽니다(${file.path})`);
        controller.error(error);
        reader.cancel().catch(() => {});
        return;
      }
      hasher.update(value);
      report(value.length);
      controller.enqueue(value);
    },
    cancel(reason) { reader.cancel(reason).catch(() => {}); }
  });
  const url = urlOf(file.path);
  await cache.put(url, new Response(stream, {
    headers: { "content-type": "application/octet-stream", "content-length": String(file.size) }
  }));
  if (received !== file.size) {
    await cache.delete(url).catch(() => {});
    throw codedError("size", `크기가 다릅니다(${file.path}): ${received} ≠ ${file.size}`);
  }
  const digest = hasher.hex();
  if (digest !== file.sha256) {
    await cache.delete(url).catch(() => {});
    throw codedError("hash", `SHA-256이 다릅니다(${file.path})`);
  }
}

async function run() {
  const cache = await caches.open(SPEC.cacheName);
  const total = self.BAROBOGI_MODEL_TOTAL;
  let done = 0;
  let lastPost = 0;
  let current = null;
  const post = (force = false) => {
    const now = Date.now();
    if (!force && now - lastPost < PROGRESS_INTERVAL) return;
    lastPost = now;
    self.postMessage({ type: "progress", done, total, file: current ? current.path : null });
  };
  for (const file of SPEC.files) {
    if (await isVerified(cache, file)) { done += file.size; post(true); continue; }
    current = file;
    const startDone = done;
    const report = (bytes) => { done += bytes; post(); };
    try {
      if (file.sha256) await downloadLarge(cache, file, report);
      else await downloadSmall(cache, file, report);
    } catch (error) {
      done = startDone;
      throw error;
    }
    await cache.put(urlOf(file.path) + VERIFIED_SUFFIX, new Response(JSON.stringify({ size: file.size, at: Date.now() }), {
      headers: { "content-type": "application/json" }
    }));
    done = startDone + file.size;
    post(true);
  }
  await cache.put(READY_URL, new Response(JSON.stringify({ revision: SPEC.revision, total, at: Date.now() }), {
    headers: { "content-type": "application/json" }
  }));
  self.postMessage({ type: "done", done, total });
}

self.onmessage = (event) => {
  if (!event.data || event.data.type !== "start") return;
  run().catch((error) => {
    const quota = error && (error.name === "QuotaExceededError" || /quota/i.test(String(error.message)));
    self.postMessage({
      type: "error",
      code: quota ? "quota" : (error && error.code) || "error",
      message: quota ? "저장 공간이 부족해 모델을 저장하지 못했습니다(약 640MB 필요)." : String((error && error.message) || error)
    });
  });
};
