"use strict";
// 바로보기 웹 번역 — 엔진 문서(engine.html) 제어. Chrome 사이드패널, Chrome·Whale 공통 엔진 창(확장이 연 좁은 창)에서
// 같은 코드로 동작한다. 배경 서비스 워커와 "engine" 포트로 연결해 번역·OCR 요청을 받는다.
// - 요청은 한 번에 하나씩(대기열 상한 있음) 처리해 메모리·CPU를 제한한다. 상태 확인 요청은 대기열을 거치지 않는다.
// - 대기 중·실행 중인 요청 ID를 5초마다(그리고 실제 진행이 있을 때) 배경에 알린다. 배경은 이 신호가 끊길 때만
//   시간 초과로 처리하므로, 느린 CPU에서 긴 번역이 고정 60초에 잘리지 않는다. 대신 엔진 쪽에서 조각별 정지 감시
//   (토큰 2분 무진행·OCR 2분)를 해서 실제로 멈춘 계산은 Worker를 다시 만들어 끝낸다.
const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const MAX_QUEUE = 32;
const ALIVE_INTERVAL = 5000;
const IS_WHALE = typeof globalThis.whale !== "undefined" || /\bWhale\//.test(navigator.userAgent);

let settings = { target: "ko", source: "auto", ocrLang: "jpn", nativeFirst: false };
let active = false;

// MARK: 배경 연결

let port = null;
let reconnectDelay = 300;
const queue = []; // { message, cancelled }
const queuedIds = new Map(); // id → entry
let running = null; // { message, cancelled, progress }
let lastAliveAt = 0;

function connectEnginePort() {
  try {
    port = chrome.runtime.connect({ name: "engine" });
  } catch {
    setTimeout(connectEnginePort, Math.min(10000, (reconnectDelay *= 2)));
    return;
  }
  port.onMessage.addListener(onPortMessage);
  port.onDisconnect.addListener(() => {
    // 서비스 워커 재시작 등으로 끊기면 다시 연결한다. 끊긴 포트로 받은 요청은 배경이 이미 실패 처리했으므로 버린다.
    port = null;
    active = false;
    for (const entry of queue) entry.cancelled = true;
    queue.length = 0;
    queuedIds.clear();
    if (running) running.cancelled = true;
    renderRole();
    setTimeout(connectEnginePort, Math.min(10000, reconnectDelay));
    reconnectDelay = Math.min(10000, reconnectDelay * 2);
  });
  reconnectDelay = 300;
}

function post(message) {
  if (!port) return;
  try { port.postMessage(message); } catch { /* 연결 끊김 */ }
}

function sendAlive(force = false) {
  const ids = [...queuedIds.keys()];
  if (running) ids.push(running.message.id);
  if (!ids.length) return;
  const now = Date.now();
  if (!force && now - lastAliveAt < 1000) return;
  lastAliveAt = now;
  post({ type: "alive", ids });
}
setInterval(() => sendAlive(true), ALIVE_INTERVAL);

function onPortMessage(message) {
  if (!message || typeof message !== "object") return;
  if (message.type === "role") {
    active = message.active === true;
    renderRole();
    if (active) autoLoadModel();
    return;
  }
  if (typeof message.id !== "string") return;
  if (message.type === "cancel") {
    const entry = queuedIds.get(message.id);
    if (entry) { entry.cancelled = true; queuedIds.delete(message.id); }
    if (running && running.message.id === message.id) {
      running.cancelled = true;
      // OCR 인식은 Tesseract Worker 안에서 돌아 중간에 멈출 수 없다: Worker를 끝내 대기열을 풀어 준다(다음 요청 때 자동 재준비).
      if (running.message.type === "ocr" && running.phase === "ocr") BarobogiOcr.abort();
    }
    return;
  }
  if (message.type === "status") {
    post({ id: message.id, ok: true, result: statusSnapshot() });
    return;
  }
  if (queue.length >= MAX_QUEUE) {
    post({ id: message.id, ok: false, code: "busy", message: "번역 엔진 대기열이 가득 찼습니다. 잠시 뒤 다시 시도하세요." });
    return;
  }
  const entry = { message, cancelled: false };
  queue.push(entry);
  queuedIds.set(message.id, entry);
  sendAlive(true);
  pump();
}

let pumping = false;
async function pump() {
  if (pumping) return;
  pumping = true;
  try {
    while (queue.length) {
      const entry = queue.shift();
      queuedIds.delete(entry.message.id);
      if (entry.cancelled) { post({ id: entry.message.id, ok: false, code: "cancelled", message: "" }); continue; }
      running = { ...entry, phase: "", progress: "" };
      const current = running;
      renderJob();
      try {
        const result = await handleRequest(current);
        if (current.cancelled) post({ id: current.message.id, ok: false, code: "cancelled", message: "" });
        else post({ id: current.message.id, ok: true, result });
      } catch (error) {
        post({ id: current.message.id, ok: false, code: (error && error.code) || "error", message: (error && error.message) || "" });
      } finally {
        running = null;
        renderJob();
      }
    }
  } finally {
    pumping = false;
  }
}

function cancelledError() { return Object.assign(new Error(""), { code: "cancelled" }); }

async function handleRequest(job) {
  const { type, payload } = job.message;
  const isCancelled = () => job.cancelled;
  switch (type) {
    case "translate": {
      job.phase = "text";
      const hint = BarobogiLangDetect.normalizeHint(payload.hint);
      return BarobogiTranslate.translateBatch(payload.texts, payload.target, payload.source, {
        hint, nativeFirst: settings.nativeFirst, isCancelled,
        onProgress: (done, total) => { job.progress = `글자 ${Math.floor(done)}/${total}`; renderJob(); sendAlive(); }
      });
    }
    case "ocr":
      return handleOcrRequest(job, payload);
    default:
      throw Object.assign(new Error("알 수 없는 엔진 요청입니다."), { code: "bad_request" });
  }
}

// MARK: OCR 요청 — 캡처 전체 이미지를 받아 영역별로 자르고 인식한 뒤, 같은 번역 라우터로 번역한다.

async function handleOcrRequest(job, { dataUrl, viewport, regions, target, source, ocrLang }) {
  const isCancelled = () => job.cancelled;
  const profile = BarobogiOcr.OCR_PROFILES[ocrLang] ? ocrLang : settings.ocrLang;
  const missing = [];
  job.phase = "ocr-prepare";
  job.progress = "OCR 준비";
  renderJob();
  const ready = await BarobogiOcr.ensure(profile);
  refreshOcrStatus();
  if (isCancelled()) throw cancelledError();
  if (!ready) {
    return { images: regions.map((r) => ({ k: r.k, items: [], langs: {} })), missing: ["ocr"], warning: BarobogiTranslate.warningFor(["ocr"]) };
  }
  const bitmap = await dataUrlToBitmap(dataUrl);
  const scaleX = bitmap.width / viewport.w;
  const scaleY = bitmap.height / viewport.h;
  const perRegion = [];
  job.phase = "ocr";
  try {
    for (let index = 0; index < regions.length; index += 1) {
      if (isCancelled()) throw cancelledError();
      const region = regions[index];
      job.progress = `이미지 인식 ${index + 1}/${regions.length}`;
      renderJob();
      sendAlive();
      const sx = Math.max(0, Math.round(region.x * scaleX));
      const sy = Math.max(0, Math.round(region.y * scaleY));
      const sw = Math.max(1, Math.min(bitmap.width - sx, Math.round(region.w * scaleX)));
      const sh = Math.max(1, Math.min(bitmap.height - sy, Math.round(region.h * scaleY)));
      const canvas = new OffscreenCanvas(sw, sh);
      canvas.getContext("2d").drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);
      let items = [];
      try {
        items = await BarobogiOcr.recognizeRegion(canvas);
      } catch (error) {
        if (isCancelled()) throw cancelledError();
        missing.push("ocr");
        refreshOcrStatus();
      }
      perRegion.push({ k: region.k, items });
    }
  } finally {
    bitmap.close?.();
  }
  if (isCancelled()) throw cancelledError();

  // 인식한 문단 원문을 모두 모아 번역한다. OCR 언어를 원문 언어 힌트로 넘긴다(사용자가 고른 프로필에서 온 실제 신호).
  const refs = [];
  for (const region of perRegion) for (const item of region.items) refs.push(item);
  job.phase = "translate";
  let warning = missing.length ? BarobogiTranslate.warningFor(missing) : "";
  if (refs.length) {
    const result = await BarobogiTranslate.translateBatch(refs.map((item) => item.o), target, source, {
      hint: BarobogiOcr.OCR_PROFILES[profile].hint, nativeFirst: settings.nativeFirst, isCancelled,
      onProgress: (done, total) => { job.progress = `이미지 글자 번역 ${Math.floor(done)}/${total}`; renderJob(); sendAlive(); }
    });
    result.missing.forEach((m) => missing.push(m));
    warning = BarobogiTranslate.warningFor(missing);
    refs.forEach((item, i) => {
      item.t = typeof result.texts[i] === "string" ? result.texts[i] : "";
      if (result.langs[i]) item.lang = result.langs[i];
    });
  }
  const images = perRegion.map((region) => {
    const langs = {};
    for (const item of region.items) {
      if (item.lang) langs[item.lang] = (langs[item.lang] || 0) + 1;
      delete item.lang;
    }
    return { k: region.k, items: region.items, langs };
  });
  return { images, missing: [...new Set(missing)], warning };
}

async function dataUrlToBitmap(dataUrl) {
  const blob = await (await fetch(dataUrl)).blob();
  return createImageBitmap(blob);
}

function statusSnapshot() {
  const snap = BarobogiLocalModel.snapshot();
  return {
    active,
    model: { cache: snap.cache, runtime: snap.runtime, download: snap.download, done: snap.downloadDone, total: snap.total },
    ocr: BarobogiOcr.snapshot(),
    busy: !!running,
    queued: queue.length
  };
}

// MARK: 상태 표시

const fmtBytes = (n) => `${(n / 1048576).toFixed(1)}MB`;
const fmtExact = (n) => `${Number(n).toLocaleString("ko-KR")}바이트`;

function renderRole() {
  $("roleNote").hidden = active || !port;
}

function renderJob() {
  if (!running) { $("jobStatus").textContent = queue.length ? `대기 ${queue.length}건` : "대기 중"; return; }
  const kind = running.message.type === "ocr" ? "이미지" : "글자";
  $("jobStatus").textContent = `처리 중: ${kind} 요청 · ${running.progress || "시작"}${queue.length ? ` · 대기 ${queue.length}건` : ""}`;
}

function renderModel(snap) {
  const total = snap.total;
  let status = "";
  const show = { downloadModel: false, cancelDownload: false, loadModel: false, restartModel: false, deleteModel: false };
  let progress = null;
  if (snap.download === "running") {
    status = "모델 내려받는 중…";
    progress = snap.downloadDone / total;
    show.cancelDownload = true;
  } else if (snap.cache === "checking" || snap.cache === "unknown") {
    status = "저장된 모델 확인 중…";
  } else if (snap.cache === "error") {
    status = `저장소를 확인하지 못했습니다: ${snap.downloadError}`;
    show.downloadModel = true;
  } else if (snap.cache !== "complete") {
    status = snap.download === "failed" ? `내려받기 실패: ${snap.downloadError}` :
      snap.download === "cancelled" ? snap.downloadError :
      snap.cache === "partial" ? "일부만 받아져 있습니다. 이어서 받으세요." : "모델이 아직 없습니다. 처음 한 번 내려받아야 합니다.";
    show.downloadModel = true;
    show.deleteModel = snap.cache === "partial";
    progress = snap.cache === "partial" ? snap.cachedBytes / total : null;
  } else if (snap.runtime === "ready") {
    status = "준비됨 · 이 PC에서 번역할 수 있습니다.";
    show.restartModel = true;
    show.deleteModel = true;
  } else if (snap.runtime === "loading") {
    const part = snap.loadFile ? ` (${snap.loadFile}${Number.isFinite(snap.loadLoaded) && Number.isFinite(snap.loadTotal) && snap.loadTotal > 0
      ? ` ${Math.round((snap.loadLoaded / snap.loadTotal) * 100)}%` : ""})` : "";
    status = `모델을 메모리에 불러오는 중…${part}`;
    if (Number.isFinite(snap.loadLoaded) && Number.isFinite(snap.loadTotal) && snap.loadTotal > 0) progress = snap.loadLoaded / snap.loadTotal;
    show.restartModel = true;
  } else if (snap.runtime === "error") {
    status = `모델을 불러오지 못했습니다: ${snap.runtimeError}`;
    show.loadModel = true;
    show.deleteModel = true;
  } else {
    status = active ? "내려받음 · 아직 메모리에 불러오지 않았습니다." : "내려받음 · 이 창이 대기 중이라 불러오지 않았습니다.";
    show.loadModel = true;
    show.deleteModel = true;
  }
  if (snap.download === "failed" && snap.cache !== "complete") $("downloadModel").textContent = "다시 시도";
  else if (snap.cache === "partial") $("downloadModel").textContent = "이어서 내려받기";
  else $("downloadModel").textContent = `모델 내려받기 (약 ${Math.round(total / 1e6)}MB)`;
  $("modelStatus").textContent = status;
  for (const [id, visible] of Object.entries(show)) $(id).hidden = !visible;
  $("modelProgress").hidden = progress === null;
  if (progress !== null) $("modelProgressBar").style.width = `${Math.max(0, Math.min(100, progress * 100)).toFixed(1)}%`;
  const bytes = snap.download === "running" ? snap.downloadDone : snap.cachedBytes;
  $("modelBytes").textContent = snap.cache === "complete" && snap.download !== "running"
    ? `저장됨: ${fmtExact(total)} (${fmtBytes(total)})`
    : `받은 양: ${fmtBytes(bytes)} / ${fmtBytes(total)} (${fmtExact(bytes)} / ${fmtExact(total)})`;
  $("setupBanner").hidden = snap.cache === "complete" || (snap.cache !== "missing" && snap.cache !== "partial" && params.get("setup") !== "1");
}

BarobogiLocalModel.onChange(renderModel);

function autoLoadModel() {
  const snap = BarobogiLocalModel.snapshot();
  if (active && snap.cache === "complete" && snap.runtime === "idle") BarobogiLocalModel.loadModel().catch(() => {});
}

// MARK: 모델 버튼

const DOWNLOAD_ORIGINS = ["https://huggingface.co/*", "https://*.hf.co/*"];

$("downloadModel").addEventListener("click", async () => {
  // 선택 권한: 모델 주소(huggingface.co와 그 CDN *.hf.co)에만 접근을 요청한다. 거절해도 공개 CORS로 받기를 시도한다.
  try { await chrome.permissions.request({ origins: DOWNLOAD_ORIGINS }); } catch { /* 이 브라우저가 지원하지 않으면 그대로 진행 */ }
  const outcome = await BarobogiLocalModel.startDownload();
  if (outcome === "done") autoLoadModel();
});
$("cancelDownload").addEventListener("click", () => BarobogiLocalModel.cancelDownload());
$("loadModel").addEventListener("click", () => BarobogiLocalModel.loadModel().catch(() => {}));
$("restartModel").addEventListener("click", () => {
  BarobogiLocalModel.terminateModel("사용자가 번역 Worker를 다시 시작했습니다.");
  autoLoadModel();
});
$("deleteModel").addEventListener("click", async () => {
  if (!confirm("내려받은 모델(약 640MB)을 이 브라우저에서 지울까요? 다시 쓰려면 다시 내려받아야 합니다.")) return;
  await BarobogiLocalModel.deleteCache();
});

// MARK: OCR

function refreshOcrStatus() {
  const snap = BarobogiOcr.snapshot();
  const label = { unchecked: "아직 준비하지 않음(첫 이미지 요청 때 자동 준비)", downloading: "준비 중…", available: "준비됨",
                  error: snap.message || "준비하지 못했습니다.", unsupported: snap.message || "지원하지 않습니다." }[snap.state] || "확인 전";
  if (snap.lang && snap.lang !== settings.ocrLang && snap.state === "available") {
    $("ocrStatus").textContent = `${BarobogiOcr.OCR_PROFILES[snap.lang]?.label || snap.lang} 준비됨 · 고른 언어는 첫 요청 때 다시 준비합니다.`;
  } else {
    $("ocrStatus").textContent = label;
  }
  $("ocrProgress").hidden = snap.state !== "downloading" || !Number.isFinite(snap.progress);
  if (Number.isFinite(snap.progress)) $("ocrProgressBar").style.width = `${Math.round(snap.progress * 100)}%`;
}

$("prepareOcr").addEventListener("click", async () => {
  $("prepareOcr").disabled = true;
  try {
    await BarobogiOcr.prepare(settings.ocrLang, () => refreshOcrStatus());
  } finally {
    $("prepareOcr").disabled = false;
    refreshOcrStatus();
  }
});

// MARK: 선택 엔진 — 브라우저 내장 번역

function renderNative() {
  if (!BarobogiTranslate.hasTranslatorApi()) { $("nativeGroup").hidden = true; return; }
  $("nativeGroup").hidden = false;
  $("nativeNote").textContent = IS_WHALE
    ? "이 브라우저에 Translator API가 보이지만 Whale에서의 동작은 확인하지 않았습니다. 쓰지 않아도 공통 로컬 모델로 번역됩니다."
    : "Chrome 기기 내 번역(Translator API). 준비 버튼을 누른 언어 조합만, 인스턴스가 실제로 만들어진 뒤에 씁니다.";
  $("nativeFirst").checked = settings.nativeFirst;
  const list = $("nativePairs");
  list.textContent = "";
  const sources = settings.source === "auto" ? BarobogiTranslate.LOCAL_LANGS : [settings.source];
  for (const lang of sources) {
    if (lang === settings.target) continue;
    const row = document.createElement("div");
    row.className = "pairRow";
    const button = document.createElement("button");
    const status = document.createElement("p");
    status.className = "statusLine";
    const paint = (snap) => {
      const text = { ready: "준비됨", downloading: `내려받는 중… ${Math.round((snap.progress || 0) * 100)}%`, unavailable: snap.message,
                     unsupported: snap.message, error: snap.message, downloadable: "내려받기 필요", available: "사용 가능(아직 만들지 않음)" }[snap.state];
      status.textContent = text || "확인 전";
    };
    button.textContent = `${lang} → ${settings.target} 내장 번역 준비`;
    button.addEventListener("click", async () => {
      button.disabled = true;
      try { paint(await BarobogiTranslate.prepareNative(lang, settings.target, () => paint(BarobogiTranslate.nativeSnapshot(lang, settings.target)))); }
      finally { button.disabled = false; }
    });
    row.append(button, status);
    list.appendChild(row);
    BarobogiTranslate.adoptNativeIfAvailable(lang, settings.target).then(paint, () => {});
  }
}

$("nativeFirst").addEventListener("change", (event) => {
  chrome.storage.local.set({ nativeFirst: event.target.checked }).catch(() => {});
});

// MARK: 설정(팝업과 공유, chrome.storage)

async function call(message) {
  const response = await chrome.runtime.sendMessage(message);
  if (!response || response.ok !== true) throw new Error(response?.message || "요청을 처리하지 못했습니다.");
  return response;
}

async function webTabId() {
  try {
    const win = await chrome.windows.getLastFocused({ windowTypes: ["normal"] });
    const [tab] = await chrome.tabs.query({ active: true, windowId: win.id });
    return Number.isInteger(tab?.id) ? tab.id : null;
  } catch {
    return null;
  }
}

$("target").addEventListener("change", async (event) => {
  await call({ cmd: "setTarget", target: event.target.value, tabId: await webTabId() }).catch(() => {});
});
$("source").addEventListener("change", async (event) => {
  await call({ cmd: "setSource", source: event.target.value, tabId: await webTabId() }).catch(() => {});
});
$("ocrLang").addEventListener("change", async (event) => {
  await call({ cmd: "setOcrLang", ocrLang: event.target.value, tabId: await webTabId() }).catch(() => {});
});

function applySettings(stored) {
  settings = {
    target: BarobogiTranslate.TARGET_LANGS.includes(stored.target) ? stored.target : "ko",
    source: BarobogiTranslate.SOURCE_LANGS.includes(stored.source) ? stored.source : "auto",
    ocrLang: BarobogiOcr.OCR_PROFILES[stored.ocrLang] ? stored.ocrLang : "jpn",
    nativeFirst: stored.nativeFirst === true
  };
  $("target").value = settings.target;
  $("source").value = settings.source;
  $("ocrLang").value = settings.ocrLang;
  renderNative();
  refreshOcrStatus();
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (!["target", "source", "ocrLang", "nativeFirst"].some((key) => key in changes)) return;
  chrome.storage.local.get({ target: "ko", source: "auto", ocrLang: "jpn", nativeFirst: false }).then(applySettings, () => {});
});

// MARK: 현재 웹 탭 상태(엔진 창 자신이 아니라 마지막으로 쓴 일반 창의 활성 탭)

function summarize(page) {
  if (!page) return "";
  const parts = [];
  if (Number.isInteger(page.inventory?.textSentences)) parts.push(`일반 ${page.inventory.textSentences}문장`);
  if (Number.isInteger(page.inventory?.imageSentences)) parts.push(`이미지 속 ${page.inventory.imageSentences}문장`);
  return parts.join(" · ");
}

async function refreshPageStatus() {
  try {
    const tabId = await webTabId();
    const response = await call({ cmd: "pageProgress", tabId });
    const page = response.page;
    $("pageStatus").textContent = page ? `${page.view === "translated" ? "번역 표시" : "원문 표시"} · ${page.warning || page.status || ""}` : "현재 웹 탭은 아직 번역하지 않았습니다.";
    $("pageSummary").textContent = summarize(page);
  } catch {
    $("pageStatus").textContent = "탭 상태를 불러오지 못했습니다.";
  }
}

(async () => {
  let context = params.get("context");
  if (!context) {
    let tab = null;
    try { tab = await chrome.tabs.getCurrent(); } catch { tab = null; }
    context = tab ? "tab" : "panel";
  }
  $("contextLabel").textContent = { window: "엔진 창", panel: "사이드패널", tab: "탭" }[context] || "";
  try {
    applySettings(await chrome.storage.local.get({ target: "ko", source: "auto", ocrLang: "jpn", nativeFirst: false }));
  } catch { applySettings({}); }
  renderModel(BarobogiLocalModel.snapshot());
  await BarobogiLocalModel.checkCache();
  connectEnginePort();
  refreshPageStatus();
  setInterval(refreshPageStatus, 2000);
  try { await navigator.storage?.persist?.(); } catch { /* 지원하지 않으면 무시 */ }
})();
