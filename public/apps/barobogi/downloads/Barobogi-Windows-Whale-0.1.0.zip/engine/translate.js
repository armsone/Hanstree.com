"use strict";
// 바로보기 웹 번역 — 번역 라우터(엔진 문서 전용).
// 기본 엔진: 공통 로컬 모델(M2M100 418M, engine/local-model.js) — Chrome·Whale 모두 같은 경로, window.Translator와 무관.
// 선택 엔진: Chrome 내장 Translator API(기기 내 처리). 사용자가 '브라우저 내장 번역 우선'을 켜고, 해당 언어 조합의
//   Translator 인스턴스가 실제로 만들어져 있을 때만 쓴다(API 존재 여부만으로 준비됐다고 표시하지 않음).
//   공식 문서: https://developer.chrome.com/docs/ai/translator-api
// 원문 언어 자동 감지는 engine/langdetect.js(franc-min + 유니코드 문자 종류 + 페이지·OCR 힌트)로 한다.

const TARGET_LANGS = ["ko", "en", "ja", "zh", "zh-Hant"];
const LOCAL_LANGS = ["ko", "en", "ja", "zh"]; // M2M100이 실제로 지원하는 이 UI의 언어(번체 출력은 보장하지 않으므로 제외)
const SOURCE_LANGS = ["auto", "ko", "en", "ja", "zh"];

const MISSING_TEXT = {
  model: "로컬 번역 모델을 아직 내려받지 않았습니다. 번역 엔진 창에서 '모델 내려받기'를 눌러 주세요.",
  "model-error": "로컬 번역 모델을 불러오지 못했습니다. 번역 엔진 창에서 상태를 확인하세요.",
  "language-detection": "원문 언어를 판별하지 못한 문장은 번역하지 않았습니다(원문 언어를 직접 고르면 번역됩니다).",
  "zh-Hant": "중국어(번체) 출력은 공통 로컬 모델이 지원하지 않습니다(Chrome 내장 번역을 준비한 경우에만 가능).",
  "unsupported-source": "이 확장이 다루지 않는 원문 언어입니다(한국어·영어·일본어·중국어만).",
  ocr: "이미지 글자 인식(OCR) 엔진을 준비하지 못했습니다.",
  partial: "일부 문장은 번역하지 못했습니다."
};

function warningFor(missing) {
  return [...new Set(missing)].map((code) => MISSING_TEXT[code] || code).join(" ").slice(0, 300);
}

// MARK: 선택 엔진 — Chrome 내장 Translator(인스턴스가 실제로 있을 때만 사용)

function hasTranslatorApi() { return typeof self !== "undefined" && "Translator" in self; }

const nativePairs = new Map(); // "src>tgt" → { state, progress, translator, message }

function nativeEntry(source, target) {
  const key = `${source}>${target}`;
  if (!nativePairs.has(key)) nativePairs.set(key, { state: "unchecked", progress: null, translator: null, message: "" });
  return nativePairs.get(key);
}

function nativeSnapshot(source, target) {
  const entry = nativeEntry(source, target);
  return { state: entry.translator ? "ready" : entry.state, progress: entry.progress, message: entry.message };
}

/** 사용자 클릭 안에서 부른다(모델 다운로드가 필요하면 Translator.create가 그 자리에서 시작). */
async function prepareNative(source, target, onProgress) {
  const entry = nativeEntry(source, target);
  if (!hasTranslatorApi()) { entry.state = "unsupported"; entry.message = "이 브라우저에는 내장 Translator API가 없습니다."; return nativeSnapshot(source, target); }
  if (entry.translator) return nativeSnapshot(source, target);
  try {
    const availability = await Translator.availability({ sourceLanguage: source, targetLanguage: target });
    if (availability === "unavailable") {
      entry.state = "unavailable";
      entry.message = "이 언어 조합은 내장 번역이 지원하지 않습니다.";
      return nativeSnapshot(source, target);
    }
    entry.state = "downloading";
    entry.progress = 0;
    entry.translator = await Translator.create({
      sourceLanguage: source, targetLanguage: target,
      monitor(m) {
        m.addEventListener("downloadprogress", (e) => {
          entry.progress = Number.isFinite(e.loaded) ? Math.max(0, Math.min(1, e.loaded)) : entry.progress;
          if (typeof onProgress === "function") onProgress(entry.progress);
        });
      }
    });
    entry.state = "ready";
    entry.progress = null;
    entry.message = "";
  } catch (error) {
    entry.translator = null;
    entry.state = "error";
    entry.message = error && error.message ? String(error.message) : "내장 번역을 준비하지 못했습니다.";
  }
  return nativeSnapshot(source, target);
}

/** 이미 내려받아진("available") 조합은 사용자 동작 없이도 인스턴스를 만들 수 있다. 그 밖에는 만들지 않는다. */
async function adoptNativeIfAvailable(source, target) {
  const entry = nativeEntry(source, target);
  if (entry.translator || !hasTranslatorApi()) return nativeSnapshot(source, target);
  try {
    const availability = await Translator.availability({ sourceLanguage: source, targetLanguage: target });
    entry.state = availability;
    if (availability === "available") {
      entry.translator = await Translator.create({ sourceLanguage: source, targetLanguage: target });
      entry.state = "ready";
    }
  } catch (error) {
    entry.state = "error";
    entry.message = error && error.message ? String(error.message) : "";
  }
  return nativeSnapshot(source, target);
}

// MARK: 일괄 번역

/** texts: string[], target: 번역 언어, source: "auto"|언어 코드.
 *  options.hint: 페이지 lang 속성·OCR 언어에서 온 원문 언어 힌트(없으면 null).
 *  options.nativeFirst: 내장 번역 우선 사용 여부. options.isCancelled(): 취소 확인. options.onProgress(done,total): 실제 진행.
 *  돌려주는 texts는 입력과 같은 길이이며 실패·미지원 항목은 null(빈 문자열로 꾸미지 않음). langs는 판별 결과|"unknown". */
async function translateBatch(texts, target, source, options = {}) {
  const { hint = null, nativeFirst = false, isCancelled = () => false, onProgress = () => {} } = options;
  const results = new Array(texts.length).fill(null);
  const langs = new Array(texts.length).fill(null);
  const missing = [];
  if (!TARGET_LANGS.includes(target)) return { texts: results, langs, missing: [], warning: "" };
  const src = source === "zh-Hant" ? "zh" : source;
  let done = 0;
  for (let i = 0; i < texts.length; i += 1) {
    if (isCancelled()) throw Object.assign(new Error(""), { code: "cancelled" });
    const text = texts[i];
    const lang = src === "auto" ? BarobogiLangDetect.detectSourceLanguage(text, hint) : src;
    langs[i] = lang;
    if (lang === "unknown") { missing.push("language-detection"); done += 1; onProgress(done, texts.length); continue; }
    if (!LOCAL_LANGS.includes(lang)) { missing.push("unsupported-source"); done += 1; onProgress(done, texts.length); continue; }
    if (lang === target) { results[i] = text; done += 1; onProgress(done, texts.length); continue; }
    const native = nativeFirst ? nativeEntry(lang, target).translator : null;
    try {
      if (native) {
        results[i] = await native.translate(text);
      } else if (LOCAL_LANGS.includes(target)) {
        results[i] = await BarobogiLocalModel.translateText(text, lang, target, {
          isCancelled, onChunk: (chunkDone, chunkTotal) => onProgress(done + chunkDone / Math.max(1, chunkTotal), texts.length)
        });
      } else {
        missing.push("zh-Hant");
      }
    } catch (error) {
      if (error && error.code === "cancelled") throw error;
      if (error && (error.code === "model_missing")) { missing.push("model"); break; }
      if (error && (error.code === "load_failed" || error.code === "load_stalled")) { missing.push("model-error"); break; }
      missing.push("partial");
      results[i] = null;
    }
    done += 1;
    onProgress(done, texts.length);
  }
  return { texts: results, langs, missing: [...new Set(missing)], warning: warningFor(missing) };
}

globalThis.BarobogiTranslate = {
  TARGET_LANGS, SOURCE_LANGS, LOCAL_LANGS, MISSING_TEXT, warningFor,
  hasTranslatorApi, prepareNative, adoptNativeIfAvailable, nativeSnapshot,
  translateBatch
};
