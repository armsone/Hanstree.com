// 바로보기 웹 번역 — 공통 로컬 번역 모델 Worker(module). 엔진 문서가 만들고, 멈추거나 취소가 필요하면 terminate 후 다시 만든다.
// - Transformers.js 3.8.1(패키지에 포함, ONNX Runtime Web WASM 단일 스레드 CPU)로 M2M100 418M q8 모델을 실행한다.
// - 모델 파일은 다운로드 Worker가 검증해 Cache API에 넣어 둔 것만 읽는다. 이 Worker는 네트워크로 아무것도 요청하지 않는다:
//   확장 패키지 밖 http(s) 요청은 fetch 단계에서 404로 막고, 허용 목록에 없는 캐시 키는 찾지 않는다.
// - 번역 요청은 한 번에 한 조각(chunk)씩 받는다. 생성한 토큰 수를 실제 진행 신호로 보낸다(가짜 진행률 없음).
import "./model-spec.js";
import { pipeline, env } from "../vendor/transformers/transformers.min.js";

const SPEC = globalThis.BAROBOGI_MODEL;
const OWN_ORIGIN = self.location.origin;
const ALLOWED = new Set(SPEC.files.map((file) => globalThis.BAROBOGI_MODEL_URL(file.path)));
let blockedRequests = 0;

const nativeFetch = self.fetch.bind(self);
self.fetch = (input, init) => {
  const url = typeof input === "string" ? input : (input && input.url) || String(input);
  if (url.startsWith(OWN_ORIGIN + "/") || url.startsWith("blob:") || url.startsWith("data:")) return nativeFetch(input, init);
  blockedRequests += 1;
  return Promise.resolve(new Response(null, { status: 404, statusText: "blocked by Barobogi (model files are read from verified cache only)" }));
};

let cache = null;
env.allowLocalModels = false;
env.allowRemoteModels = true; // 원격 URL은 캐시 키 계산에만 쓰인다(실제 요청은 위 fetch에서 막힘).
env.remoteHost = SPEC.host;
env.remotePathTemplate = "{model}/resolve/{revision}/";
env.useBrowserCache = false;
env.useFSCache = false;
env.useCustomCache = true;
env.customCache = {
  async match(key) {
    const url = typeof key === "string" ? key : key && key.url;
    if (!ALLOWED.has(url)) return undefined;
    cache = cache || (await caches.open(SPEC.cacheName));
    return cache.match(url);
  },
  async put() { /* 이 Worker는 캐시에 쓰지 않는다(다운로드 Worker만 검증 뒤 쓴다). */ }
};
env.backends.onnx.wasm.wasmPaths = {
  mjs: new URL("../vendor/transformers/ort-wasm-simd-threaded.jsep.mjs", import.meta.url).href,
  wasm: new URL("../vendor/transformers/ort-wasm-simd-threaded.jsep.wasm", import.meta.url).href
};
env.backends.onnx.wasm.numThreads = 1; // 교차 출처 격리(SharedArrayBuffer) 없이 동작하도록 단일 스레드
env.backends.onnx.wasm.proxy = false;

let translator = null;
let loading = null;

function load() {
  if (translator) return Promise.resolve();
  if (loading) return loading;
  loading = (async () => {
    const ready = await (await caches.open(SPEC.cacheName)).match(globalThis.BAROBOGI_MODEL_READY_URL);
    if (!ready) throw Object.assign(new Error("모델 파일이 아직 준비되지 않았습니다(최초 다운로드 필요)."), { code: "model_missing" });
    translator = await pipeline("translation", SPEC.id, {
      revision: SPEC.revision,
      dtype: SPEC.dtype,
      device: "wasm",
      progress_callback: (info) => {
        if (!info || typeof info !== "object") return;
        self.postMessage({
          type: "loadProgress", status: String(info.status || ""), file: typeof info.file === "string" ? info.file : "",
          loaded: Number.isFinite(info.loaded) ? info.loaded : null, total: Number.isFinite(info.total) ? info.total : null
        });
      }
    });
  })();
  loading.catch(() => { loading = null; });
  return loading;
}

class TokenCounter {
  constructor(jobId) { this.jobId = jobId; this.count = 0; this.last = 0; }
  put() {
    this.count += 1;
    const now = Date.now();
    if (now - this.last < 400) return;
    this.last = now;
    self.postMessage({ type: "tokens", jobId: this.jobId, count: this.count });
  }
  end() {}
}

async function translate({ jobId, text, src, tgt, maxNewTokens }) {
  await load();
  const streamer = new TokenCounter(jobId);
  const output = await translator(text, {
    src_lang: src, tgt_lang: tgt, max_new_tokens: maxNewTokens, num_beams: 1, do_sample: false, streamer
  });
  const first = Array.isArray(output) ? output[0] : output;
  return typeof first?.translation_text === "string" ? first.translation_text : "";
}

self.onmessage = (event) => {
  const message = event.data || {};
  if (message.type === "load") {
    load().then(
      () => self.postMessage({ type: "loaded", blockedRequests }),
      (error) => self.postMessage({ type: "loadError", code: error.code || "load_failed", message: String(error.message || error), blockedRequests })
    );
  } else if (message.type === "translate") {
    translate(message).then(
      (text) => self.postMessage({ type: "result", jobId: message.jobId, text }),
      (error) => self.postMessage({ type: "error", jobId: message.jobId, code: error.code || "translate_failed", message: String(error.message || error) })
    );
  }
};
