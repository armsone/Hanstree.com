// 바로보기 웹 번역 — 공통 로컬 번역 모델 고정 명세(엔진 문서·다운로드 Worker·모델 Worker가 함께 쓴다).
// 출처: https://huggingface.co/Xenova/m2m100_418M (facebook/m2m100_418M의 ONNX 변환본, 원본 MIT)
// 이 목록에 있는 파일만, 이 고정 리비전 URL에서만 내려받고 불러온다. 크기·해시는 Hugging Face API 메타데이터
// (siblings[].size, lfs.sha256, 일반 파일은 git blob SHA-1)에서 옮겨 적었다. 다운로드 요청에는 번역할 글자·이미지를 담지 않는다.
globalThis.BAROBOGI_MODEL = Object.freeze({
  id: "Xenova/m2m100_418M",
  revision: "9c374f0b7aca709787cea97b047bfbbd1559d177",
  host: "https://huggingface.co/",
  cacheName: "barobogi-m2m100-418m-9c374f0b",
  dtype: "q8",
  files: Object.freeze([
    { path: "config.json", size: 908, gitSha1: "4f466cf3049e59ef8bb5de9b67f4275fa8f7257a" },
    { path: "generation_config.json", size: 233, gitSha1: "434f8e78dc0d584e14d179bd47be7e329df86cb0" },
    { path: "special_tokens_map.json", size: 1559, gitSha1: "57f8d1552234eca0ba0dfb591805015ccb69ce74" },
    { path: "tokenizer_config.json", size: 1813, gitSha1: "b177ccaad20b2538951a05fcaf7093bd2b0a92b1" },
    { path: "tokenizer.json", size: 7988527, gitSha1: "cd68f923c35fc0da05d4bb83125bdcbe6ff9211b" },
    { path: "onnx/encoder_model_quantized.onnx", size: 287856370,
      sha256: "13a94e354a9140764eb81102d77d3ec6952d796e6f113c651eeb3c3443da0386" },
    { path: "onnx/decoder_model_merged_quantized.onnx", size: 344128178,
      sha256: "007654bcabb6cea6fd3bde34ce933137b431330b3755781145d7b6906270b45a" }
  ]),
  // M2M100이 실제로 지원하고 이 확장 UI가 다루는 언어 코드(모델 토큰 __ko__ 등과 같다).
  languages: Object.freeze(["ko", "en", "ja", "zh"])
});

globalThis.BAROBOGI_MODEL_URL = (path) =>
  `${BAROBOGI_MODEL.host}${BAROBOGI_MODEL.id}/resolve/${BAROBOGI_MODEL.revision}/${path}`;

globalThis.BAROBOGI_MODEL_TOTAL = BAROBOGI_MODEL.files.reduce((sum, file) => sum + file.size, 0);

// 완료·검증 표시용 Cache 키(네트워크로 요청하지 않는 키일 뿐이다). Cache API는 URL의 # 조각을 무시하므로 쿼리로 구분한다.
globalThis.BAROBOGI_MODEL_READY_URL = BAROBOGI_MODEL_URL(".barobogi-complete");
globalThis.BAROBOGI_VERIFIED_SUFFIX = "?barobogi-verified=1";
