# 바로보기 웹 번역(Windows Chrome·Naver Whale) 0.1.0 — 배포 전 후보

Windows의 **Chrome**과 **네이버 웨일(Whale)**에서 쓰는 독립 확장(Manifest V3)입니다. 이 확장의 핵심은
**이미지 속 글자 번역**입니다. 웹페이지 이미지 속 글자(특히 **일본어 세로쓰기**)를 이 PC 안에서 인식(OCR)하고 번역해,
원래 이미지 위 같은 자리에 겹쳐 그립니다. 계정·API 키·별도 EXE·로컬 서버가 없고, 번역할 글자나 이미지를 서버로 보내지 않습니다.

페이지의 일반 글자는 브라우저 자체 번역(Chrome: 마우스 오른쪽 → "한국어로 번역", Whale: 주소창의 번역 버튼)으로
번역하는 것을 권장합니다. 이 확장은 **기본값이 "이미지 전용"**이라 브라우저가 번역해 둔 페이지 글자를 덮어쓰지 않습니다.
원하면 팝업의 "페이지 글자도 이 확장으로 번역"을 켤 수 있습니다(선택).

## 현재 범위·목표

- 이 Windows 빌드는 작업 시작 시점의 Mac 앱 0.7.69 **미커밋 BrowserExtension 소스**(DOM/이미지 처리, 취소, 렌더러, `sampleColors`)를
  그대로 참고해 이식했습니다. 기술 보고서에 적힌 0.7.45는 더 앞선 스냅샷으로, 설계 방향을 참고한 것일 뿐 실제로 가져온 작업 소스가
  아닙니다. 이후 Mac 쪽에서 계속 진행 중인 변경은 따라가지 않았고, 네이티브 OCR(Apple Vision) 및 Mac과의 완전한 기능 동일성은
  보장하지 않습니다. 배포 목적지는 hanstree.com/apps/barobogi입니다(웹사이트 게시는 별도 작업).
- 이번 0.1.0 후보의 목표: Chrome·Whale 두 브라우저에서 같은 **공통 로컬 번역 엔진**으로 이미지 번역이 동작하는 설치 가능한
  패키지 두 개(`output/Barobogi-Windows-Chrome-0.1.0.zip`, `output/Barobogi-Windows-Whale-0.1.0.zip`).
- 범위 밖: 데스크톱 EXE, 서버, 결제, 다른 Windows 프로그램 위 오버레이.

## 동작 방식(채택한 구성)

| 부분 | 구성 | 비고 |
|---|---|---|
| 번역(기본, 두 브라우저 공통) | **M2M100 418M**(Meta, 2020, MIT) ONNX q8 양자화본 `Xenova/m2m100_418M`, 리비전 `9c374f0b7aca709787cea97b047bfbbd1559d177` 고정 | Transformers.js 3.8.1 + ONNX Runtime Web(WASM, CPU **단일 스레드**)을 패키지에 포함. 전용 Worker에서 실행 |
| 번역(선택, Chrome) | Chrome 내장 Translator API | "내장 번역 우선"을 켜고, 엔진 창에서 그 언어 조합을 준비해 실제 인스턴스가 만들어졌을 때만 사용 |
| 원문 언어 자동 감지 | 유니코드 문자 종류(한글·가나·한자·라틴) + **franc-min 6.2.0**(MIT, 패키지 포함) + 페이지 `lang`·OCR 언어 힌트 | 근거가 부족하면 "판별 불가"로 남기고 번역하지 않음(원문 언어를 직접 고를 수 있음) |
| 이미지 글자 인식 | **Tesseract.js 7.0.0**(WASM) + 패키지 포함 언어 데이터(일본어 가로·**세로(jpn_vert)**·영어·중국어 간체·한국어) | 사용자가 고른 OCR 언어 하나로 인식(자동 판별 안 함). 세로쓰기 프로필은 결과를 세로로 그림 |
| 엔진 문서 | `engine.html` — Chrome은 **사이드패널 또는 엔진 창**, Whale은 **엔진 창**(확장이 여는 좁은 창) | Whale 공식 문서상 `action`과 `sidebar_action`을 함께 쓸 수 없어, 툴바 팝업을 유지하고 사이드바 대신 엔진 창을 씀 |

지원 언어(번역): 한국어·영어·일본어·중국어. 공통 모델은 중국어를 하나의 `zh`로 다루므로 **번체 출력은 보장하지 않습니다**.
"중국어(번체)" 번역 대상은 Chrome 내장 번역을 준비한 경우에만 동작하고, 그렇지 않으면 "지원하지 않음" 경고를 냅니다.
원문 중국어(간체·번체)는 모두 `zh`로 모델에 넣습니다.

## 설치

두 브라우저 모두 "압축해제된 확장 프로그램" 방식(개발자 모드)입니다. 브라우저마다 **해당 브라우저용 ZIP**을 쓰세요.

### Chrome

1. `Barobogi-Windows-Chrome-0.1.0.zip`을 원하는 폴더에 압축을 풉니다(`manifest.json`이 들어 있는 폴더).
2. 주소창에 `chrome://extensions` 입력 → 오른쪽 위 **개발자 모드** 켜기.
3. **압축해제된 확장 프로그램을 로드합니다** → 압축을 푼 폴더 선택. (Chrome 116 이상)

### Naver Whale

1. `Barobogi-Windows-Whale-0.1.0.zip`을 원하는 폴더에 압축을 풉니다.
2. 주소창에 `whale://extensions` 입력 → **개발자 모드** 켜기.
3. **압축해제된 확장앱을 로드**하는 버튼(Whale 버전에 따라 이름이 조금 다를 수 있음) → 압축을 푼 폴더 선택.

압축을 푼 폴더는 지우지 마세요(브라우저가 그 폴더에서 확장을 실행합니다).

## 처음 실행: 모델 내려받기(설치 후 한 번)

1. 설치하면 **번역 엔진 창**이 한 번 자동으로 열립니다(안 열리면 툴바의 바로보기 아이콘 → "번역 엔진 창 열기").
2. **"모델 내려받기 (약 640MB)"**를 누릅니다. 브라우저가 `huggingface.co`와 그 다운로드 서버(`*.hf.co`) 접근 허용을 물으면
   허용하세요(선택 권한이며, 거절해도 공개 다운로드로 시도합니다).
3. 받은 바이트·전체 바이트(639,977,588바이트)와 진행 막대가 표시됩니다. 언제든 **내려받기 취소**할 수 있고,
   실패하면 **다시 시도/이어서 내려받기**로 검증을 마친 파일은 건너뛰고 나머지만 받습니다.
4. 모든 파일의 크기·해시(큰 ONNX 파일은 SHA-256, 작은 JSON은 git blob SHA-1)가 고정 메타데이터와 맞을 때만 "저장됨"이 되고,
   이어서 모델을 메모리에 불러옵니다("모델을 메모리에 불러오는 중…" → "준비됨").
5. 다음부터는 다시 받지 않습니다. 엔진 창을 열면 저장된 모델을 불러오기만 합니다.

받는 파일(고정 리비전 URL `https://huggingface.co/Xenova/m2m100_418M/resolve/9c374f0b…/`의 이 7개만):
`onnx/encoder_model_quantized.onnx`(287,856,370바이트), `onnx/decoder_model_merged_quantized.onnx`(344,128,178바이트),
`tokenizer.json`(7,988,527바이트), `config.json`, `generation_config.json`, `tokenizer_config.json`, `special_tokens_map.json`.
다운로드 요청에는 쿠키·리퍼러·번역할 글자·이미지가 들어가지 않습니다. 모델은 확장 ZIP에 포함하지 않습니다.

**Chrome과 Whale은 저장소를 공유하지 않습니다.** 두 브라우저에 모두 설치하면 각각 한 번씩 받습니다(총 약 1.28GB 다운로드,
디스크도 각각 사용). 모델을 지우려면 엔진 창의 "모델 캐시 삭제"를 누르거나 확장을 제거하세요.

## 사용법

1. **번역 엔진 창을 열어 둡니다**(툴바 아이콘 → "번역 엔진 창 열기", Chrome은 "Chrome 사이드패널로 열기"도 가능).
   엔진 창을 닫으면 번역이 멈추고 "번역 엔진이 꺼져 있습니다" 안내가 뜹니다(가짜로 성공한 척하지 않음).
2. 번역할 웹 탭으로 돌아가 툴바 아이콘 → **이미지 글자** 언어를 고릅니다(예: 만화·세로 글이면 "일본어(세로쓰기)").
3. **번역 시작**을 누르면 지금 화면에 보이는 이미지들을 캡처·인식·번역해 이미지 위에 겹쳐 그립니다.
   번역 대상은 팝업을 연 그 웹 탭이며, 엔진 창이 열려 있어도 바뀌지 않습니다.
4. **원문 보기**로 언제든 원래 화면으로 되돌립니다(이 확장이 바꾼 것만 되돌림).

- 수동 "번역 시작"은 누른 시점에 보이는 부분만 번역합니다. 스크롤을 따라 계속 번역하려면 "모든 사이트에서 자동 번역"을 켜세요
  (브라우저가 모든 사이트 접근 권한을 묻습니다. 선택 권한).
- 엔진 창의 "처리 현황"에 실제 진행(이미지 인식 n/m, 글자 번역 n/m)이 표시됩니다. 느린 PC에서는 한 이미지에 시간이 걸릴 수
  있으며, 고정 60초에 끊지 않고 엔진이 실제로 진행하는 동안 기다립니다. 한 조각에서 2분 동안 새 토큰이 나오지 않으면
  번역 Worker를, 한 영역 인식이 2분을 넘기면 OCR Worker를 다시 만들어 대기열을 풉니다. 요청 하나의 절대 상한은 20분입니다.
- 엔진 창(또는 사이드패널)이 여러 개 열려 있으면 가장 최근에 연 하나만 요청을 처리하고, 나머지는 "대기 중"으로 표시되며
  모델을 불러오지 않습니다. 처리 중인 창을 닫으면 그 창으로 보낸 요청만 실패하고, 남은 창이 이어받습니다.

## 개인정보와 처리 경계

- 번역·OCR은 모두 이 PC 안의 엔진 창(전용 Worker)에서 처리합니다. 외부 번역 서버를 쓰지 않습니다.
- 네트워크 사용은 **처음 모델 내려받기**뿐이며, 고정 목록의 모델 데이터 파일만 받습니다. 번역 모델 Worker는 확장 패키지 밖으로
  요청을 보내지 못하게 막혀 있고(검증된 캐시에서만 읽음), 실행 코드(JS·Worker·WASM)는 모두 패키지 안의 것만 씁니다.
- 저장하는 것: 설정값(`chrome.storage.local` — 번역/원문/OCR 언어, 이미지·페이지 글자 번역 여부, 글꼴, 자동 번역, 내장 번역 우선)과
  모델 파일(Cache API). 페이지 글자·이미지·번역 결과·방문 기록은 저장하지 않습니다(엔진 창 메모리에만 잠시, 창을 닫으면 사라짐).
- 화면 캡처는 "번역 시작"/자동 번역 때 보이는 탭만, 메모리에서 잠깐 쓰고 버립니다.

## 권한

- 필수: `activeTab`, `scripting`(사용자가 누른 탭에만 번역 스크립트·캡처), `storage`(설정값), `unlimitedStorage`(약 640MB 모델이
  저장소 정리로 지워지지 않게), Chrome 패키지만 `sidePanel`. Whale 패키지에는 `sidePanel`·`side_panel`이 없습니다.
- 선택(사용자가 누를 때만 요청): `<all_urls>`(모든 사이트 자동 번역), `https://huggingface.co/*`·`https://*.hf.co/*`(모델 내려받기).

## 실제 한계(확인된 사실과 확인하지 못한 것)

- **Windows 실기기 동작은 아직 확인하지 않았습니다.** 이 패키지는 macOS에서 소스·manifest·자원·문법 수준으로만 검증했습니다.
  Windows Chrome·Whale에서의 설치, 모델 다운로드 완료, 모델 불러오기, 번역 속도, 메모리·디스크 사용량은 실제 PC에서 확인해야 하며,
  이 문서는 측정하지 않은 속도·품질 수치를 적지 않습니다. 모델 파일 크기(639,977,588바이트)만 확인된 숫자입니다.
- **번역 품질:** M2M100 418M은 2020년 공개된 비교적 작은 다국어 모델입니다. 최신 클라우드 번역기(Google·DeepL 등)와 같은 품질을
  기대할 수 없고, 특히 구어체·만화 대사·짧은 문구에서 어색할 수 있습니다. Transformers.js 3.8.1은 빔 서치를 지원하지 않아
  탐욕(greedy) 디코딩으로 번역합니다.
- **속도·메모리:** CPU 단일 스레드 WASM입니다(교차 출처 격리가 필요 없게 하려고 다중 스레드를 쓰지 않음). 모델을 처음 메모리에
  불러올 때와 긴 글을 번역할 때 시간이 걸리고, 엔진 창이 상당한 메모리를 씁니다(실측 전).
- **OCR 품질은 Mac 버전(Apple Vision)과 다릅니다.** Tesseract가 주는 상자는 낱말(세로쓰기에서는 대개 열 조각) 단위이지 Mac처럼
  글자 하나하나의 상자가 아니어서, 원문 가림과 글자 크기 추정이 더 거칩니다. 세로쓰기 프로필(jpn_vert, PSM 5)은 이미지 영역을
  "세로로 정렬된 한 덩어리 글"로 읽으므로 가로 글이 섞인 이미지에서는 결과가 나쁩니다. 그럴 땐 OCR 언어를 바꿔 다시 번역하세요.
- **원문 가림은 단색 덮개**입니다(문단 대표 배경색). 그림결 복원은 없습니다.
- 인식 범위는 **지금 화면에 보이는 이미지**뿐이고, 브라우저 밖 다른 프로그램 화면은 번역할 수 없습니다.
- 자동 감지: 가나 없는 짧은 한자 문구(8자 미만)는 페이지 `lang`·OCR 언어 힌트가 없으면 판별하지 않습니다. 영어가 아닌 라틴 문자
  언어(프랑스어 등)는 번역하지 않습니다.
- Chrome 내장 Translator는 선택 기능입니다. Whale에서 이 API가 보이더라도 동작을 확인하지 않았다고 표시합니다.
- 엔진 창을 최소화해도 요청을 처리하도록 설계했지만(살아 있음 신호 150초 여유), 브라우저의 백그라운드 절전 정책에 따라 느려질 수
  있습니다. 엔진 창은 작게 띄워 두는 것을 권장합니다.

## 폴더 구조

```
extension/                  확장 소스(Chrome manifest). build.sh가 Whale manifest를 따로 만든다
  manifest.json
  background.js             배경 서비스 워커: 요청 검증·캡처·엔진 포트 관리(여러 엔진 문서, 살아 있음 신호, 대기열 상한)·엔진 창
  content.js                페이지 내용 스크립트: 이미지 후보·캡처 요청·이미지 위 번역 배치(세로쓰기 포함)·원문 복원
  popup.html/js/css         팝업(두 브라우저 공통)
  engine.html, engine.css   엔진 문서(Chrome 사이드패널 / 엔진 창)
  engine/page.js            엔진 문서 제어: 요청 대기열·취소·진행 표시·모델/OCR/내장 번역 UI
  engine/model-spec.js      고정 모델 명세(리비전·파일 7개·크기·해시)
  engine/download-worker.js 모델 다운로드 Worker(스트리밍 SHA-256, Cache API 저장)
  engine/sha256.js          스트리밍 SHA-256
  engine/model-worker.js    번역 모델 Worker(module, Transformers.js, 네트워크 차단)
  engine/local-model.js     다운로드·불러오기·조각 번역·정지 감시 제어
  engine/langdetect.js      원문 언어 판별(franc-min + 문자 종류 + 힌트)
  engine/translate.js       번역 라우터(로컬 모델 기본, Chrome 내장 번역 선택)
  engine/ocr.js             Tesseract.js 래퍼 + 배경색 표본화
  vendor/transformers/      Transformers.js 3.8.1 번들 + ONNX Runtime Web WASM(.mjs·.wasm)
  vendor/franc/             franc-min 6.2.0 번들(esbuild IIFE)
  vendor/licenses/          제3자 라이선스(Transformers.js Apache-2.0, ONNX Runtime MIT·제3자 고지, franc-min 등 MIT, M2M100/fairseq MIT)
  ocr/                      Tesseract.js·코어·언어 데이터(+라이선스)
  fonts/, icons/
scripts/
  fetch-ocr-assets.sh        OCR 자원을 공식 npm에서 받음
  fetch-local-engine-assets.sh 로컬 번역 엔진 실행 파일·franc-min·라이선스를 공식 npm·저장소에서 받음(모델 가중치는 받지 않음)
  build.sh                   문법·자원·원격 코드·모델 명세 검사 + Chrome/Whale ZIP 두 개 생성
output/                      배포용 ZIP
```

## 빌드 방법(재현 가능)

```sh
cd Barobogi-Win
bash scripts/fetch-ocr-assets.sh            # OCR 자원(최초 1회)
bash scripts/fetch-local-engine-assets.sh   # 로컬 번역 엔진 자원(최초 1회)
bash scripts/build.sh                       # 검사 + output/Barobogi-Windows-Chrome-0.1.0.zip, Barobogi-Windows-Whale-0.1.0.zip
```

테스트 코드·러너는 두지 않았습니다. `build.sh`의 검사(문법, 참조 파일, 원격 실행 코드 없음, 모델 Worker의 로컬 WASM 경로·
단일 스레드·네트워크 차단 설정, 고정 모델 명세, 브라우저별 manifest 권한)가 자동 검증의 전부입니다.

## 라이선스가 있는 포함 자산

- 번역 모델(내려받는 데이터): facebook/m2m100_418M — MIT(모델 카드 license: mit, 원본 fairseq 저장소 LICENSE를
  `vendor/licenses/m2m100-fairseq-LICENSE.txt`에 동봉). ONNX 변환본 Xenova/m2m100_418M.
- `vendor/transformers/` — @huggingface/transformers 3.8.1(Apache-2.0), 번들 안 onnxruntime-web 1.22.0-dev(MIT, 제3자 고지 동봉).
- `vendor/franc/` — franc-min 6.2.0과 의존 패키지 trigram-utils·n-gram·collapse-white-space(MIT).
- `ocr/` — Tesseract.js·tesseract.js-core(Apache-2.0), 언어 데이터(@tesseract.js-data, Apache-2.0).
- `fonts/` — 나눔고딕·나눔명조·나눔펜(OFL-1.1), 조선궁서체(조선일보 무료 배포 글꼴, 동봉 라이선스).

## 소스 참고(Mac 작업본에서 가져온 설계·코드)

- `BrowserExtension/shared/content.js` — DOM 글자 수집·복원, 이미지 후보 탐지, 이미지 위 번역 배치(글자 크기·세로쓰기·무리짓기),
  동적 페이지 대응, 세대(epoch) 무효화.
- `BrowserExtension/shared/background.js` — 자동 번역 세대 관리, 탭별 요청 추적·취소, 캡처 빈도 제한, 응답 검증 패턴.
- `Sources/ImageTextRecognizer.swift`(`sampleColors`) — 배경·글자색 다수결 표본화를 Canvas로 이식.
