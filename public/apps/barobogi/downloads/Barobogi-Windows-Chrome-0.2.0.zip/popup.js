"use strict";
// 바로보기 웹 번역 팝업(Chrome·Whale 공통): 번역 시작/원문 보기, 언어·OCR 언어·글꼴·이미지/페이지 글자 설정,
// 번역 엔진 창 열기(두 브라우저 공통), Chrome에서는 사이드패널로 열기도 제공한다.
// 번역 대상 탭은 팝업을 연 창의 활성 웹 탭으로 고정한다(엔진 창을 열어도 바뀌지 않음).
const $ = (id) => document.getElementById(id);
const ALL_URLS = "<all_urls>";
let tabId = null;
let origin = null;

function showError(message) {
  $("error").textContent = message || "";
  $("error").hidden = !message;
}

async function call(message) {
  const response = await chrome.runtime.sendMessage({ ...message, tabId });
  if (!response || response.ok !== true) throw new Error(response?.message || "요청을 처리하지 못했습니다.");
  return response;
}

// 팝업 갱신: 모델 확인·권한 요청·내려받기·불러오기·페이지 번역이 진행 중일 때(그리고 내려받기를 마쳤지만 아직 불러오기 전일 때)
// 1초마다 다시 묻는다. 요청이 잠깐 실패하면 같은 타이머 하나로 1·2·4·8초(최대 10초) 간격을 늘려 다시 묻는다. 타이머는 하나만 두고
// 새로 걸기 전에 지우며, 팝업이 닫히면(pagehide) 지운다. 예전에는 페이지 번역 중일 때만 다시 물어서, 엔진 창에서 내려받는 동안
// 팝업 숫자가 열었을 때 값에 멈춰 "아무것도 안 하는 것처럼" 보였다.
const POLL_MS = 1000;
const POLL_MAX_MS = 10000;
let pollTimer = 0;
let pollFailures = 0;
let pollErrorShown = false; // 갱신 실패로 띄운 오류만 다음 성공 때 지운다(사용자 동작 오류는 남김)
let refreshing = false;
let refreshAgain = false;
let closed = false;

function schedule(ms) {
  clearTimeout(pollTimer);
  pollTimer = 0;
  if (!closed) pollTimer = setTimeout(refresh, ms);
}
window.addEventListener("pagehide", () => { closed = true; clearTimeout(pollTimer); pollTimer = 0; });

function renderModelBox(state, session) {
  const box = $("modelBox");
  const engine = state.engine;
  let stage = "", detail = "", warn = "", percent = null, cta = "번역 엔진 창 열기 →", poll = false, visible = true;
  if (!engine || !engine.connected) {
    stage = "번역 엔진 꺼짐";
    detail = session
      ? "모델을 내려받던 번역 엔진 창이 닫혀 내려받기가 멈췄습니다. 엔진 창을 다시 열고 '이어서 내려받기'를 누르세요(검증된 파일은 건너뛰고, 받던 파일은 처음부터 다시 받습니다)."
      : "번역·이미지 인식·모델 내려받기는 번역 엔진 창이 열려 있어야 동작합니다.";
  } else if (engine.error) {
    stage = "번역 엔진 응답 없음";
    detail = "엔진 창이 바쁘거나 멈췄을 수 있습니다. 잠시 뒤 다시 확인합니다.";
    poll = true;
  } else if (engine.model) {
    const view = BarobogiModelStatus.describe(engine.model);
    stage = view.stage;
    detail = [view.text, view.file, view.bytes].filter(Boolean).join(" ");
    warn = view.warn;
    percent = Number.isFinite(view.percent) ? view.percent : null;
    // 캐시는 완료됐지만 아직 불러오기 전(idle)인 짧은 틈에도 계속 갱신해 "불러오는 중 → 준비됨"을 놓치지 않는다.
    poll = view.busy || (engine.model.cache === "complete" && engine.model.runtime === "idle");
    if (view.needsDownload) cta = "번역 엔진 창에서 모델 내려받기 →";
    else if (view.busy) cta = "번역 엔진 창 보기 →";
    visible = !view.ready;
  }
  box.hidden = !visible;
  $("modelStage").textContent = stage;
  $("modelDetail").textContent = detail;
  $("modelWarn").textContent = warn;
  $("modelWarn").hidden = !warn;
  $("modelProgressRow").hidden = percent === null;
  if (percent !== null) {
    $("modelProgress").value = percent;
    $("modelProgress").setAttribute("aria-valuetext", `${stage} ${percent}%`);
    $("modelPercent").textContent = `${percent}%`;
  }
  $("modelCta").textContent = cta;
  return poll;
}

function render(state, session) {
  const engine = $("engine");
  const model = state.engine?.model;
  const view = model ? BarobogiModelStatus.describe(model) : null;
  if (!state.engine || !state.engine.connected) {
    engine.textContent = "엔진 꺼짐";
    engine.className = "pill bad";
  } else if (state.engine.error) {
    engine.textContent = "엔진 응답 없음";
    engine.className = "pill bad";
  } else if (view && view.downloading) {
    engine.textContent = Number.isFinite(view.percent) ? `모델 받는 중 ${view.percent}%` : "모델 받는 중";
    engine.className = "pill";
  } else if (model && model.otherWindow && model.cache !== "complete") {
    engine.textContent = Number.isFinite(view.percent) ? `다른 창에서 받는 중 ${view.percent}%` : "다른 창에서 받는 중";
    engine.className = "pill";
  } else if (model && model.download === "permission") {
    engine.textContent = "권한 요청 중";
    engine.className = "pill";
  } else if (model && model.cache !== "complete") {
    engine.textContent = model.cache === "checking" || model.cache === "unknown" ? "모델 확인 중" : "모델 필요";
    engine.className = model.cache === "checking" || model.cache === "unknown" ? "pill" : "pill bad";
  } else if (model && model.runtime === "loading") {
    engine.textContent = "모델 불러오는 중";
    engine.className = "pill";
  } else if (model && model.runtime === "ready") {
    engine.textContent = "엔진 준비됨";
    engine.className = "pill ok";
  } else {
    engine.textContent = "엔진 켜짐";
    engine.className = "pill";
  }
  const modelPoll = renderModelBox(state, session);
  $("target").value = state.settings.target;
  $("source").value = state.settings.source;
  $("ocrLang").value = state.settings.ocrLang;
  $("pageText").checked = state.settings.pageText === true;
  $("fontStyle").value = state.settings.fontStyle;
  $("images").checked = state.settings.images !== false;
  $("autoAll").checked = state.settings.automaticEnabled === true;
  $("translate").disabled = tabId === null;
  const isTranslated = state.page?.view === "translated";
  $("translate").classList.toggle("active", isTranslated);
  $("original").classList.toggle("active", !isTranslated && !!state.page);
  const running = state.page?.running === true;
  $("spinner").hidden = !running;
  $("translateSpinner").hidden = !running;
  let status = "";
  if (state.page) {
    status = state.page.error || state.page.warning || state.page.status || "";
  } else if (!origin) {
    status = "이 페이지는 번역할 수 없습니다(브라우저 내부 페이지·확장 스토어·새 탭 등은 브라우저가 확장 접근을 막습니다). 일반 웹사이트(http/https)에서 사용하세요.";
  } else if (!state.engine?.connected) {
    status = "'번역 엔진 창 열기'로 엔진을 먼저 켜 주세요.";
  } else if (model && model.cache !== "complete") {
    status = "번역 엔진 창에서 로컬 번역 모델(약 640MB)을 먼저 내려받아 주세요.";
  }
  $("statusText").textContent = status;
  const inventory = state.page?.inventory;
  const parts = [];
  if (Number.isInteger(inventory?.textSentences)) parts.push(`일반 ${inventory.textSentences}문장`);
  if (Number.isInteger(inventory?.imageSentences)) parts.push(`이미지 속 ${inventory.imageSentences}문장`);
  $("summary").textContent = parts.join(" · ");
  $("summary").hidden = parts.length === 0;
  if (running || modelPoll || state.engine?.busy) schedule(POLL_MS);
}

async function refresh() {
  if (closed) return;
  if (refreshing) { refreshAgain = true; return; } // 설정 변경 직후 요청이 진행 중인 갱신에 묻히지 않게 한 번 더
  refreshing = true;
  clearTimeout(pollTimer);
  pollTimer = 0;
  try {
    const response = await call({ cmd: "popupState" });
    let session = null;
    if (!response.engine || !response.engine.connected) {
      try { session = (await chrome.storage.local.get("modelDownloadSession")).modelDownloadSession || null; } catch { session = null; }
    }
    pollFailures = 0;
    if (pollErrorShown) { pollErrorShown = false; showError(""); }
    if (!closed) render(response, session);
  } catch (error) {
    showError(error.message);
    pollErrorShown = true;
    // 일시적인 요청 실패(서비스 워커 재시작 등)로 갱신이 멈추지 않게 같은 타이머로 간격을 늘려 다시 묻는다.
    pollFailures += 1;
    schedule(Math.min(POLL_MAX_MS, POLL_MS * 2 ** (pollFailures - 1)));
  } finally {
    refreshing = false;
    if (refreshAgain && !closed) { refreshAgain = false; refresh(); }
  }
}

$("target").addEventListener("change", async (event) => {
  await call({ cmd: "setTarget", target: event.target.value }).catch((e) => showError(e.message));
  refresh();
});

$("source").addEventListener("change", async (event) => {
  await call({ cmd: "setSource", source: event.target.value }).catch((e) => showError(e.message));
  refresh();
});

$("ocrLang").addEventListener("change", async (event) => {
  await call({ cmd: "setOcrLang", ocrLang: event.target.value }).catch((e) => showError(e.message));
  refresh();
});

$("pageText").addEventListener("change", async (event) => {
  await call({ cmd: "setPageText", pageText: event.target.checked }).catch((e) => showError(e.message));
  refresh();
});

$("fontStyle").addEventListener("change", async (event) => {
  await call({ cmd: "setFontStyle", fontStyle: event.target.value }).catch((e) => showError(e.message));
  refresh();
});

$("images").addEventListener("change", async (event) => {
  await call({ cmd: "setImages", images: event.target.checked }).catch((e) => showError(e.message));
  refresh();
});

$("autoAll").addEventListener("change", async (event) => {
  const want = event.target.checked;
  showError("");
  if (!want) {
    await call({ cmd: "toggleOriginal" }).catch((e) => showError(e.message));
    refresh();
    return;
  }
  let granted = false;
  try { granted = await chrome.permissions.request({ origins: [ALL_URLS] }); } catch { granted = false; }
  if (!granted) {
    event.target.checked = false;
    showError("모든 웹사이트 접근을 허용해야 자동 번역을 켤 수 있습니다.");
    return;
  }
  try {
    await call({ cmd: "translateNow", automatic: true, trigger: "button", clickedAt: Date.now() });
  } catch (error) {
    showError(error.message);
  }
  refresh();
});

$("translate").addEventListener("click", async () => {
  showError("");
  $("translate").disabled = true;
  try {
    await call({ cmd: "translateNow", automatic: false, tabOnly: true, trigger: "button", clickedAt: Date.now() });
  } catch (error) {
    showError(error.message);
  } finally {
    $("translate").disabled = false;
    refresh();
  }
});

$("original").addEventListener("click", async () => {
  showError("");
  try { await call({ cmd: "toggleOriginal" }); } catch (error) { showError(error.message); }
  refresh();
});

async function openEngine() {
  showError("");
  try {
    await call({ cmd: "openEngine" });
    window.close();
  } catch (error) {
    showError(error.message);
  }
}
$("openEngine").addEventListener("click", openEngine);
$("modelCta").addEventListener("click", openEngine);

// 확장 안에 들어 있는 설치·사용 도움말(help.html)을 새 탭으로 연다(네트워크 사용 없음).
$("openHelp").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("help.html") }).then(() => window.close(), (error) => showError(error.message));
});
$("versionLabel").textContent = `버전 ${chrome.runtime.getManifest().version}`;

// Chrome 패키지에만 sidePanel 권한이 있다(Whale 패키지에는 없음). 사용자 클릭 직후 await 없이 바로 부른다.
if (chrome.sidePanel && typeof chrome.sidePanel.open === "function") {
  $("openSidePanel").hidden = false;
  $("openSidePanel").addEventListener("click", () => {
    if (tabId === null) return;
    chrome.sidePanel.open({ tabId }).then(() => window.close(), (error) => showError(error.message));
  });
}

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = Number.isInteger(tab?.id) ? tab.id : null;
  try {
    const url = new URL(tab?.url || "");
    origin = url.protocol === "http:" || url.protocol === "https:" ? url.origin : null;
  } catch {
    origin = null;
  }
  refresh();
})();
