"use strict";
// 바로보기 웹 번역 — 이미지 OCR 모듈(엔진 문서에서만 불러온다).
// Tesseract.js 7(WebAssembly, 패키지에 포함된 worker·core·언어 데이터만 사용, 원격 코드 없음)로 이미지 속 글자를 읽는다.
// 공식 저장소: https://github.com/naptha/tesseract.js
// 결과 문단 상자(x,y,w,h)·글자 상자(g)는 모두 "넘겨받은 그 자른 이미지" 기준 0~1 비율 좌표다.
// 실제로 검출되지 않은 상자·글자는 만들어 넣지 않는다(상자는 실제 낱말·글자 상자의 합집합).
//
// 자동(기본) 인식 전략 — 언어를 고르지 않아도 한 이미지 안의 영어·한국어·일본어·중국어(간체), 일본어 가로·세로가 섞인 글을 읽는다:
//  1) 가로 패스: "jpn+jpn_vert+kor+chi_sim+eng"(PSM 3 자동 배치). jpn 데이터에 들어 있는 하위 언어 설정(tessedit_load_sublangs
//     jpn_vert)이 실제로 동작하도록 jpn_vert 파일도 같은 Worker에 싣는다. 그래서 Tesseract가 배치 분석에서 세로 블록
//     (PT_VERTICAL_TEXT)으로 본 곳은 같은 패스 안에서 세로 모델로 읽는다.
//  2) 세로 전체 스캔: 가로 결과와 관계없이 언제나 일본어 세로 Worker(jpn_vert)로 영역 전체를 PSM 3(자동 배치)으로 한 번 더 읽는다.
//     가로 패스가 아예 블록으로 잡지 못한 세로 열(그림·잡음으로 분류된 말풍선 등)도 여기서 찾는다. 영역 전체를 PSM 5
//     ("세로 한 덩어리")로 단정해 읽지 않는다.
//  3) 세로 정밀 인식: 실제 세로 근거(Tesseract 블록 종류, 글자 상자의 위→아래 흐름, 세로로 긴 열, 세로 열을 가로로 가로질러 읽은
//     격자 모양)가 강한 곳만 최대 6곳 잘라 PSM 5로 다시 읽는다. 6곳을 넘는 후보를 큰 상자 하나로 합치지 않으며, 정밀 인식하지
//     못한 곳의 전체 스캔 결과는 그대로 후보로 남는다. 믿을 만한 가로 글이 들어 있는 곳은 PSM 5로 자르지 않는다.
//  4) 문단 나누기: Tesseract 문단 안에서 연속한 같은 문자 종류(한글 / 한자·가나 / 라틴)의 줄끼리 나누고, 한 줄 안에서도
//     크게 떨어지거나 길게 이어진 다른 문자 묶음은 나눈다. 나눈 조각마다 실제 낱말 상자 합집합·원문 힌트·가로/세로를 따로 둔다.
//  5) 병합: 겹치는 가로·세로 후보 쌍마다 따로 비교한다(묶음 전체에서 한 패스만 남기지 않음). 믿을 만한 라틴·한글 가로 글은
//     세로 후보가 지우지 못하고, 큰 쪽이 지면 통째로 지우지 않고 이긴 쪽에 걸친 낱말만 뺀다. 같은 패스 안의 겹치는 결과
//     (전체 스캔과 정밀 인식, 겹치는 잘라 읽기)는 하나만 남긴다. 가로 결과와 겹치지 않는 세로 단독 결과는 신뢰도 55 이상·
//     글자 2개 이상·한자/가나 80% 이상·실제 세로 근거가 있을 때만 남긴다.
//  Tesseract는 낱말별 언어를 알려 주지 않으므로, 원문 언어 힌트는 인식된 글자의 문자 종류(한글·가나·한자·라틴)에서 뽑는다
//  (scriptHint). 가나 없는 한자만 있는 조각은 "han"으로 남겨 엔진 문서가 같은 이미지의 가나·페이지 언어 같은 실제 근거로만 정한다.
// Worker는 최대 2개(가로·세로 슬롯)만 두고, 영역마다 다시 만들지 않는다. 사용은 잠금으로 한 번에 하나씩, PSM은 단계마다 다시 지정한다.
// 세로 단계가 실패해도 가로 결과는 버리지 않고 경고("ocr-vertical")로 알린다. 사용자 취소만 결과 전체를 버린다.

const AUTO_TESS = ["jpn", "jpn_vert", "kor", "chi_sim", "eng"]; // jpn_vert: jpn의 하위 언어(세로 블록용)로 같은 Worker에 싣는다
const VERTICAL_TESS = "jpn_vert";
// Tesseract PolyBlockType.PT_VERTICAL_TEXT. 패키지 core wasm의 _emscripten_enum_PolyBlockType_PT_VERTICAL_TEXT 함수 본문
// (i32.const 7)에서 확인한 값이고, JSON 출력의 "blocktype"은 이름이 아니라 이 숫자로 나온다(build.sh가 다시 확인).
const PT_VERTICAL_TEXT = 7;
const OCR_PROFILES = {
  auto: { label: "자동(영어·한국어·일본어·중국어 간체, 가로·세로)", auto: true, hint: null },
  jpn_vert: { label: "일본어 세로쓰기만(수동)", tess: "jpn_vert", psm: "5", vertical: true, hint: "ja" },
  jpn: { label: "일본어 가로쓰기만(수동)", tess: "jpn", psm: "3", vertical: false, hint: "ja" },
  eng: { label: "영어만(수동)", tess: "eng", psm: "3", vertical: false, hint: "en" },
  chi_sim: { label: "중국어 간체만(수동)", tess: "chi_sim", psm: "3", vertical: false, hint: "zh" },
  kor: { label: "한국어만(수동)", tess: "kor", psm: "3", vertical: false, hint: "ko" }
};
const LANG_LABEL = { jpn: "일본어", kor: "한국어", chi_sim: "중국어 간체", eng: "영어", jpn_vert: "일본어 세로" };
// Tesseract.js 준비 단계(logger status) → 화면 문구. 진행률은 단계마다 따로 0~100%이므로 전체 진행률처럼 보이지 않게 단계 이름과 함께 보인다.
const STAGE_LABEL = {
  "loading tesseract core": "OCR 엔진 코드 불러오기",
  "initializing tesseract": "OCR 엔진 시작",
  "loading language traineddata": "언어 데이터 읽기",
  "initializing api": "인식기 설정"
};
const RECOGNIZE_STALL_MS = 120000; // 한 번의 인식이 이보다 오래 걸리면 두 OCR Worker를 모두 끝내 대기열을 풀어 준다
const INIT_STALL_MS = 90000;       // Worker 준비(언어 데이터 읽기·초기화) 중 진행 신호가 이만큼 없으면 실패로 본다
const MIN_CONFIDENCE = 35;
const STRONG_V_CONFIDENCE = 55;    // 가로 결과와 겹치지 않는 세로 단독 결과의 최소 신뢰도
const PROTECTED_H_CONFIDENCE = 60; // 이 이상인 라틴·한글 가로 결과는 세로 후보가 지우지 못한다
const OVERLAP = 0.4;               // 작은 쪽 면적 대비 겹침 비율: 이 이상이면 같은 글을 두 번 읽은 것으로 본다
const MAX_VERTICAL_CROPS = 6;
const MAX_GLYPHS = 128;
const TARGET_LONG_SIDE = 1600;     // 작은 영역은 최대 2배까지 키워 인식한다(작은 글자 인식률)

const CJK = /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u;
const CJK_JOIN = /([\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}ー々〆〜、。，．！？：；「」『』（）［］【】…・])\s+(?=[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}ー々〆〜、。，．！？：；「」『』（）［］【】…・])/gu;

function baseUrl(path) { return chrome.runtime.getURL(path); }

// MARK: Worker 슬롯(가로·세로 최대 2개)

function newSlot() { return { worker: null, key: "", langs: "", pending: null, kill: null, state: "unchecked", progress: null, stage: "", message: "" }; }
const slots = { horizontal: newSlot(), vertical: newSlot() };
let generation = 0; // abort()마다 올린다: 그 전에 시작한 준비·인식 결과는 버린다
let activeProfile = "auto";
let lastError = "";
const abortWaiters = new Set();

function cancelledError() { return Object.assign(new Error(""), { code: "cancelled" }); }

function slotSnapshot(slot) {
  return { state: slot.state, progress: slot.progress, stage: slot.stage, message: slot.message, langs: slot.langs };
}

function snapshot() {
  const h = slots.horizontal, v = slots.vertical;
  const preparing = [h, v].find((s) => s.state === "preparing");
  const ready = [h, v].some((s) => s.state === "available");
  const failed = [h, v].find((s) => s.state === "error");
  return {
    state: preparing ? "downloading" : failed ? "error" : ready ? "available" : (typeof Tesseract === "undefined" ? "unsupported" : "unchecked"),
    progress: preparing ? preparing.progress : null,
    stage: preparing ? preparing.stage : "",
    message: failed ? failed.message : lastError,
    profile: activeProfile,
    horizontal: slotSnapshot(h),
    vertical: slotSnapshot(v)
  };
}

function langsLabel(langs) {
  return String(langs || "").split("+").filter(Boolean).map((code) => LANG_LABEL[code] || code).join("·");
}

/** Tesseract.createWorker를 감싸 (1) 초기화 오류를 errorHandler로 받아 거부하고 (2) 진행 신호가 끊기면 시간 초과로 거부하며
 *  (3) 취소·시간 초과 때 내부 Web Worker를 확실히 끝낸다. Tesseract.js 7은 언어 데이터 읽기·초기화가 실패하면 createWorker
 *  프로미스를 끝내지 않고 errorHandler만 부르므로, 그대로 기다리면 대기열이 영원히 막힌다. 내부 Worker 핸들은 createWorker가
 *  동기적으로 new Worker(workerPath)를 부르는 순간에만 잠시 Worker 생성자를 감싸 잡아 둔다(다른 코드에는 영향 없음). */
function spawnTesseract(langs, onProgress) {
  let captured = null;
  let settle = null;
  const failed = new Promise((_, reject) => { settle = reject; });
  failed.catch(() => {});
  let stallTimer = 0;
  let initDone = false;
  const arm = () => {
    clearTimeout(stallTimer);
    if (initDone) return;
    stallTimer = setTimeout(() => settle(Object.assign(new Error("OCR 엔진 준비가 90초 동안 진행되지 않아 중단했습니다."), { code: "ocr_init_stalled" })), INIT_STALL_MS);
  };
  arm();
  const NativeWorker = globalThis.Worker;
  let created;
  try {
    globalThis.Worker = class extends NativeWorker {
      constructor(...args) { super(...args); captured = this; }
    };
    created = Tesseract.createWorker(langs, 1 /* OEM.LSTM_ONLY */, {
      workerPath: baseUrl("ocr/worker.min.js"),
      corePath: baseUrl("ocr/tesseract-core-simd-lstm.wasm.js"),
      langPath: baseUrl("ocr/lang/"),
      workerBlobURL: false,
      gzip: true,
      cacheMethod: "none",
      errorHandler: (data) => settle(Object.assign(new Error(String(data || "OCR 엔진 오류")), { code: "ocr_error" })),
      logger: (m) => {
        if (!m || typeof m !== "object") return;
        arm();
        if (typeof onProgress === "function") onProgress(Number.isFinite(m.progress) ? Math.max(0, Math.min(1, m.progress)) : null, String(m.status || ""));
      }
    });
  } catch (error) {
    created = Promise.reject(error);
  } finally {
    globalThis.Worker = NativeWorker;
  }
  const kill = () => {
    clearTimeout(stallTimer);
    settle(cancelledError());
    try { captured && captured.terminate(); } catch { /* 이미 끝남 */ }
  };
  const promise = Promise.race([Promise.resolve(created), failed]).then(
    (worker) => { initDone = true; clearTimeout(stallTimer); return worker; },
    (error) => { kill(); throw error; }
  );
  // 이미 거부된 뒤 늦게 만들어진 Worker가 있으면 끝낸다(누수 방지).
  Promise.resolve(created).then((worker) => { promise.catch(() => worker.terminate().catch(() => {})); }, () => {});
  return { promise, kill };
}

/** 슬롯을 주어진 언어로 준비한다(PSM은 인식할 때마다 따로 지정). 같은 언어면 다시 만들지 않고, 준비 중이면 그 준비를 함께 기다린다.
 *  onProgress(slotName, fraction|null, stageLabel): 지금 준비 단계의 진행률(단계마다 0~1). */
function prepareSlot(name, langs, onProgress) {
  const slot = slots[name];
  const key = langs;
  if (slot.worker && slot.key === key && slot.state === "available") return Promise.resolve(slot.worker);
  if (slot.pending && slot.pending.key === key) return slot.pending.promise;
  const gen = generation;
  const promise = (async () => {
    if (slot.pending) { await slot.pending.promise.catch(() => {}); }
    if (gen !== generation) throw cancelledError();
    if (slot.worker && slot.key === key && slot.state === "available") return slot.worker;
    if (slot.worker) { const old = slot.worker; slot.worker = null; slot.key = ""; old.terminate().catch(() => {}); }
    if (typeof Tesseract === "undefined" || typeof Tesseract.createWorker !== "function") {
      slot.state = "error";
      slot.message = "OCR 실행 파일을 불러오지 못했습니다(패키지 손상 가능).";
      throw Object.assign(new Error(slot.message), { code: "ocr_unsupported" });
    }
    slot.state = "preparing";
    slot.langs = langs;
    slot.progress = null;
    slot.stage = "";
    slot.message = "";
    const spawned = spawnTesseract(langs, (progress, status) => {
      // 같은 Worker의 로그로 인식 진행률도 온다: 지금 인식을 기다리는 쪽(recognizeWith)에 넘긴다.
      if (/recogniz/i.test(status)) { if (typeof slot.onRecognize === "function") slot.onRecognize(progress); return; }
      if (gen !== generation) return;
      slot.stage = STAGE_LABEL[status] || status || slot.stage;
      slot.progress = progress;
      if (typeof onProgress === "function") onProgress(name, progress, slot.stage);
    });
    slot.kill = spawned.kill;
    let worker;
    try {
      worker = await spawned.promise;
      if (gen !== generation) { worker.terminate().catch(() => {}); throw cancelledError(); }
    } catch (error) {
      if (gen !== generation) throw cancelledError(); // abort() 뒤의 늦은 실패는 새 준비 상태를 건드리지 않는다
      slot.kill = null;
      slot.progress = null;
      slot.stage = "";
      if (error && error.code === "cancelled") { slot.state = "unchecked"; throw error; }
      slot.state = "error";
      slot.message = (error && error.message) || "OCR 엔진을 준비하지 못했습니다.";
      lastError = slot.message;
      throw error;
    }
    slot.kill = null;
    slot.worker = worker;
    slot.key = key;
    slot.state = "available";
    slot.progress = null;
    slot.stage = "";
    lastError = "";
    return worker;
  })();
  const entry = { key, promise };
  slot.pending = entry;
  promise.finally(() => { if (slot.pending === entry) slot.pending = null; }).catch(() => {});
  return promise;
}

function profileSlots(profile) {
  const p = OCR_PROFILES[profile] || OCR_PROFILES.auto;
  if (p.auto) return [["horizontal", AUTO_TESS.join("+"), "3"]];
  if (p.vertical) return [["vertical", p.tess, p.psm]];
  return [["horizontal", p.tess, p.psm]];
}

// 슬롯 사용은 한 번에 하나씩: "미리 준비" 버튼이 인식 중인 Worker를 다른 언어로 바꿔 끼우지 않게 한다(abort()는 잠금을 기다리지 않음).
let lockChain = Promise.resolve();
function withLock(fn) {
  const run = lockChain.then(fn, fn);
  lockChain = run.catch(() => {});
  return run;
}

/** 프로필에 필요한 Worker를 준비한다. 자동 프로필의 세로 Worker는 보통 첫 이미지를 읽을 때 준비하지만,
 *  사용자가 "미리 준비"를 누르면(includeVertical) 함께 준비한다. 패키지 자원만 쓴다. */
function prepare(profile = "auto", onProgress, { includeVertical = false } = {}) {
  return withLock(async () => {
    activeProfile = OCR_PROFILES[profile] ? profile : "auto";
    try {
      for (const [name, langs] of profileSlots(activeProfile)) await prepareSlot(name, langs, onProgress);
      if (includeVertical && activeProfile === "auto") await prepareSlot("vertical", VERTICAL_TESS, onProgress);
    } catch { /* 상태는 snapshot()에 남는다 */ }
    return snapshot();
  });
}

function ensure(profile = "auto", onProgress) {
  return withLock(async () => {
    activeProfile = OCR_PROFILES[profile] ? profile : "auto";
    try {
      for (const [name, langs] of profileSlots(activeProfile)) await prepareSlot(name, langs, onProgress);
      return true;
    } catch (error) {
      if (error && error.code === "cancelled") throw error;
      return false;
    }
  });
}

/** 진행 중인 OCR 준비·인식을 모두 멈춘다(두 Worker를 끝내 대기열이 막히지 않게). 다음 요청 때 필요한 Worker만 다시 준비한다. */
function abort() {
  generation += 1;
  for (const slot of Object.values(slots)) {
    const worker = slot.worker;
    const kill = slot.kill;
    slot.worker = null;
    slot.key = "";
    slot.kill = null;
    slot.pending = null;
    slot.state = "unchecked";
    slot.progress = null;
    slot.stage = "";
    if (kill) kill();
    if (worker) worker.terminate().catch(() => {});
  }
  for (const wake of [...abortWaiters]) wake();
}

/** 인식 오류(취소·정지 제외) 뒤 그 슬롯만 끝내고 "미준비"로 되돌린다: 망가진 Worker를 다시 쓰지 않고, 다음 요청 때 새로 준비한다.
 *  다른 슬롯(예: 세로가 실패했을 때의 가로)은 건드리지 않는다. */
function resetSlot(name, error) {
  const slot = slots[name];
  const worker = slot.worker;
  slot.worker = null;
  slot.key = "";
  slot.state = "unchecked";
  slot.progress = null;
  slot.stage = "";
  lastError = (error && error.message) || "OCR 인식 중 오류가 나 인식기를 다시 준비합니다.";
  if (worker) worker.terminate().catch(() => {});
}

/** 인식 한 번: PSM을 이 단계 값으로 다시 지정하고, 정지 감시(2분)와 abort()를 함께 건다. 진행률을 onProgress로 넘긴다. */
async function recognizeWith(name, canvas, psm, onProgress) {
  const slot = slots[name];
  const worker = slot.worker;
  if (!worker) throw Object.assign(new Error("OCR 엔진이 준비되지 않았습니다."), { code: "ocr_not_ready" });
  const gen = generation;
  let timer = 0, wake = null;
  const guard = new Promise((_, reject) => {
    wake = () => reject(cancelledError());
    abortWaiters.add(wake);
    timer = setTimeout(() => {
      // 자기 대기자를 먼저 떼고 "정지"로 끝낸 뒤에 Worker를 끝낸다. 순서가 반대면 abort()가 이 요청을 "취소"로 먼저 끝내,
      // 사용자가 취소하지 않았는데도 남은 이미지까지 조용히 버려진다.
      abortWaiters.delete(wake);
      reject(Object.assign(new Error("이미지 글자 인식이 2분 넘게 끝나지 않아 OCR 엔진을 다시 시작합니다."), { code: "ocr_stalled" }));
      abort();
    }, RECOGNIZE_STALL_MS);
  });
  guard.catch(() => {});
  slot.onRecognize = onProgress;
  try {
    const run = (async () => {
      await worker.setParameters({ tessedit_pageseg_mode: psm });
      return worker.recognize(canvas, {}, { text: false, blocks: true });
    })();
    const result = await Promise.race([run, guard]);
    if (gen !== generation) throw cancelledError();
    return (result && result.data) || {};
  } catch (error) {
    const code = error && error.code;
    if (code !== "cancelled" && code !== "ocr_stalled" && gen === generation && slot.worker === worker) resetSlot(name, error);
    throw error;
  } finally {
    clearTimeout(timer);
    abortWaiters.delete(wake);
    if (slot.onRecognize === onProgress) slot.onRecognize = null;
  }
}

// MARK: 배경·글자색 표본화 — Barobogi Mac(ImageTextRecognizer.sampleColors)의 그리드 다수결 방식을 Canvas로 옮긴 것.
// 문단 상자 둘레에 패딩을 더한 영역을 10x10으로 줄여 색을 양자화해 다수결 버킷을 찾는다(여백 샘플은 3배 더 신뢰).
function sampleColors(ctx, cw, ch, boxFrac) {
  const gridSize = 10;
  const boxPx = { x: boxFrac.x * cw, y: boxFrac.y * ch, w: Math.max(boxFrac.w * cw, 1), h: Math.max(boxFrac.h * ch, 1) };
  const pad = Math.min(Math.max(Math.min(boxPx.w, boxPx.h) * 0.25, 2), 12);
  const px0 = Math.max(0, Math.floor(boxPx.x - pad));
  const py0 = Math.max(0, Math.floor(boxPx.y - pad));
  const px1 = Math.min(cw, Math.ceil(boxPx.x + boxPx.w + pad));
  const py1 = Math.min(ch, Math.ceil(boxPx.y + boxPx.h + pad));
  const pw = px1 - px0, ph = py1 - py0;
  if (pw < 1 || ph < 1) return { bg: "#FFFFFF", fg: "#000000" };
  let pixels;
  try { pixels = ctx.getImageData(px0, py0, pw, ph).data; } catch { return { bg: "#FFFFFF", fg: "#000000" }; }
  const localMinX = (boxPx.x - px0) / pw, localMaxX = (boxPx.x + boxPx.w - px0) / pw;
  const localMinY = (boxPx.y - py0) / ph, localMaxY = (boxPx.y + boxPx.h - py0) / ph;
  const buckets = new Map();
  for (let gy = 0; gy < gridSize; gy += 1) {
    for (let gx = 0; gx < gridSize; gx += 1) {
      const sx = Math.min(pw - 1, Math.floor(((gx + 0.5) / gridSize) * pw));
      const sy = Math.min(ph - 1, Math.floor(((gy + 0.5) / gridSize) * ph));
      const idx = (sy * pw + sx) * 4;
      const a = pixels[idx + 3];
      if (a <= 10) continue;
      const r = pixels[idx] / 255, g = pixels[idx + 1] / 255, b = pixels[idx + 2] / 255;
      const fx = (gx + 0.5) / gridSize, fy = (gy + 0.5) / gridSize;
      const interior = fx > localMinX && fx < localMaxX && fy > localMinY && fy < localMaxY;
      const weight = interior ? 1 : 3;
      const key = (Math.round(r * 7) << 6) | (Math.round(g * 7) << 3) | Math.round(b * 7);
      const bucket = buckets.get(key) || { weight: 0, r: 0, g: 0, b: 0 };
      bucket.weight += weight; bucket.r += r * weight; bucket.g += g * weight; bucket.b += b * weight;
      buckets.set(key, bucket);
    }
  }
  let best = null;
  for (const bucket of buckets.values()) { if (!best || bucket.weight > best.weight) best = bucket; }
  if (!best || best.weight <= 0) return { bg: "#FFFFFF", fg: "#000000" };
  const r = best.r / best.weight, g = best.g / best.weight, b = best.b / best.weight;
  const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
  const hex = (v) => Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, "0").toUpperCase();
  return { bg: `#${hex(r)}${hex(g)}${hex(b)}`, fg: luminance > 0.55 ? "#000000" : "#FFFFFF" };
}

// MARK: 문자 종류·글자 흐름 분석

const HANGUL_RE = /[ᄀ-ᇿ㄰-㆏가-힣]/gu;
const KANA_RE = /[぀-ゟ゠-ヿㇰ-ㇿｦ-ﾝ]/gu;
const HAN_RE = /[㐀-䶿一-鿿豈-﫿]/gu;
const LATIN_RE = /[A-Za-zÀ-ɏ]/gu;
const countOf = (text, re) => (String(text).match(re) || []).length;

function scriptCounts(text) {
  const hangul = countOf(text, HANGUL_RE), kana = countOf(text, KANA_RE), han = countOf(text, HAN_RE), latin = countOf(text, LATIN_RE);
  return { hangul, kana, han, latin, cjk: kana + han, letters: hangul + kana + han + latin };
}

/** 문자 종류 계열: "ko"(한글) | "cjk"(한자·가나 — 일본어 계열을 한 덩어리로) | "latin" | null(글자 없음: 숫자·기호). */
function familyOf(s) {
  if (!s.letters) return null;
  if (s.hangul >= s.cjk && s.hangul >= s.latin) return "ko";
  if (s.cjk >= s.latin) return "cjk";
  return "latin";
}

/** 인식된 글자의 문자 종류에서 나온 원문 언어 힌트: "ko"|"ja"|"en"|"han"(가나 없는 한자 — 일본어·중국어 미정)|null.
 *  라틴 문자는 자동 프로필에 실린 라틴 문자 언어가 영어뿐이라 "en" 힌트를 준다(번역 단계에서 긴 글만 franc-min이 다시 확인). */
function scriptHint(text) {
  const s = scriptCounts(text);
  if (!s.letters) return null;
  if (s.hangul / s.letters >= 0.5) return "ko";
  if (s.kana > 0 && s.cjk / s.letters >= 0.5) return "ja";
  if (s.han / s.letters >= 0.5) return "han";
  if (s.latin / s.letters >= 0.5) return "en";
  return null;
}

const validBox = (b) => b && b.x1 > b.x0 && b.y1 > b.y0;
const median = (list) => { const s = list.slice().sort((a, b) => a - b); return s.length ? s[Math.floor(s.length / 2)] : 0; };
const area = (b) => Math.max(0, b.x1 - b.x0) * Math.max(0, b.y1 - b.y0);
const unionOf = (boxes) => boxes.reduce((u, b) => (u ? { x0: Math.min(u.x0, b.x0), y0: Math.min(u.y0, b.y0), x1: Math.max(u.x1, b.x1), y1: Math.max(u.y1, b.y1) } : { ...b }), null);
const centerIn = (b, box) => { const cx = (b.x0 + b.x1) / 2, cy = (b.y0 + b.y1) / 2; return cx >= box.x0 && cx <= box.x1 && cy >= box.y0 && cy <= box.y1; };

function intersection(a, b) {
  const ix = Math.max(0, Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0));
  const iy = Math.max(0, Math.min(a.y1, b.y1) - Math.max(a.y0, b.y0));
  return ix * iy;
}
function overlapRatio(a, b) {
  const small = Math.min(area(a), area(b));
  return small > 0 ? intersection(a, b) / small : 0;
}

/** 글자 상자 순서에서 본 흐름: "v"(위→아래로 이어짐)|"h"(옆으로 이어짐)|null(판단 근거 부족). */
function flowOf(boxes) {
  if (boxes.length < 2) return null;
  const dx = [], dy = [];
  for (let i = 1; i < boxes.length; i += 1) {
    const a = boxes[i - 1], b = boxes[i];
    dx.push(Math.abs((b.x0 + b.x1) / 2 - (a.x0 + a.x1) / 2));
    dy.push(Math.abs((b.y0 + b.y1) / 2 - (a.y0 + a.y1) / 2));
  }
  const across = median(dx), down = median(dy);
  if (down > across * 1.3) return "v";
  if (across > down * 1.3) return "h";
  return null;
}

const lineSymbols = (line) => line.words.flatMap((w) => w.syms.map((s) => s.box));

/** 줄들이 실제로 세로 모양인지: 줄 안 글자가 위아래로 이어지거나(세로로 긴 줄), 한두 글자짜리 줄이 같은 x에서 세로로 쌓였는지. */
function linesLookVertical(lines) {
  if (!lines.length) return false;
  let verticalChars = 0, totalChars = 0;
  for (const line of lines) {
    const syms = lineSymbols(line);
    const n = Math.max(1, syms.length);
    totalChars += n;
    const b = line.box, w = b.x1 - b.x0, h = b.y1 - b.y0;
    const flow = flowOf(syms);
    if (flow === "v" || (flow !== "h" && syms.length >= 2 && h >= w * 1.6)) verticalChars += n;
  }
  if (verticalChars / totalChars >= 0.6) return true;
  if (lines.length >= 3) {
    const narrow = lines.filter((l) => (l.box.x1 - l.box.x0) <= (l.box.y1 - l.box.y0) * 1.5);
    if (narrow.length / lines.length >= 0.8) {
      const cx = narrow.map((l) => (l.box.x0 + l.box.x1) / 2);
      const widths = narrow.map((l) => l.box.x1 - l.box.x0);
      const spread = Math.max(...cx) - Math.min(...cx);
      if (spread <= median(widths) * 1.2) return true;
    }
  }
  return false;
}

/** 세로 열들을 가로 줄로 가로질러 읽은 격자 모양인지(신뢰도가 높아도 글자 순서가 섞인 글): 한자·가나 위주이고,
 *  한 줄 안 글자 사이 가로 간격이 글자 폭의 절반을 넘고, 줄 간격이 글자 높이와 비슷하며, 위아래 줄의 글자가 같은 x에 놓인다. */
function gridSuspect(lines, scripts) {
  if (scripts.cjk < 4 || scripts.cjk < (scripts.hangul + scripts.latin) * 2) return false;
  const rows = lines.map((l) => lineSymbols(l).slice().sort((a, b) => a.x0 - b.x0)).filter((r) => r.length >= 2);
  if (rows.length < 2) return false;
  const all = rows.flat();
  const charW = median(all.map((b) => b.x1 - b.x0)), charH = median(all.map((b) => b.y1 - b.y0));
  if (charW <= 0 || charH <= 0) return false;
  const gaps = [];
  for (const row of rows) for (let i = 1; i < row.length; i += 1) gaps.push(row[i].x0 - row[i - 1].x1);
  if (median(gaps) < charW * 0.5) return false;
  const cy = (b) => (b.y0 + b.y1) / 2, cx = (b) => (b.x0 + b.x1) / 2;
  rows.sort((a, b) => median(a.map(cy)) - median(b.map(cy)));
  const pitches = [];
  for (let i = 1; i < rows.length; i += 1) pitches.push(median(rows[i].map(cy)) - median(rows[i - 1].map(cy)));
  if (median(pitches) > charH * 1.6) return false;
  let aligned = 0, total = 0;
  for (let i = 1; i < rows.length; i += 1) {
    for (const b of rows[i]) {
      total += 1;
      if (rows[i - 1].some((a) => Math.abs(cx(a) - cx(b)) <= charW * 0.35)) aligned += 1;
    }
  }
  return total > 0 && aligned / total >= 0.6;
}

function cleanText(text) {
  return String(text || "").replace(/\s+/g, " ").replace(CJK_JOIN, "$1").trim();
}

/** Tesseract 결과를 블록 종류(blocktype)를 지닌 문단 목록으로 펼친다. 줄·낱말·글자 상자는 offset만큼 옮긴다(잘라 읽은 경우). */
function paragraphsOf(data, offset = { x: 0, y: 0 }) {
  const shift = (b) => ({ x0: b.x0 + offset.x, y0: b.y0 + offset.y, x1: b.x1 + offset.x, y1: b.y1 + offset.y });
  const out = [];
  for (const block of data.blocks || []) {
    const blocktype = Number.isFinite(Number(block.blocktype)) && block.blocktype !== null ? Number(block.blocktype) : null;
    for (const paragraph of block.paragraphs || []) {
      const lines = [];
      for (const line of paragraph.lines || []) {
        const words = [];
        for (const word of line.words || []) {
          if (!validBox(word.bbox)) continue;
          const syms = (word.symbols || []).filter((s) => validBox(s.bbox)).map((s) => ({ box: shift(s.bbox), conf: Number(s.confidence) || 0 }));
          words.push({ text: String(word.text || ""), conf: Number(word.confidence) || 0, box: shift(word.bbox), syms });
        }
        if (words.length) lines.push({ box: unionOf(words.map((w) => w.box)), words });
      }
      out.push({
        blocktype, lines, conf: Number(paragraph.confidence) || 0, text: cleanText(paragraph.text),
        box: validBox(paragraph.bbox) ? shift(paragraph.bbox) : null
      });
    }
  }
  return out;
}

/** 실제 낱말들로 후보를 만든다. 상자는 낱말 상자의 합집합, 신뢰도는 낱말 신뢰도의 글자 수 가중 평균. */
function buildCandidate(pass, lines, meta) {
  lines = lines.filter((l) => l.words.length).map((l) => ({ box: unionOf(l.words.map((w) => w.box)), words: l.words }));
  if (!lines.length) return null;
  const words = lines.flatMap((l) => l.words);
  const text = cleanText(lines.map((l) => l.words.map((w) => w.text).join(" ")).join(" "));
  if (!text) return null;
  let sum = 0, weight = 0;
  for (const w of words) { const n = Math.max(1, w.text.length); sum += w.conf * n; weight += n; }
  const scripts = scriptCounts(text);
  const lineFlows = lines.map((l) => flowOf(lineSymbols(l))).filter(Boolean);
  const flow = lineFlows.length ? (lineFlows.filter((f) => f === "v").length >= lineFlows.length / 2 ? "v" : "h") : null;
  return {
    pass, refined: meta.refined === true, blocktype: meta.blocktype, lines, text,
    conf: weight ? sum / weight : 0, box: unionOf(words.map((w) => w.box)),
    symbols: words.flatMap((w) => w.syms.filter((s) => s.conf >= MIN_CONFIDENCE).map((s) => s.box)),
    wordBoxes: words.filter((w) => w.conf >= MIN_CONFIDENCE).map((w) => w.box),
    flow, looksVertical: linesLookVertical(lines), grid: gridSuspect(lines, scripts), scripts, family: familyOf(scripts)
  };
}

/** 문단을 문자 종류가 같은 연속 줄 묶음으로 나눈다. 한 줄 안에서는 다른 문자 종류 묶음이 크게 떨어져 있거나(줄 높이 이상)
 *  양쪽 모두 낱말 2개·글자 4개 이상으로 길게 이어질 때만 나눈다(문장 속 외래어 한 낱말은 나누지 않음). 글자 2개 미만 조각은 이웃에 붙인다. */
function splitByScript(lines) {
  const pieces = [];
  for (const line of lines) {
    const lineH = line.box.y1 - line.box.y0, lineW = line.box.x1 - line.box.x0;
    const runs = [];
    for (const word of line.words) {
      const s = scriptCounts(word.text);
      const fam = familyOf(s);
      const last = runs[runs.length - 1];
      if (last && (!fam || !last.family || fam === last.family)) {
        last.words.push(word);
        last.letters += s.letters;
        if (!last.family) last.family = fam;
      } else {
        runs.push({ family: fam, words: [word], letters: s.letters });
      }
    }
    const kept = [];
    for (const run of runs) {
      const prev = kept[kept.length - 1];
      if (prev) {
        const a = prev.words[prev.words.length - 1].box, b = run.words[0].box;
        const gap = lineH >= lineW ? b.y0 - a.y1 : b.x0 - a.x1; // 세로 열이면 위아래 간격
        const unit = Math.min(lineH, lineW);
        const long = (r) => r.words.length >= 2 && r.letters >= 4;
        const genuine = run.family && prev.family && run.family !== prev.family && run.letters >= 2 && prev.letters >= 2 &&
          (gap >= unit || (long(prev) && long(run)));
        if (!genuine) { prev.words.push(...run.words); prev.letters += run.letters; if (!prev.family) prev.family = run.family; continue; }
      }
      kept.push(run);
    }
    for (const run of kept) {
      // 한 줄 전체 조각의 계열은 낱말이 아니라 글자 수 다수로 다시 정한다(섞인 짧은 낱말을 붙인 결과).
      const s = scriptCounts(run.words.map((w) => w.text).join(""));
      pieces.push({ family: familyOf(s), letters: s.letters, line: { box: unionOf(run.words.map((w) => w.box)), words: run.words } });
    }
  }
  const segments = [];
  for (const piece of pieces) {
    const last = segments[segments.length - 1];
    if (last && (piece.letters < 2 || !piece.family || piece.family === last.family || last.letters < 2)) {
      last.lines.push(piece.line);
      if (last.letters < 2 && piece.letters >= 2) last.family = piece.family;
      last.letters += piece.letters;
    } else {
      segments.push({ family: piece.family, letters: piece.letters, lines: [piece.line] });
    }
  }
  return segments.map((s) => s.lines);
}

/** 문단 목록을 후보로 바꾼다. split: 자동 프로필이면 문자 종류별로 나눈다. */
function candidatesOf(paragraphs, pass, { split = true, refined = false } = {}) {
  const out = [];
  for (const par of paragraphs) {
    const groups = split ? splitByScript(par.lines) : [par.lines];
    for (const lines of groups) {
      const c = buildCandidate(pass, lines, { blocktype: par.blocktype, refined });
      if (c && c.conf >= MIN_CONFIDENCE) out.push(c);
    }
  }
  return out;
}

/** 실제 세로 근거: 글자가 위→아래로 이어지거나, (흐름 판단 근거가 없을 때) Tesseract가 세로 블록으로 봤거나 세로 열 모양이다. */
function verticalEvidence(c) {
  if (c.flow === "v") return true;
  if (c.flow === "h") return false;
  return c.blocktype === PT_VERTICAL_TEXT || c.looksVertical;
}

/** 세로 열을 가로 모델이 읽었다고 의심되는 가로 후보(블록 종류가 세로인데 흐름이 세로인 것은 하위 언어 jpn_vert가 제대로 읽은 것). */
function horizontalReadOfVertical(c) {
  if (c.pass !== "h" || c.scripts.cjk < c.scripts.hangul + c.scripts.latin) return false;
  if (c.grid) return true;
  return c.looksVertical && c.blocktype !== PT_VERTICAL_TEXT && c.flow !== "v";
}

/** 세로 후보가 지울 수 없는 가로 후보: 신뢰도 높은 라틴·한글 위주 글(세로 모델은 이 글자들을 읽지 못한다). */
function protectedHorizontal(c) {
  const s = c.scripts;
  return c.pass === "h" && !c.grid && c.conf >= PROTECTED_H_CONFIDENCE && s.letters >= 2 && (s.hangul + s.latin) / s.letters >= 0.6;
}

/** 믿을 만한 가로 글(라틴·한글·가로 한자/가나): 이것이 들어 있는 곳은 PSM 5로 잘라 읽지 않는다. */
function goodHorizontal(c) {
  return c.pass === "h" && c.conf >= PROTECTED_H_CONFIDENCE && c.flow !== "v" && c.blocktype !== PT_VERTICAL_TEXT &&
    !c.looksVertical && !c.grid && c.scripts.letters >= 2;
}

function score(c) {
  let s = c.conf;
  const s2 = c.scripts;
  const nonCjk = s2.hangul + s2.latin;
  if (c.pass === "v") {
    if (c.flow === "h") s -= 25;                 // 세로 모델이 가로 줄을 읽은 경우
    if (nonCjk > s2.cjk) s -= 30;                // 세로 모델(일본어)은 한글·라틴을 제대로 못 읽는다
    if (c.refined) s += 5;                       // 그 부분만 잘라 세로 한 덩어리로 다시 읽은 결과
  } else {
    if (c.grid && s2.cjk >= nonCjk) s -= 30;     // 세로 열을 가로로 가로질러 읽은 격자: 신뢰도가 높아도 순서가 섞인 글
    else if (horizontalReadOfVertical(c)) s -= 15; // 가로 모델이 세로 열을 읽은 경우
    if (nonCjk > s2.cjk) s += 10;
  }
  return s;
}

/** 세로 패스 후보로 쓸 수 있는지: 한자·가나 위주이고 실제 세로 근거가 있다(세로 모델의 비CJK 출력은 믿지 않는다). */
function usableVertical(c) {
  return !!c && c.conf >= MIN_CONFIDENCE && c.scripts.letters > 0 && c.scripts.cjk / c.scripts.letters >= 0.5 && verticalEvidence(c);
}

/** loser에서 winner 상자 안에 중심이 있는 낱말을 뺀 후보(뺄 낱말이 없거나 남은 것이 쓸모없으면 null). */
function trimCandidate(loser, box) {
  let removed = 0;
  const lines = loser.lines.map((l) => ({ box: l.box, words: l.words.filter((w) => { const inside = centerIn(w.box, box); if (inside) removed += 1; return !inside; }) }));
  if (!removed) return null;
  const c = buildCandidate(loser.pass, lines, { blocktype: loser.blocktype, refined: loser.refined });
  if (!c || c.conf < MIN_CONFIDENCE) return null;
  if (c.pass === "v" && !usableVertical(c)) return null;
  return c;
}

/** 같은 패스 안의 겹치는 결과(전체 스캔과 정밀 인식, 겹치는 잘라 읽기)를 하나만 남긴다: 점수 높은 것부터. */
function dedupSamePass(list) {
  const sorted = list.slice().sort((a, b) => score(b) - score(a) || b.scripts.letters - a.scripts.letters);
  const kept = [];
  for (const c of sorted) if (!kept.some((k) => overlapRatio(k.box, c.box) >= OVERLAP)) kept.push(c);
  return kept;
}

/** 가로·세로 후보를 겹치는 쌍마다 비교해 병합한다(묶음 전체에서 한 패스만 남기는 방식이 아님).
 *  hEvidence: 가로 패스가 실제로 글자를 본 상자들(신뢰도 낮은 것 포함) — 세로 단독 판정에 쓴다. */
function mergeCandidates(hList, vList, hEvidence) {
  let h = hList.slice();
  let v = dedupSamePass(vList);
  // 한 번 돌 때마다 후보 하나가 빠지거나 낱말이 줄어드므로 (후보 수 + 낱말 수)번 안에 끝난다.
  const limit = [...h, ...v].reduce((n, c) => n + 1 + c.lines.reduce((m, l) => m + l.words.length, 0), 1);
  for (let guard = 0; guard < limit; guard += 1) {
    let pair = null;
    for (const a of h) {
      for (const b of v) {
        const r = overlapRatio(a.box, b.box);
        if (r >= OVERLAP && (!pair || r > pair.r)) pair = { a, b, r };
      }
    }
    if (!pair) break;
    const { a, b } = pair;
    const hWins = protectedHorizontal(a) || score(a) >= score(b);
    const winner = hWins ? a : b, loser = hWins ? b : a;
    // 진 쪽이 훨씬 크면 통째로 지우지 않고 이긴 쪽에 걸친 낱말만 뺀다(큰 세로 문단이 옆의 좋은 가로 글까지 지우지 않게, 반대도 같음).
    const replacement = area(loser.box) > area(winner.box) * 2 ? trimCandidate(loser, winner.box) : null;
    if (hWins) v = v.filter((c) => c !== loser).concat(replacement ? [replacement] : []);
    else h = h.filter((c) => c !== loser).concat(replacement ? [replacement] : []);
  }
  // 가로 패스가 글자를 보지 못한 곳의 세로 단독 결과는 강한 근거가 있을 때만 남긴다(잡음을 세로 모델이 글자로 읽은 것 방지).
  v = v.filter((c) => {
    if (hEvidence.some((box) => overlapRatio(box, c.box) >= 0.2)) return true;
    const s = c.scripts;
    return c.conf >= STRONG_V_CONFIDENCE && s.letters >= 2 && s.cjk / s.letters >= 0.8 && verticalEvidence(c);
  });
  return [...h, ...v];
}

/** 세로 정밀 인식(PSM 5)으로 다시 읽을 곳을 고른다(작업 캔버스 px). 근거가 강한 순으로 최대 6곳.
 *  근거: 가로 패스 문단 중 세로 블록·세로 흐름·격자·세로 모양·신뢰도 낮은 한자/가나, 세로 전체 스캔 중 실제 세로 결과.
 *  믿을 만한 가로 글이 들어 있는 곳(섞인 곳)은 자르지 않는다: 그곳은 전체 스캔(PSM 3) 결과만 쓴다. */
function refinementCrops(hParagraphs, hCandidates, vScan, cw, ch) {
  const pad = Math.max(8, Math.min(40, Math.round(Math.max(cw, ch) * 0.03)));
  const sources = [];
  for (const par of hParagraphs) {
    if (!par.lines.length) continue;
    const c = buildCandidate("h", par.lines, { blocktype: par.blocktype });
    if (!c) continue;
    const w = c.box.x1 - c.box.x0, hgt = c.box.y1 - c.box.y0;
    const weakCjk = CJK.test(c.text) && c.conf < 60 && w <= hgt * 3;
    let strength = 0;
    if (c.blocktype === PT_VERTICAL_TEXT) strength += 3;
    if (c.flow === "v") strength += 2;
    if (c.grid) strength += 2;
    if (c.looksVertical) strength += 1;
    if (weakCjk) strength += 0.5;
    if (strength > 0 && c.scripts.cjk > 0) sources.push({ box: c.box, strength });
  }
  for (const c of vScan) {
    if (!usableVertical(c)) continue;
    sources.push({ box: c.box, strength: 2 + (c.blocktype === PT_VERTICAL_TEXT ? 1 : 0) + c.conf / 100 });
  }
  let boxes = sources.map((s) => ({ x0: s.box.x0 - pad, y0: s.box.y0 - pad, x1: s.box.x1 + pad, y1: s.box.y1 + pad, strength: s.strength }));
  // 겹치거나 닿는 곳은 합치되(같은 말풍선의 여러 열), 합친 상자가 두 상자 면적의 합보다 크게 부풀면 합치지 않는다(사슬처럼 커지지 않게).
  let merged = true;
  while (merged) {
    merged = false;
    outer: for (let i = 0; i < boxes.length; i += 1) {
      for (let j = i + 1; j < boxes.length; j += 1) {
        const a = boxes[i], b = boxes[j];
        if (!(a.x0 <= b.x1 && b.x0 <= a.x1 && a.y0 <= b.y1 && b.y0 <= a.y1)) continue;
        const u = { x0: Math.min(a.x0, b.x0), y0: Math.min(a.y0, b.y0), x1: Math.max(a.x1, b.x1), y1: Math.max(a.y1, b.y1) };
        if (area(u) > (area(a) + area(b)) * 1.25 && overlapRatio(a, b) < 0.5) continue;
        boxes[i] = { ...u, strength: Math.max(a.strength, b.strength) + 0.5 };
        boxes.splice(j, 1);
        merged = true;
        break outer;
      }
    }
  }
  const good = hCandidates.filter(goodHorizontal);
  return boxes
    .map((b) => ({
      x0: Math.max(0, Math.floor(b.x0)), y0: Math.max(0, Math.floor(b.y0)),
      x1: Math.min(cw, Math.ceil(b.x1)), y1: Math.min(ch, Math.ceil(b.y1)), strength: b.strength
    }))
    .filter((b) => b.x1 - b.x0 >= 12 && b.y1 - b.y0 >= 12)
    .filter((b) => !good.some((c) => centerIn(c.box, b)))
    .sort((a, b) => b.strength - a.strength || area(b) - area(a))
    .slice(0, MAX_VERTICAL_CROPS);
}

/** 문단 가로/세로: 실제 글자 배치에서 정한다. 흐름을 알 수 없는 세로 패스 결과를 무조건 세로로 두지 않는다
 *  (사용자가 "일본어 세로쓰기만"을 직접 고른 경우만 예외: explicitVertical). */
function isVertical(c, explicitVertical) {
  const s = c.scripts;
  if (s.cjk === 0 || s.cjk < s.hangul + s.latin) return false;
  if (c.pass === "v") return explicitVertical ? c.flow !== "h" : verticalEvidence(c);
  if (c.flow === "v") return true;
  if (c.flow === "h" || c.grid) return false;
  return c.blocktype === PT_VERTICAL_TEXT || c.looksVertical;
}

function toItem(c, ctx, cw, ch, explicitVertical = false) {
  const b = c.box;
  const frac = { x: b.x0 / cw, y: b.y0 / ch, w: (b.x1 - b.x0) / cw, h: (b.y1 - b.y0) / ch };
  const toFrac = (g) => [g.x0 / cw, g.y0 / ch, (g.x1 - g.x0) / cw, (g.y1 - g.y0) / ch];
  // 글자 상자: Tesseract가 실제로 준 글자(symbol) 상자를 "글자"(gl=1)로 넘긴다. 너무 많으면 낱말 상자(gl=0)로 대신한다.
  let g = [], gl = "";
  if (c.symbols.length && c.symbols.length <= MAX_GLYPHS) { g = c.symbols.map(toFrac); gl = "1".repeat(g.length); }
  else if (c.wordBoxes.length) { g = c.wordBoxes.slice(0, MAX_GLYPHS).map(toFrac); gl = "0".repeat(g.length); }
  const { bg, fg } = sampleColors(ctx, cw, ch, frac);
  return {
    x: frac.x, y: frac.y, w: frac.w, h: frac.h, o: c.text.slice(0, 700), v: isVertical(c, explicitVertical) ? 1 : 0,
    bg, fg, ...(g.length ? { g, gl } : {}), conf: Math.round(c.conf), pass: c.pass, sh: scriptHint(c.text)
  };
}

function workCanvasOf(canvas) {
  const long = Math.max(canvas.width, canvas.height);
  const scale = Math.max(1, Math.min(2, TARGET_LONG_SIDE / Math.max(1, long)));
  if (scale <= 1.05) return canvas;
  const work = new OffscreenCanvas(Math.round(canvas.width * scale), Math.round(canvas.height * scale));
  const ctx = work.getContext("2d");
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(canvas, 0, 0, work.width, work.height);
  return work;
}

function cropCanvas(source, b) {
  const crop = new OffscreenCanvas(b.x1 - b.x0, b.y1 - b.y0);
  crop.getContext("2d").drawImage(source, b.x0, b.y0, b.x1 - b.x0, b.y1 - b.y0, 0, 0, b.x1 - b.x0, b.y1 - b.y0);
  return crop;
}

/** canvas(이미 잘라낸 한 이미지 영역)를 인식해 { items, warnings }를 돌려준다.
 *  options.profile: "auto"(기본)|수동 프로필. options.onPhase(text, fraction|null): 실제 단계·그 단계의 진행률. options.isCancelled().
 *  항목: x,y,w,h,o,v(0|1),bg,fg,g,gl + conf(신뢰도)·pass("h"|"v")·sh(scriptHint). 신뢰도가 낮거나 글자가 없는 조각은 뺀다.
 *  warnings: ["ocr-vertical"] — 세로 단계가 실패해 가로 결과(와 그때까지 읽은 세로 결과)만 돌려준 경우.
 *  사용자 취소는 code "cancelled"로 거부하고, 사용자가 취소하지 않았는데 Worker가 끊긴 경우는 "ocr_interrupted"로 구분한다. */
function recognizeRegion(canvas, options = {}) {
  const isCancelled = typeof options.isCancelled === "function" ? options.isCancelled : () => false;
  return withLock(() => recognizeRegionNow(canvas, { ...options, isCancelled })).catch((error) => {
    if (error && error.code === "cancelled" && !isCancelled()) {
      throw Object.assign(new Error("OCR 엔진이 중간에 다시 시작되어 이 이미지를 읽지 못했습니다."), { code: "ocr_interrupted" });
    }
    throw error;
  });
}

async function recognizeRegionNow(canvas, { profile = "auto", onPhase, isCancelled }) {
  const p = OCR_PROFILES[profile] || OCR_PROFILES.auto;
  activeProfile = OCR_PROFILES[profile] ? profile : "auto";
  const phase = (text, fraction = null) => { if (typeof onPhase === "function") onPhase(text, fraction); };
  const preparePhase = (label) => (slot, fraction, stage) => phase(`${label} 준비${stage ? ` · ${stage}` : ""}`, fraction);
  const work = workCanvasOf(canvas);
  const cw = work.width, ch = work.height;
  const ctx = work.getContext("2d");
  const check = () => { if (isCancelled()) throw cancelledError(); };

  if (!p.auto) {
    const [name, langs, psm] = profileSlots(profile)[0];
    await prepareSlot(name, langs, preparePhase(`${langsLabel(langs)} 인식기`));
    check();
    const data = await recognizeWith(name, work, psm, (fraction) => phase(`${langsLabel(langs)} 인식`, fraction));
    const candidates = candidatesOf(paragraphsOf(data), p.vertical ? "v" : "h", { split: false });
    return { items: candidates.map((c) => toItem(c, ctx, cw, ch, p.vertical)), warnings: [] };
  }

  const autoLangs = AUTO_TESS.join("+");
  await prepareSlot("horizontal", autoLangs, preparePhase("가로 인식기"));
  check();
  const hData = await recognizeWith("horizontal", work, "3", (fraction) => phase("가로 인식(여러 언어, 세로 블록 포함)", fraction));
  check();
  const hParagraphs = paragraphsOf(hData);
  const hCandidates = candidatesOf(hParagraphs, "h");
  const hEvidence = hParagraphs.filter((par) => par.text && par.box).map((par) => par.box);

  // 세로 단계: 실패해도(사용자 취소 제외) 이미 읽은 가로 결과와 그때까지 읽은 세로 결과는 버리지 않는다.
  const warnings = [];
  const vCandidates = [];
  try {
    await prepareSlot("vertical", VERTICAL_TESS, preparePhase("세로 인식기(일본어 세로)"));
    check();
    const scanData = await recognizeWith("vertical", work, "3", (fraction) => phase("세로 전체 스캔(일본어 세로, 자동 배치)", fraction));
    const vScan = candidatesOf(paragraphsOf(scanData), "v").filter(usableVertical);
    vCandidates.push(...vScan);
    const crops = refinementCrops(hParagraphs, hCandidates, vScan, cw, ch);
    for (let i = 0; i < crops.length; i += 1) {
      check();
      const crop = crops[i];
      const data = await recognizeWith("vertical", cropCanvas(work, crop), "5",
        (fraction) => phase(`세로 후보 ${i + 1}/${crops.length} 정밀 인식(일본어 세로)`, fraction));
      vCandidates.push(...candidatesOf(paragraphsOf(data, { x: crop.x0, y: crop.y0 }), "v", { refined: true }).filter(usableVertical));
    }
  } catch (error) {
    if (isCancelled()) throw cancelledError();
    warnings.push("ocr-vertical");
  }
  check();
  phase("가로·세로 후보 비교·중복 제거", null);
  const kept = mergeCandidates(hCandidates, vCandidates, hEvidence);
  kept.sort((a, b) => a.box.y0 - b.box.y0 || a.box.x0 - b.box.x0);
  return { items: kept.map((c) => toItem(c, ctx, cw, ch)), warnings };
}

globalThis.BarobogiOcr = { OCR_PROFILES, AUTO_TESS, VERTICAL_TESS, prepare, ensure, snapshot, recognizeRegion, abort, scriptHint, langsLabel };
