"use strict";
// 바로보기 웹 번역 — 엔진 문서(engine.html) 제어. Chrome 사이드패널, Chrome·Whale 공통 엔진 창(확장이 연 좁은 창)에서
// 같은 코드로 동작한다. 배경 서비스 워커와 "engine" 포트로 연결해 번역·OCR 요청을 받는다.
// - 요청은 한 번에 하나씩(대기열 상한 있음) 처리해 메모리·CPU를 제한한다. 상태 확인 요청은 대기열을 거치지 않는다.
// - 대기 중·실행 중인 요청 ID를 5초마다(그리고 실제 진행이 있을 때) 배경에 알린다. 배경은 이 신호가 끊길 때만
//   시간 초과로 처리하므로, 느린 CPU에서 긴 번역이 고정 60초에 잘리지 않는다. 대신 엔진 쪽에서 조각별 정지 감시
//   (토큰 2분 무진행·OCR 2분)를 해서 실제로 멈춘 계산은 Worker를 다시 만들어 끝낸다.
const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);
const MAX_QUEUE = 32;
const ALIVE_INTERVAL = 5000;
const IS_WHALE = typeof globalThis.whale !== "undefined" || /\bWhale\//.test(navigator.userAgent);

const SETTING_DEFAULTS = { target: "ko", source: "auto", ocrLang: "auto", nativeFirst: false };
let settings = { ...SETTING_DEFAULTS };
let active = false;

// MARK: 배경 연결

let port = null;
let reconnectDelay = 300;
const queue = []; // { message, cancelled }
const queuedIds = new Map(); // id → entry
let running = null; // { message, cancelled, progress }
let lastAliveAt = 0;

function connectEnginePort() {
  try {
    port = chrome.runtime.connect({ name: "engine" });
  } catch {
    setTimeout(connectEnginePort, Math.min(10000, (reconnectDelay *= 2)));
    return;
  }
  port.onMessage.addListener(onPortMessage);
  port.onDisconnect.addListener(() => {
    // 서비스 워커 재시작 등으로 끊기면 다시 연결한다. 끊긴 포트로 받은 요청은 배경이 이미 실패 처리했으므로 버린다.
    port = null;
    active = false;
    for (const entry of queue) entry.cancelled = true;
    queue.length = 0;
    queuedIds.clear();
    if (running) running.cancelled = true;
    renderRole();
    setTimeout(connectEnginePort, Math.min(10000, reconnectDelay));
    reconnectDelay = Math.min(10000, reconnectDelay * 2);
  });
  reconnectDelay = 300;
}

function post(message) {
  if (!port) return;
  try { port.postMessage(message); } catch { /* 연결 끊김 */ }
}

function sendAlive(force = false) {
  const ids = [...queuedIds.keys()];
  if (running) ids.push(running.message.id);
  if (!ids.length) return;
  const now = Date.now();
  if (!force && now - lastAliveAt < 1000) return;
  lastAliveAt = now;
  post({ type: "alive", ids });
}
setInterval(() => sendAlive(true), ALIVE_INTERVAL);

function onPortMessage(message) {
  if (!message || typeof message !== "object") return;
  if (message.type === "role") {
    active = message.active === true;
    renderRole();
    if (active) autoLoadModel();
    return;
  }
  if (typeof message.id !== "string") return;
  if (message.type === "cancel") {
    const entry = queuedIds.get(message.id);
    if (entry) { entry.cancelled = true; queuedIds.delete(message.id); }
    if (running && running.message.id === message.id) {
      running.cancelled = true;
      // OCR 준비·인식은 Tesseract Worker 안에서 돌아 중간에 멈출 수 없다: 두 Worker(가로·세로)를 모두 끝내 대기열을 풀어 준다
      // (다음 요청 때 필요한 것만 자동 재준비).
      if (running.message.type === "ocr" && (running.phase === "ocr" || running.phase === "ocr-prepare")) BarobogiOcr.abort();
    }
    return;
  }
  if (message.type === "status") {
    post({ id: message.id, ok: true, result: statusSnapshot() });
    return;
  }
  if (queue.length >= MAX_QUEUE) {
    post({ id: message.id, ok: false, code: "busy", message: "번역 엔진 대기열이 가득 찼습니다. 잠시 뒤 다시 시도하세요." });
    return;
  }
  const entry = { message, cancelled: false };
  queue.push(entry);
  queuedIds.set(message.id, entry);
  sendAlive(true);
  pump();
}

let pumping = false;
async function pump() {
  if (pumping) return;
  pumping = true;
  try {
    while (queue.length) {
      const entry = queue.shift();
      queuedIds.delete(entry.message.id);
      if (entry.cancelled) { post({ id: entry.message.id, ok: false, code: "cancelled", message: "" }); continue; }
      running = { ...entry, phase: "", progress: "" };
      const current = running;
      renderJob();
      try {
        const result = await handleRequest(current);
        if (current.cancelled) post({ id: current.message.id, ok: false, code: "cancelled", message: "" });
        else post({ id: current.message.id, ok: true, result });
      } catch (error) {
        post({ id: current.message.id, ok: false, code: (error && error.code) || "error", message: (error && error.message) || "" });
      } finally {
        running = null;
        renderJob();
      }
    }
  } finally {
    pumping = false;
  }
}

function cancelledError() { return Object.assign(new Error(""), { code: "cancelled" }); }

async function handleRequest(job) {
  const { type, payload } = job.message;
  const isCancelled = () => job.cancelled;
  switch (type) {
    case "translate": {
      job.phase = "text";
      const hint = BarobogiLangDetect.normalizeHint(payload.hint);
      return BarobogiTranslate.translateBatch(payload.texts, payload.target, payload.source, {
        hint, nativeFirst: settings.nativeFirst, isCancelled,
        onProgress: (done, total) => { job.progress = `글자 ${Math.floor(done)}/${total}`; renderJob(); sendAlive(); }
      });
    }
    case "ocr":
      return handleOcrRequest(job, payload);
    default:
      throw Object.assign(new Error("알 수 없는 엔진 요청입니다."), { code: "bad_request" });
  }
}

// MARK: OCR 요청 — 캡처 전체 이미지를 받아 영역별로 자르고 인식한 뒤, 같은 번역 라우터로 번역한다.

async function handleOcrRequest(job, { dataUrl, viewport, regions, target, source, ocrLang, hint }) {
  const isCancelled = () => job.cancelled;
  const profile = BarobogiOcr.OCR_PROFILES[ocrLang] ? ocrLang : settings.ocrLang;
  const auto = BarobogiOcr.OCR_PROFILES[profile].auto === true;
  const pageHint = BarobogiLangDetect.normalizeHint(hint);
  const missing = [];
  job.phase = "ocr-prepare";
  job.progress = auto ? `OCR 준비(${BarobogiOcr.langsLabel(BarobogiOcr.AUTO_TESS.join("+"))})` : "OCR 준비";
  renderJob();
  let ready = false;
  try {
    ready = await BarobogiOcr.ensure(profile, (slot, fraction, stage) => {
      // 진행률은 지금 준비 단계(코드 불러오기·언어 데이터 읽기·설정)의 값이라 단계 이름과 함께 보인다(전체 진행률이 아님).
      job.progress = `OCR 준비${stage ? ` · ${stage}` : ""}${Number.isFinite(fraction) ? ` ${Math.round(fraction * 100)}%` : ""}`;
      renderJob();
      refreshOcrStatus();
      sendAlive();
    });
  } catch {
    if (isCancelled()) throw cancelledError();
  }
  refreshOcrStatus();
  if (isCancelled()) throw cancelledError();
  if (!ready) {
    return { images: regions.map((r) => ({ k: r.k, items: [], langs: {} })), missing: ["ocr"], warning: BarobogiTranslate.warningFor(["ocr"]) };
  }
  const bitmap = await dataUrlToBitmap(dataUrl);
  const scaleX = bitmap.width / viewport.w;
  const scaleY = bitmap.height / viewport.h;
  const perRegion = [];
  job.phase = "ocr";
  try {
    for (let index = 0; index < regions.length; index += 1) {
      if (isCancelled()) throw cancelledError();
      const region = regions[index];
      job.progress = `이미지 ${index + 1}/${regions.length} 인식 시작`;
      renderJob();
      sendAlive();
      const sx = Math.max(0, Math.round(region.x * scaleX));
      const sy = Math.max(0, Math.round(region.y * scaleY));
      const sw = Math.max(1, Math.min(bitmap.width - sx, Math.round(region.w * scaleX)));
      const sh = Math.max(1, Math.min(bitmap.height - sy, Math.round(region.h * scaleY)));
      const canvas = new OffscreenCanvas(sw, sh);
      canvas.getContext("2d").drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);
      let items = [];
      try {
        const recognized = await BarobogiOcr.recognizeRegion(canvas, {
          profile, isCancelled,
          onPhase: (text, fraction) => {
            job.progress = `이미지 ${index + 1}/${regions.length} · ${text}${Number.isFinite(fraction) ? ` ${Math.round(fraction * 100)}%` : ""}`;
            renderJob();
            refreshOcrStatus();
            sendAlive();
          }
        });
        items = recognized.items;
        // 세로 단계 실패 등 일부만 읽은 경우: 읽은 결과는 쓰고 경고를 페이지에 그대로 보인다.
        recognized.warnings.forEach((code) => missing.push(code));
        if (recognized.warnings.length) refreshOcrStatus();
      } catch (error) {
        if (isCancelled() || (error && error.code === "cancelled")) throw cancelledError();
        missing.push("ocr-region");
        refreshOcrStatus();
      }
      perRegion.push({ k: region.k, items });
    }
  } finally {
    bitmap.close?.();
  }
  if (isCancelled()) throw cancelledError();

  // 문단(문자 종류별로 나눈 조각)마다 원문 언어 힌트를 정한다. 자동 프로필: 그 조각의 문자 종류(scriptHint). 가나 없는 한자만 있는 문단("han")은
  // 같은 이미지에 가나 문단이 있거나 페이지 lang이 ja/zh일 때만 그 값을 쓰고, 근거가 없으면 힌트 없이 둔다(번역 단계에서
  // 긴 글만 franc-min으로 판별, 짧으면 "판별 불가"로 남김). 수동 프로필: 사용자가 고른 언어가 힌트다.
  const refs = [];
  const hints = [];
  for (const region of perRegion) {
    const regionHasKana = region.items.some((item) => item.sh === "ja");
    for (const item of region.items) {
      let itemHint;
      if (!auto) itemHint = BarobogiOcr.OCR_PROFILES[profile].hint;
      else if (item.sh === "han") itemHint = regionHasKana ? "ja" : (pageHint === "ja" || pageHint === "zh") ? pageHint : null;
      else itemHint = item.sh || null;
      item.lh = itemHint || undefined;
      delete item.sh;
      refs.push(item);
      hints.push(itemHint);
    }
  }
  job.phase = "translate";
  let warning = missing.length ? BarobogiTranslate.warningFor(missing) : "";
  if (refs.length) {
    const result = await BarobogiTranslate.translateBatch(refs.map((item) => item.o), target, source, {
      hints, nativeFirst: settings.nativeFirst, isCancelled,
      ocrHints: true, // 라틴 글자 힌트는 OCR의 영어(eng) 데이터에서 온 것: 짧은 글에서 franc-min이 뒤집지 않게
      onProgress: (done, total) => { job.progress = `이미지 글자 번역 ${Math.floor(done)}/${total}`; renderJob(); sendAlive(); }
    });
    result.missing.forEach((m) => missing.push(m));
    warning = BarobogiTranslate.warningFor(missing);
    refs.forEach((item, i) => {
      item.t = typeof result.texts[i] === "string" ? result.texts[i] : "";
      if (result.langs[i]) { item.lang = result.langs[i]; item.sl = result.langs[i]; }
    });
  }
  const images = perRegion.map((region) => {
    const langs = {};
    for (const item of region.items) {
      if (item.lang) langs[item.lang] = (langs[item.lang] || 0) + 1;
      delete item.lang;
    }
    return { k: region.k, items: region.items, langs };
  });
  return { images, missing: [...new Set(missing)], warning };
}

async function dataUrlToBitmap(dataUrl) {
  const blob = await (await fetch(dataUrl)).blob();
  return createImageBitmap(blob);
}

function statusSnapshot() {
  const snap = BarobogiLocalModel.snapshot();
  return {
    active,
    // 팝업이 엔진 창과 같은 단계·바이트를 보여 줄 수 있게 실제 값만 넘긴다(번역 내용 없음).
    model: modelView(snap),
    ocr: BarobogiOcr.snapshot(),
    busy: !!running,
    queued: queue.length
  };
}

// MARK: 상태 표시

function renderRole() {
  $("roleNote").hidden = active || !port;
}

function renderJob() {
  if (!running) {
    $("jobStatus").textContent = queue.length ? `대기 ${queue.length}건` : "대기 중";
    $("ocrPhase").textContent = "";
    return;
  }
  const kind = running.message.type === "ocr" ? "이미지" : "글자";
  $("jobStatus").textContent = `처리 중: ${kind} 요청 · ${running.progress || "시작"}${queue.length ? ` · 대기 ${queue.length}건` : ""}`;
  $("ocrPhase").textContent = running.message.type === "ocr" && running.phase !== "translate" ? `지금: ${running.progress || "시작"}` : "";
}

function renderSteps(view) {
  const list = $("modelSteps");
  if (!list.children.length) {
    for (const label of BarobogiModelStatus.STEPS) { const li = document.createElement("li"); li.textContent = label; list.appendChild(li); }
  }
  [...list.children].forEach((li, index) => {
    const done = view.ready ? true : index < view.step;
    const current = !view.ready && index === view.step && (view.busy || view.downloading || view.step > 0);
    li.className = done ? "done" : current ? "current" : "";
    if (current) li.setAttribute("aria-current", "step"); else li.removeAttribute("aria-current");
  });
}

function renderModel(snap) {
  const m = modelView(snap);
  const view = BarobogiModelStatus.describe(m);
  const show = { downloadModel: false, cancelDownload: false, loadModel: false, restartModel: false, deleteModel: false };
  if (view.busy && (m.download === "permission" || view.downloading)) show.cancelDownload = true;
  else if (view.needsDownload && !m.otherWindow) { show.downloadModel = true; show.deleteModel = m.cache === "partial"; }
  else if (m.cache === "complete") {
    if (m.runtime === "ready") { show.restartModel = true; show.deleteModel = true; }
    else if (m.runtime === "loading") show.restartModel = true;
    else { show.loadModel = true; show.deleteModel = true; }
  }
  const button = $("downloadModel");
  button.textContent = m.download === "failed" || m.download === "cancelled" ? "다시 시도"
    : m.cache === "partial" || m.interrupted ? "이어서 내려받기" : `모델 내려받기 (약 ${Math.round(m.total / 1e6)}MB)`;
  button.disabled = BarobogiLocalModel.isDownloadBusy();
  $("cancelDownload").textContent = m.download === "permission" ? "권한 요청 취소" : "내려받기 취소";
  renderSteps(view);
  $("modelStage").textContent = view.stage;
  $("modelStatus").textContent = view.text;
  $("modelFile").textContent = view.file;
  $("modelFile").hidden = !view.file;
  $("modelBytes").textContent = view.bytes;
  $("modelWarn").textContent = view.warn;
  $("modelWarn").hidden = !view.warn;
  const permissionNote = view.downloading && m.permissionGranted === false
    ? "모델 서버 접근 권한을 거절해 공개 주소로 받는 중입니다." : "";
  if (permissionNote && !view.warn) { $("modelWarn").textContent = permissionNote; $("modelWarn").hidden = false; }
  $("keepOpen").hidden = !view.downloading;
  for (const [id, visible] of Object.entries(show)) $(id).hidden = !visible;
  const hasPercent = Number.isFinite(view.percent);
  $("modelProgressRow").hidden = !hasPercent;
  if (hasPercent) {
    $("modelProgressLabel").textContent = view.progressLabel;
    $("modelProgress").value = view.percent;
    $("modelProgress").setAttribute("aria-valuetext", `${view.progressLabel} ${view.percent}%${view.bytes ? ` · ${view.bytes}` : ""}`);
    $("modelPercent").textContent = `${view.percent}%`;
  }
  document.title = view.downloading && hasPercent ? `${view.percent}% 내려받는 중 — 바로보기 번역 엔진` : "바로보기 번역 엔진";
  $("setupBanner").hidden = m.cache === "complete" || (m.cache !== "missing" && m.cache !== "partial" && params.get("setup") !== "1");
}

function modelView(snap) {
  return {
    cache: snap.cache, cachedBytes: snap.cachedBytes, cachedFiles: snap.cachedFiles, runtime: snap.runtime, runtimeError: snap.runtimeError,
    download: snap.download, done: snap.downloadDone, total: snap.total, error: snap.downloadError, errorCode: snap.downloadErrorCode,
    file: snap.downloadFile, fileIndex: snap.downloadFileIndex, fileCount: snap.downloadFileCount || BarobogiLocalModel.MODEL.files.length,
    fileDone: snap.downloadFileDone, fileSize: snap.downloadFileSize, skipped: snap.downloadSkipped,
    stalled: snap.stalled, idleSeconds: snap.lastActivityAt ? Math.floor((Date.now() - snap.lastActivityAt) / 1000) : 0,
    interrupted: snap.interrupted, otherWindow: snap.otherWindow, foreign: snap.foreign, permissionGranted: snap.permissionGranted,
    loadFile: snap.loadFile, loadLoaded: snap.loadLoaded, loadTotal: snap.loadTotal
  };
}

// 캐시가 "완료"로 바뀌면(이 창이 받았든 다른 엔진 창이 받았든) 활성 엔진은 곧바로 메모리에 불러온다.
let lastCacheState = "";
BarobogiLocalModel.onChange((snap) => {
  renderModel(snap);
  if (snap.cache === "complete" && lastCacheState !== "complete") autoLoadModel();
  if (snap.cache !== "checking") lastCacheState = snap.cache;
});
// 무활동 초(네트워크 응답 없음 경고)는 시간이 흐르며 바뀌므로 내려받는 동안만 1초마다 다시 그린다.
setInterval(() => { if (BarobogiLocalModel.isDownloadBusy()) renderModel(BarobogiLocalModel.snapshot()); }, 1000);

function autoLoadModel() {
  const snap = BarobogiLocalModel.snapshot();
  if (active && snap.cache === "complete" && snap.runtime === "idle") BarobogiLocalModel.loadModel().catch(() => {});
}

// 내려받는 중 창을 닫으려 하면 브라우저 확인 창을 띄운다(닫으면 내려받기가 멈추기 때문).
window.addEventListener("beforeunload", (event) => {
  const snap = BarobogiLocalModel.snapshot();
  if (BarobogiLocalModel.isDownloadBusy() && snap.download !== "permission") { event.preventDefault(); event.returnValue = ""; }
});

// MARK: 모델 버튼

const DOWNLOAD_ORIGINS = ["https://huggingface.co/*", "https://*.hf.co/*"];

$("downloadModel").addEventListener("click", () => {
  // 클릭 즉시(권한 요청을 기다리기 전에) 화면을 "권한 요청 중"으로 바꾸고 버튼을 잠근다(중복 클릭 방지).
  if (BarobogiLocalModel.isDownloadBusy()) return;
  $("downloadModel").disabled = true;
  const ticket = BarobogiLocalModel.beginPermissionRequest();
  if (!ticket) return;
  // 선택 권한: 모델 주소(huggingface.co와 그 CDN *.hf.co)에만 접근을 요청한다. 사용자 클릭 안에서 곧바로 불러야 한다.
  // 거절해도 공개 CORS로 받기를 시도한다.
  let request = null;
  try { request = chrome.permissions.request({ origins: DOWNLOAD_ORIGINS }); } catch { request = null; }
  Promise.resolve(request)
    .then((granted) => (request === null ? null : granted === true), () => null)
    .then((granted) => BarobogiLocalModel.startDownload(ticket, { permissionGranted: granted }))
    .then((outcome) => { if (outcome === "done") autoLoadModel(); });
});
$("cancelDownload").addEventListener("click", () => BarobogiLocalModel.cancelDownload());
$("loadModel").addEventListener("click", () => BarobogiLocalModel.loadModel().catch(() => {}));
$("restartModel").addEventListener("click", () => {
  BarobogiLocalModel.terminateModel("사용자가 번역 Worker를 다시 시작했습니다.");
  autoLoadModel();
});
$("deleteModel").addEventListener("click", async () => {
  if (!confirm("내려받은 모델(약 640MB)을 이 브라우저에서 지울까요? 다시 쓰려면 다시 내려받아야 합니다.")) return;
  await BarobogiLocalModel.deleteCache();
});
$("openHelp").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("help.html") }).catch(() => window.open(chrome.runtime.getURL("help.html"), "_blank"));
});

// MARK: OCR

function refreshOcrStatus() {
  const snap = BarobogiOcr.snapshot();
  const profile = BarobogiOcr.OCR_PROFILES[settings.ocrLang] || BarobogiOcr.OCR_PROFILES.auto;
  const slotText = (slot, idle) => {
    if (slot.state === "preparing") return `준비 중${slot.stage ? ` · ${slot.stage}` : ""}${Number.isFinite(slot.progress) ? ` ${Math.round(slot.progress * 100)}%` : "…"}`;
    if (slot.state === "available") return `준비됨(${BarobogiOcr.langsLabel(slot.langs)})`;
    if (slot.state === "error") return `실패: ${slot.message || "준비하지 못했습니다."}`;
    return idle;
  };
  let text;
  if (typeof Tesseract === "undefined") text = "OCR 실행 파일을 불러오지 못했습니다(패키지 손상 가능).";
  else if (profile.auto) {
    text = `자동 인식 — 가로(영어·한국어·일본어·중국어 간체, 세로 블록 포함): ${slotText(snap.horizontal, "첫 이미지 요청 때 준비")} · ` +
      `세로(일본어 전체 스캔·정밀 인식): ${slotText(snap.vertical, "첫 이미지 요청 때 준비")}`;
  } else {
    const slot = profile.vertical ? snap.vertical : snap.horizontal;
    const matches = slot.langs === profile.tess;
    text = `수동: ${profile.label} — ${matches ? slotText(slot, "첫 이미지 요청 때 준비") : "첫 이미지 요청 때 준비"}`;
  }
  $("ocrStatus").textContent = text;
  const preparing = [snap.horizontal, snap.vertical].find((slot) => slot.state === "preparing");
  const pct = preparing && Number.isFinite(preparing.progress) ? Math.round(preparing.progress * 100) : null;
  $("ocrProgressRow").hidden = pct === null;
  if (pct !== null) {
    const stage = preparing.stage || "준비";
    $("ocrProgressLabel").textContent = `OCR 준비(${BarobogiOcr.langsLabel(preparing.langs)}) · ${stage}`;
    $("ocrProgress").value = pct;
    $("ocrProgress").setAttribute("aria-valuetext", `OCR 준비 · ${stage} ${pct}%`);
    $("ocrPercent").textContent = `${pct}%`;
  }
}

$("prepareOcr").addEventListener("click", async () => {
  $("prepareOcr").disabled = true;
  try {
    await BarobogiOcr.prepare(settings.ocrLang, () => refreshOcrStatus(), { includeVertical: true });
  } finally {
    $("prepareOcr").disabled = false;
    refreshOcrStatus();
  }
});

// MARK: 선택 엔진 — 브라우저 내장 번역

function renderNative() {
  if (!BarobogiTranslate.hasTranslatorApi()) { $("nativeGroup").hidden = true; return; }
  $("nativeGroup").hidden = false;
  $("nativeNote").textContent = IS_WHALE
    ? "이 브라우저에 Translator API가 보이지만 Whale에서의 동작은 확인하지 않았습니다. 쓰지 않아도 공통 로컬 모델로 번역됩니다."
    : "Chrome 기기 내 번역(Translator API). 준비 버튼을 누른 언어 조합만, 인스턴스가 실제로 만들어진 뒤에 씁니다.";
  $("nativeFirst").checked = settings.nativeFirst;
  const list = $("nativePairs");
  list.textContent = "";
  const sources = settings.source === "auto" ? BarobogiTranslate.LOCAL_LANGS : [settings.source];
  for (const lang of sources) {
    if (lang === settings.target) continue;
    const row = document.createElement("div");
    row.className = "pairRow";
    const button = document.createElement("button");
    const status = document.createElement("p");
    status.className = "statusLine";
    const paint = (snap) => {
      const text = { ready: "준비됨", downloading: `내려받는 중… ${Math.round((snap.progress || 0) * 100)}%`, unavailable: snap.message,
                     unsupported: snap.message, error: snap.message, downloadable: "내려받기 필요", available: "사용 가능(아직 만들지 않음)" }[snap.state];
      status.textContent = text || "확인 전";
    };
    button.textContent = `${lang} → ${settings.target} 내장 번역 준비`;
    button.addEventListener("click", async () => {
      button.disabled = true;
      try { paint(await BarobogiTranslate.prepareNative(lang, settings.target, () => paint(BarobogiTranslate.nativeSnapshot(lang, settings.target)))); }
      finally { button.disabled = false; }
    });
    row.append(button, status);
    list.appendChild(row);
    BarobogiTranslate.adoptNativeIfAvailable(lang, settings.target).then(paint, () => {});
  }
}

$("nativeFirst").addEventListener("change", (event) => {
  chrome.storage.local.set({ nativeFirst: event.target.checked }).catch(() => {});
});

// MARK: 설정(팝업과 공유, chrome.storage)

async function call(message) {
  const response = await chrome.runtime.sendMessage(message);
  if (!response || response.ok !== true) throw new Error(response?.message || "요청을 처리하지 못했습니다.");
  return response;
}

async function webTabId() {
  try {
    const win = await chrome.windows.getLastFocused({ windowTypes: ["normal"] });
    const [tab] = await chrome.tabs.query({ active: true, windowId: win.id });
    return Number.isInteger(tab?.id) ? tab.id : null;
  } catch {
    return null;
  }
}

$("target").addEventListener("change", async (event) => {
  await call({ cmd: "setTarget", target: event.target.value, tabId: await webTabId() }).catch(() => {});
});
$("source").addEventListener("change", async (event) => {
  await call({ cmd: "setSource", source: event.target.value, tabId: await webTabId() }).catch(() => {});
});
$("ocrLang").addEventListener("change", async (event) => {
  await call({ cmd: "setOcrLang", ocrLang: event.target.value, tabId: await webTabId() }).catch(() => {});
});

function applySettings(stored) {
  settings = {
    target: BarobogiTranslate.TARGET_LANGS.includes(stored.target) ? stored.target : "ko",
    source: BarobogiTranslate.SOURCE_LANGS.includes(stored.source) ? stored.source : "auto",
    ocrLang: BarobogiOcr.OCR_PROFILES[stored.ocrLang] ? stored.ocrLang : "auto",
    nativeFirst: stored.nativeFirst === true
  };
  $("target").value = settings.target;
  $("source").value = settings.source;
  $("ocrLang").value = settings.ocrLang;
  renderNative();
  refreshOcrStatus();
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (!["target", "source", "ocrLang", "nativeFirst"].some((key) => key in changes)) return;
  chrome.storage.local.get(SETTING_DEFAULTS).then(applySettings, () => {});
});

// MARK: 현재 웹 탭 상태(엔진 창 자신이 아니라 마지막으로 쓴 일반 창의 활성 탭)

function summarize(page) {
  if (!page) return "";
  const parts = [];
  if (Number.isInteger(page.inventory?.textSentences)) parts.push(`일반 ${page.inventory.textSentences}문장`);
  if (Number.isInteger(page.inventory?.imageSentences)) parts.push(`이미지 속 ${page.inventory.imageSentences}문장`);
  return parts.join(" · ");
}

async function refreshPageStatus() {
  try {
    const tabId = await webTabId();
    const response = await call({ cmd: "pageProgress", tabId });
    const page = response.page;
    $("pageStatus").textContent = page ? `${page.view === "translated" ? "번역 표시" : "원문 표시"} · ${page.warning || page.status || ""}` : "현재 웹 탭은 아직 번역하지 않았습니다.";
    $("pageSummary").textContent = summarize(page);
  } catch {
    $("pageStatus").textContent = "탭 상태를 불러오지 못했습니다.";
  }
}

(async () => {
  let context = params.get("context");
  if (!context) {
    let tab = null;
    try { tab = await chrome.tabs.getCurrent(); } catch { tab = null; }
    context = tab ? "tab" : "panel";
  }
  $("contextLabel").textContent = { window: "엔진 창", panel: "사이드패널", tab: "탭" }[context] || "";
  $("versionLabel").textContent = `v${chrome.runtime.getManifest().version}`;
  try {
    applySettings(await chrome.storage.local.get(SETTING_DEFAULTS));
  } catch { applySettings({}); }
  renderModel(BarobogiLocalModel.snapshot());
  await BarobogiLocalModel.checkCache();
  connectEnginePort();
  refreshPageStatus();
  setInterval(refreshPageStatus, 2000);
  try { await navigator.storage?.persist?.(); } catch { /* 지원하지 않으면 무시 */ }
})();
