"use strict";
// 바로보기 웹 번역 — 모델 다운로드 전용 Worker(엔진 문서가 만들고, 취소하면 terminate한다).
// - model-spec.js에 고정된 파일만, 고정 리비전 URL에서만 받는다. 요청에는 쿠키·리퍼러·번역할 내용이 없다(credentials: omit).
// - 받는 동안 바이트 수·SHA-256(큰 파일)·git blob SHA-1(작은 JSON)을 확인하고, 크기·해시가 맞을 때만 "검증됨" 표시를 남긴다.
//   검증 표시가 없는 항목은 다음 실행 때 다시 받는다(중간에 꺼져 생긴 불완전한 항목을 쓰지 않음). 이어받기(Range)는 하지 않으므로
//   중간에 끊긴 파일은 처음부터 다시 받고, 검증을 마친 파일만 건너뛴다.
// - 모든 파일이 검증되면 완료 표시(readyMarker)를 남긴다. 엔진은 완료 표시가 있을 때만 모델을 불러온다.
// - 단계 알림(phase): checking(저장된 파일 확인) → connecting(서버 응답 대기) → downloading(실제 바이트 수신) →
//   verifying(마지막 바이트 뒤 해시 확인·저장) → finalizing(완료 표시 저장). 진행률은 실제로 받은 바이트만 센다.
// - 네트워크에서 INACTIVITY_MS 동안 한 바이트도 오지 않으면(연결 대기 포함) 요청을 끊고 "stalled" 오류로 끝낸다.
importScripts("model-spec.js", "sha256.js");

const SPEC = self.BAROBOGI_MODEL;
const urlOf = self.BAROBOGI_MODEL_URL;
const VERIFIED_SUFFIX = self.BAROBOGI_VERIFIED_SUFFIX;
const READY_URL = self.BAROBOGI_MODEL_READY_URL;
const PROGRESS_INTERVAL = 250;
const INACTIVITY_MS = 60000;

function hex(buffer) {
  return Array.from(new Uint8Array(buffer), (b) => b.toString(16).padStart(2, "0")).join("");
}

async function isVerified(cache, file) {
  const [entry, mark] = await Promise.all([cache.match(urlOf(file.path)), cache.match(urlOf(file.path) + VERIFIED_SUFFIX)]);
  if (!entry || !mark) return false;
  try { return (await mark.json()).size === file.size; } catch { return false; }
}

function codedError(code, message) {
  return Object.assign(new Error(message), { code });
}

/** 무활동 감시: touch()가 INACTIVITY_MS 동안 불리지 않으면 fetch를 끊는다. */
function watchdog(file) {
  const controller = new AbortController();
  let timer = 0;
  let stalled = false;
  const touch = () => {
    clearTimeout(timer);
    timer = setTimeout(() => { stalled = true; controller.abort(); }, INACTIVITY_MS);
  };
  const stop = () => clearTimeout(timer);
  const translate = (error) => {
    if (stalled) {
      return codedError("stalled", `네트워크에서 ${INACTIVITY_MS / 1000}초 동안 데이터를 받지 못해 중단했습니다(${file.path}).`);
    }
    return error && error.code ? error : codedError("network", `내려받는 중 연결이 끊겼습니다(${file.path}): ${error && error.message ? error.message : error}`);
  };
  touch();
  return { signal: controller.signal, touch, stop, translate };
}

async function fetchFile(file, guard) {
  let response;
  try {
    response = await fetch(urlOf(file.path), {
      credentials: "omit", cache: "no-store", redirect: "follow", referrerPolicy: "no-referrer", mode: "cors", signal: guard.signal
    });
  } catch (error) {
    const translated = guard.translate(error);
    if (translated.code === "network") translated.message = `내려받기 연결 실패(${file.path}): ${error && error.message ? error.message : error}`;
    throw translated;
  }
  if (response.status !== 200 || !response.body) {
    throw codedError("http", `내려받기 실패(${file.path}): HTTP ${response.status}`);
  }
  guard.touch();
  return response;
}

/** 작은 JSON 파일: 스트림으로 받아(진행 표시) 메모리에 모은 뒤 git blob SHA-1을 확인하고 저장한다. */
async function downloadSmall(cache, file, report, phase) {
  const guard = watchdog(file);
  try {
    const response = await fetchFile(file, guard);
    phase("downloading");
    const reader = response.body.getReader();
    const chunks = [];
    let received = 0;
    for (;;) {
      let step;
      try { step = await reader.read(); } catch (error) { throw guard.translate(error); }
      if (step.done) break;
      guard.touch();
      received += step.value.length;
      if (received > file.size) { reader.cancel().catch(() => {}); throw codedError("size", `받은 크기가 예상보다 큽니다(${file.path})`); }
      chunks.push(step.value);
      report(step.value.length);
    }
    guard.stop();
    phase("verifying");
    if (received !== file.size) throw codedError("size", `크기가 다릅니다(${file.path}): ${received} ≠ ${file.size}`);
    const body = new Uint8Array(received);
    let offset = 0;
    for (const chunk of chunks) { body.set(chunk, offset); offset += chunk.length; }
    const header = new TextEncoder().encode(`blob ${body.length}\0`);
    const joined = new Uint8Array(header.length + body.length);
    joined.set(header, 0);
    joined.set(body, header.length);
    const sha1 = hex(await crypto.subtle.digest("SHA-1", joined));
    if (sha1 !== file.gitSha1) throw codedError("hash", `해시가 다릅니다(${file.path})`);
    await cache.put(urlOf(file.path), new Response(body, {
      headers: { "content-type": "application/json", "content-length": String(body.length) }
    }));
  } finally {
    guard.stop();
  }
}

/** 큰 ONNX 파일: 스트림으로 받으면서 SHA-256을 갱신하고, 같은 스트림을 그대로 Cache API에 쓴다(전체를 메모리에 두지 않음). */
async function downloadLarge(cache, file, report, phase) {
  const guard = watchdog(file);
  const url = urlOf(file.path);
  try {
    const response = await fetchFile(file, guard);
    phase("downloading");
    const reader = response.body.getReader();
    const hasher = new self.BarobogiSha256();
    let received = 0;
    let streamError = null;
    const stream = new ReadableStream({
      async pull(controller) {
        let step;
        try { step = await reader.read(); } catch (error) { streamError = guard.translate(error); controller.error(streamError); return; }
        if (step.done) { guard.stop(); phase("verifying"); controller.close(); return; }
        guard.touch();
        received += step.value.length;
        if (received > file.size) {
          streamError = codedError("size", `받은 크기가 예상보다 큽니다(${file.path})`);
          controller.error(streamError);
          reader.cancel().catch(() => {});
          return;
        }
        hasher.update(step.value);
        report(step.value.length);
        controller.enqueue(step.value);
      },
      cancel(reason) { reader.cancel(reason).catch(() => {}); }
    });
    try {
      await cache.put(url, new Response(stream, {
        headers: { "content-type": "application/octet-stream", "content-length": String(file.size) }
      }));
    } catch (error) {
      throw streamError || guard.translate(error);
    }
    if (received !== file.size) throw codedError("size", `크기가 다릅니다(${file.path}): ${received} ≠ ${file.size}`);
    if (hasher.hex() !== file.sha256) throw codedError("hash", `SHA-256이 다릅니다(${file.path})`);
  } catch (error) {
    await cache.delete(url).catch(() => {});
    throw error;
  } finally {
    guard.stop();
  }
}

async function run() {
  const total = self.BAROBOGI_MODEL_TOTAL;
  const count = SPEC.files.length;
  let done = 0;
  let lastPost = 0;
  let current = null, index = -1, fileDone = 0, skipped = 0;
  const post = (force = false) => {
    const now = Date.now();
    if (!force && now - lastPost < PROGRESS_INTERVAL) return;
    lastPost = now;
    self.postMessage({ type: "progress", done, total, file: current ? current.path : null, fileIndex: index, fileCount: count,
                       fileDone, fileSize: current ? current.size : 0, skipped });
  };
  const phase = (name) => {
    self.postMessage({ type: "phase", phase: name, file: current ? current.path : null, fileIndex: index, fileCount: count,
                       fileSize: current ? current.size : 0, done, skipped });
  };
  phase("checking");
  const cache = await caches.open(SPEC.cacheName);
  for (let i = 0; i < count; i += 1) {
    const file = SPEC.files[i];
    current = file;
    index = i;
    fileDone = 0;
    if (await isVerified(cache, file)) { done += file.size; skipped += 1; fileDone = file.size; post(true); continue; }
    const startDone = done;
    const report = (bytes) => { done += bytes; fileDone += bytes; post(); };
    phase("connecting");
    try {
      if (file.sha256) await downloadLarge(cache, file, report, phase);
      else await downloadSmall(cache, file, report, phase);
    } catch (error) {
      done = startDone;
      throw error;
    }
    await cache.put(urlOf(file.path) + VERIFIED_SUFFIX, new Response(JSON.stringify({ size: file.size, at: Date.now() }), {
      headers: { "content-type": "application/json" }
    }));
    done = startDone + file.size;
    post(true);
  }
  current = null;
  index = count;
  phase("finalizing");
  await cache.put(READY_URL, new Response(JSON.stringify({ revision: SPEC.revision, total, at: Date.now() }), {
    headers: { "content-type": "application/json" }
  }));
  self.postMessage({ type: "done", done, total, skipped });
}

self.onmessage = (event) => {
  if (!event.data || event.data.type !== "start") return;
  run().catch((error) => {
    const quota = error && (error.name === "QuotaExceededError" || /quota/i.test(String(error.message)));
    self.postMessage({
      type: "error",
      code: quota ? "quota" : (error && error.code) || "error",
      message: quota ? "저장 공간이 부족해 모델을 저장하지 못했습니다(약 640MB 필요)." : String((error && error.message) || error)
    });
  });
};
