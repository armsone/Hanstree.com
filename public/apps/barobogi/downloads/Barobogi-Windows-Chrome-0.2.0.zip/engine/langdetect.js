"use strict";
// 바로보기 웹 번역 — 원문 언어 판별(엔진 문서 전용). 로컬 M2M100은 원문 언어 코드를 직접 넘겨야 하므로 자동 감지가 필요하다.
// - 유니코드 문자 종류(한글·가나·한자·라틴)를 먼저 센다. 가나가 있으면 일본어, 한글이 대부분이면 한국어처럼 문자 자체가
//   확실한 신호인 경우만 바로 정한다.
// - 라틴 문자는 패키지에 포함한 franc-min(vendor/franc, MIT)으로 판별하고, 영어로 판정될 때만 en으로 둔다
//   (프랑스어 등 다른 라틴 언어를 영어로 우기지 않는다).
// - 가나 없는 한자만 있는 짧은 글은 중국어·일본어를 가를 근거가 없다: 페이지 lang 속성이나 OCR 언어 같은 실제 힌트가
//   있을 때만 그 값을 쓰고, 없으면 "unknown"으로 둔다(지어내지 않음). 긴 한자 문장은 franc-min(cmn/jpn 제한)으로 판별한다.

const HANGUL = /[ᄀ-ᇿ㄰-㆏가-힣]/gu;
const KANA = /[぀-ゟ゠-ヿㇰ-ㇿｦ-ﾝ]/gu;
const HAN = /[㐀-䶿一-鿿豈-﫿]/gu;
const LATIN = /[A-Za-zÀ-ɏ]/gu;
const SHORT_HAN = 8;
const MIN_FRANC_LATIN = 12;
const MIN_FRANC_LATIN_OCR = 40; // OCR 라틴 글자(영어 데이터로만 읽힘)의 "en" 힌트를 franc-min이 뒤집을 수 있는 최소 글자 수

const count = (text, re) => (text.match(re) || []).length;

/** hint: "ko"|"en"|"ja"|"zh"|null — 페이지 lang 속성 또는 OCR 언어(사용자가 고른 프로필)에서 온 실제 신호.
 *  options.ocr: hint가 OCR 결과의 문자 종류에서 온 값인지. OCR의 라틴 글자는 영어(eng) 데이터로만 읽히므로 "en" 힌트가 강한 근거다:
 *  짧거나 OCR 오류가 섞인 글은 franc-min이 다른 언어로 오판하기 쉬워, 충분히 긴 글에서만 franc-min 판정으로 뒤집는다. */
function detectSourceLanguage(text, hint, { ocr = false } = {}) {
  const sample = String(text || "").slice(0, 2000);
  const hangul = count(sample, HANGUL), kana = count(sample, KANA), han = count(sample, HAN), latin = count(sample, LATIN);
  const letters = hangul + kana + han + latin;
  if (!letters) return "unknown";
  if (hangul / letters >= 0.5) return "ko";
  if (kana > 0 && (kana + han) / letters >= 0.5) return "ja";
  if (han / letters >= 0.5) {
    if (hint === "ja" || hint === "zh") return hint;
    if (han < SHORT_HAN || typeof BarobogiFranc === "undefined") return "unknown";
    const code = BarobogiFranc.franc(sample, { only: ["cmn", "jpn"], minLength: SHORT_HAN });
    return code === "cmn" ? "zh" : code === "jpn" ? "ja" : "unknown";
  }
  if (latin / letters >= 0.5) {
    const minLatin = ocr && hint === "en" ? MIN_FRANC_LATIN_OCR : MIN_FRANC_LATIN;
    if (latin >= minLatin && typeof BarobogiFranc !== "undefined") {
      const code = BarobogiFranc.franc(sample, { minLength: minLatin });
      if (code === "eng") return "en";
      if (code !== "und") return "unknown"; // 영어가 아닌 라틴 언어: 이 확장의 원문 언어 목록 밖
    }
    return hint === "en" ? "en" : "unknown";
  }
  return "unknown";
}

/** 페이지 lang 속성("ja-JP", "zh-Hant-TW" 등)이나 OCR 프로필을 모델 언어 코드 힌트로 바꾼다. */
function normalizeHint(value) {
  const lower = String(value || "").toLowerCase();
  if (/^ko\b/.test(lower) || lower === "kor") return "ko";
  if (/^ja\b/.test(lower) || lower === "jpn" || lower === "jpn_vert") return "ja";
  if (/^zh\b/.test(lower) || lower === "chi_sim") return "zh";
  if (/^en\b/.test(lower) || lower === "eng") return "en";
  return null;
}

globalThis.BarobogiLangDetect = { detectSourceLanguage, normalizeHint };
