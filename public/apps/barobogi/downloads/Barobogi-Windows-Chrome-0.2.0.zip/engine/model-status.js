"use strict";
// 바로보기 웹 번역 — 로컬 번역 모델 상태 문구(엔진 문서와 팝업이 함께 쓴다). 실제 상태 값만 문장으로 바꾼다:
// 진행률은 실제로 받은 바이트로만 계산하고, 100%는 모든 파일 검증 뒤 완료 표시(readyMarker)가 저장된 경우에만 보인다.
// 입력 m: 엔진 문서 statusSnapshot().model 모양(cache, cachedBytes, cachedFiles, download, done, total, file, fileIndex, ...).

(() => {
  const STEPS = ["내려받기", "검증·저장", "메모리에 불러오기", "준비됨"];
  const MB = (n) => `${(Math.max(0, Number(n) || 0) / 1e6).toFixed(1)}MB`; // 10진 MB(1MB = 1,000,000바이트, "약 640MB"와 같은 단위)
  const pctOf = (done, total) => (total > 0 ? Math.max(0, Math.min(99, Math.floor((done / total) * 100))) : 0);
  const BUSY = new Set(["permission", "starting", "checking", "connecting", "running", "verifying", "finalizing"]);

  function describe(m) {
    const total = Number(m.total) || 0;
    const count = Number(m.fileCount) || 7;
    const fileName = m.file ? String(m.file).split("/").pop() : "";
    const fileLine = m.file && m.fileIndex >= 0 && m.fileIndex < count
      ? `파일 ${m.fileIndex + 1}/${count}: ${fileName}${m.fileSize ? ` — ${MB(m.fileDone)} / ${MB(m.fileSize)}` : ""}` : "";
    const out = { stage: "", text: "", percent: null, progressLabel: "내려받기", bytes: "", file: "", warn: "", step: 0,
                  busy: false, downloading: false, needsDownload: false, canRetry: false, ready: false };
    const dl = m.download;

    if (BUSY.has(dl)) {
      out.busy = true;
      out.downloading = dl !== "permission";
      out.percent = pctOf(m.done, total);
      out.bytes = `받은 양: ${MB(m.done)} / ${MB(total)}${m.skipped ? ` · 이미 검증된 파일 ${m.skipped}개는 건너뜀` : ""}`;
      out.file = fileLine;
      if (dl === "permission") {
        out.stage = "브라우저 권한 요청 중";
        out.text = "브라우저가 띄운 권한 확인 창에서 '허용'을 눌러 주세요. huggingface.co와 그 다운로드 서버(*.hf.co)의 모델 파일 접근만 요청합니다. 거절해도 공개 주소로 받기를 시도합니다. 확인 창이 안 보이면 이 창을 한 번 클릭해 앞으로 가져오세요.";
        out.percent = null;
        out.file = "";
      } else if (dl === "starting" || dl === "checking") {
        out.stage = "내려받기 준비 중";
        out.text = "이미 저장·검증된 파일이 있는지 확인하는 중…";
      } else if (dl === "connecting") {
        out.stage = `서버 연결 중 (${out.percent}%)`;
        out.text = "Hugging Face 서버의 응답을 기다리는 중…";
      } else if (dl === "running") {
        out.stage = `내려받는 중 ${out.percent}%`;
        out.text = "모델 파일을 받는 중입니다. 이 창을 닫으면 내려받기가 멈춥니다.";
      } else if (dl === "verifying") {
        out.stage = `검증·저장 중 (${out.percent}%)`;
        out.text = `${fileName || "파일"}의 크기·해시를 확인하고 저장하는 중…`;
        out.step = 1;
      } else {
        out.stage = "완료 표시 저장·확인 중";
        out.text = "모든 파일 검증을 마쳤습니다. 완료 표시를 저장하고 저장소에서 다시 확인하는 중…";
        out.step = 1;
      }
      if (m.stalled && (dl === "connecting" || dl === "running")) {
        out.warn = `네트워크에서 ${m.idleSeconds || 20}초째 데이터가 오지 않습니다. 인터넷 연결을 확인하세요. 60초 동안 응답이 없으면 자동으로 중단되며, ` +
          "'다시 시도'를 누르면 검증된 파일은 건너뛰고 받던 파일은 처음부터 다시 받습니다.";
      }
      return out;
    }

    if (m.cache === "checking" || m.cache === "unknown" || !m.cache) {
      out.stage = "저장된 모델 확인 중";
      out.text = "이 브라우저 저장소를 확인하는 중…(네트워크를 쓰지 않음)";
      out.busy = true;
      return out;
    }
    if (m.cache === "error") {
      out.stage = "저장소 확인 실패";
      out.text = m.error || "브라우저 저장소를 확인하지 못했습니다.";
      out.needsDownload = true;
      out.canRetry = true;
      return out;
    }
    if (m.cache !== "complete") {
      out.needsDownload = true;
      out.percent = m.cachedBytes > 0 ? pctOf(m.cachedBytes, total) : null;
      out.bytes = m.cachedFiles > 0
        ? `검증된 파일 ${m.cachedFiles}/${count}개 저장됨 (${MB(m.cachedBytes)} / ${MB(total)}). 다시 받으면 이 파일들은 건너뛰고, 중간에 끊긴 파일은 처음부터 다시 받습니다.`
        : `저장된 파일 없음 · 전체 ${MB(total)} (${total.toLocaleString("ko-KR")}바이트, 파일 ${count}개)`;
      if (m.otherWindow) {
        // 다른 엔진 문서(엔진 창·사이드패널)가 내려받기 잠금을 쥐고 있다: 그 문서가 알린 실제 진행만 보인다.
        const f = m.foreign || {};
        const PHASE = { starting: "준비 중", checking: "준비 중", connecting: "서버 연결 중", running: "내려받는 중", verifying: "검증·저장 중", finalizing: "완료 표시 저장 중" };
        out.busy = true;
        if (Number.isFinite(f.done)) {
          out.percent = pctOf(f.done, total);
          out.bytes = `받은 양: ${MB(f.done)} / ${MB(total)}`;
        }
        const fCount = Number(f.fileCount) || count;
        if (f.file && f.fileIndex >= 0 && f.fileIndex < fCount) {
          out.file = `파일 ${f.fileIndex + 1}/${fCount}: ${String(f.file).split("/").pop()}${f.fileSize ? ` — ${MB(f.fileDone)} / ${MB(f.fileSize)}` : ""}`;
        }
        out.stage = `다른 엔진 창에서 ${PHASE[f.phase] || "내려받는 중"}${out.percent !== null ? ` ${out.percent}%` : ""}`;
        out.text = "다른 번역 엔진 창(또는 사이드패널)이 내려받고 있습니다. 그 창을 열어 두세요. 끝나면 이 창도 저장된 모델을 자동으로 확인해 불러옵니다.";
        out.step = f.phase === "verifying" || f.phase === "finalizing" ? 1 : 0;
      } else if (dl === "failed") {
        out.stage = m.errorCode === "stalled" ? "네트워크 응답 없음으로 중단됨" : "내려받기 실패";
        out.text = m.error || "내려받지 못했습니다.";
        out.canRetry = true;
      } else if (dl === "cancelled") {
        out.stage = "취소됨";
        out.text = m.error || "내려받기를 취소했습니다.";
        out.canRetry = true;
      } else if (m.interrupted) {
        out.stage = "중단됨(엔진 창이 닫힘)";
        out.text = "이전 내려받기가 번역 엔진 창이 닫히면서 멈췄습니다. 아래 버튼으로 이어서 받으세요.";
        out.canRetry = true;
      } else if (m.cache === "partial") {
        out.stage = "일부만 저장됨";
        out.text = "모델 파일 일부만 저장되어 있습니다. 이어서 받아야 번역할 수 있습니다.";
        out.canRetry = true;
      } else {
        out.stage = "모델 필요(아직 받지 않음)";
        out.text = `처음 한 번 공통 로컬 번역 모델(약 ${Math.round(total / 1e6)}MB)을 내려받아야 합니다. 버튼을 누르기 전에는 아무것도 받지 않습니다.`;
      }
      return out;
    }

    out.bytes = `저장됨(검증 완료): ${MB(total)} (${total.toLocaleString("ko-KR")}바이트, 파일 ${count}개)`;
    if (m.runtime === "ready") {
      out.stage = "준비됨";
      out.text = "다운로드·검증 완료, 메모리에 불러옴 — 이 PC에서 번역할 수 있습니다.";
      out.percent = 100;
      out.progressLabel = "준비";
      out.step = 3;
      out.ready = true;
    } else if (m.runtime === "loading") {
      out.stage = "메모리에 불러오는 중";
      out.progressLabel = "불러오기";
      out.step = 2;
      out.busy = true;
      const hasLoad = Number.isFinite(m.loadLoaded) && Number.isFinite(m.loadTotal) && m.loadTotal > 0;
      out.percent = hasLoad ? Math.min(100, Math.floor((m.loadLoaded / m.loadTotal) * 100)) : null;
      out.text = "다운로드는 끝났습니다(100% 검증됨). 저장된 모델을 메모리에 불러오는 중이며 네트워크는 쓰지 않습니다. PC에 따라 수십 초~몇 분 걸릴 수 있습니다.";
      out.file = m.loadFile ? `불러오는 파일: ${String(m.loadFile).split("/").pop()}${hasLoad ? ` ${out.percent}%` : ""}` : "";
    } else if (m.runtime === "error") {
      out.stage = "불러오기 실패";
      out.text = m.runtimeError || "모델을 메모리에 불러오지 못했습니다.";
      out.step = 2;
    } else {
      out.stage = "내려받음(검증됨) · 아직 불러오지 않음";
      out.text = "번역 엔진 창이 활성일 때 자동으로 메모리에 불러옵니다.";
      out.step = 2;
    }
    return out;
  }

  globalThis.BarobogiModelStatus = { describe, STEPS, MB };
})();
