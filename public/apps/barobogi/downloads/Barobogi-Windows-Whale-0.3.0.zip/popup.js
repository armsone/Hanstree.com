"use strict";
// 바로보기 웹 번역 팝업(Chrome·Whale 공통, Mac 바로보기 팝업과 같은 사용 방식):
// - 아이콘을 눌러 팝업이 열리면 '번역 보기'로 전환한다(토글 아님). 이미 번역 보기이거나 번역 중이면 다시 번역하지 않는다.
//   이때는 권한 창을 띄우지 않고, 이미 허용된 범위(지금 탭) 안에서만 번역한다.
// - '번역' 버튼: 사용자 클릭 안에서 모든 사이트 접근을 요청해 전역 자동 번역을 켠다. 거절하면 지금 탭만 번역한다.
// - '원문' 버튼: 전역 자동 번역을 끄고 원문으로 되돌린다.
// - 번역에 필요한 파일(약 640MB)이 없으면 짧은 설명과 '번역 준비하기' 버튼을 보인다. 버튼 클릭 안에서 모델 주소 접근을 요청하고,
//   허용되면 배경이 숨은 엔진 문서에서 받는다(팝업을 닫아도 계속). 다시 열면 실제 상태를 다시 읽는다.
// - 준비가 끝나면 지금 이 팝업에서 한 번만 번역을 이어 간다(팝업을 닫았거나, 원문을 눌렀거나, 다른 탭·주소로 옮겼으면 하지 않음).
// 번역 대상 탭은 팝업을 연 창의 활성 웹 탭으로 고정한다.
const $ = (id) => document.getElementById(id);
const ALL_URLS = "<all_urls>";
const DOWNLOAD_ORIGINS = ["https://huggingface.co/*", "https://*.hf.co/*"]; // 번역 모델 파일 주소(선택 권한, 배경과 같은 값)
const OPENED_AT = Date.now();
const POLL_MS = 1000;
const POLL_MAX_MS = 10000;
let tabId = null;
let origin = null;
let current = null;
let notice = "";
let closed = false;
let resumeTranslate = false; // 준비가 끝나면 이 팝업에서 한 번만 번역을 이어 갈지
// 자동 번역(열 때·준비 뒤 이어 가기) 취소 세대: 사용자가 원문·준비 취소·번역을 누르거나 팝업이 닫히면 동기로 올린다.
// 자동 흐름은 시작할 때 값을 잡고 각 await 뒤 다시 비교해, 바뀌었으면 요청을 보내지 않는다(이미 보낸 요청은 배경 세대가 막는다).
let autoGen = 0;
let pollTimer = 0;
let pollFailures = 0;
let refreshing = false;
let refreshAgain = false;

function cancelAuto() {
  autoGen += 1;
  resumeTranslate = false;
}

window.addEventListener("pagehide", () => { closed = true; cancelAuto(); clearTimeout(pollTimer); pollTimer = 0; });

function originOf(url) {
  try {
    const parsed = new URL(url || "");
    return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.origin : null;
  } catch {
    return null;
  }
}

function showError(message) {
  $("error").textContent = message || "";
  $("error").hidden = !message;
}

/** 사용자 동작의 결과 안내·오류: 다음 새로 고침에도 남는다(갱신 실패 안내는 다음 성공 때 지워진다). */
function tell(message) {
  notice = message || "";
  showError(notice);
}

async function call(message) {
  const response = await chrome.runtime.sendMessage({ ...message, tabId });
  if (!response || response.ok !== true) throw Object.assign(new Error(response?.message || "요청을 처리하지 못했어요."), { code: response?.code });
  return response;
}

function schedule(ms) {
  clearTimeout(pollTimer);
  pollTimer = 0;
  if (!closed) pollTimer = setTimeout(refresh, ms);
}

// MARK: 화면

function translateAllowed() {
  return tabId !== null && !!current && modelState(current).kind === "ready";
}

function modelState(state) {
  const engine = state.engine || {};
  if (!engine.connected) return { kind: engine.code === "unsupported_browser" ? "unsupported" : "offline", title: engine.message || "번역 준비와 연결하지 못했어요. 잠시 뒤 다시 확인합니다." };
  return BarobogiModelStatus.describe(engine.model);
}

function renderSetup(view) {
  const show = view.kind !== "ready";
  $("setup").hidden = !show;
  if (!show) return;
  $("setupTitle").textContent = view.title;
  const hasPercent = Number.isFinite(view.percent) && view.kind !== "needed" && view.kind !== "failed";
  $("setupProgressRow").hidden = !hasPercent;
  if (hasPercent) {
    $("setupProgress").value = view.percent;
    $("setupProgress").setAttribute("aria-valuetext", `${view.title}${view.bytes ? ` · ${view.bytes}` : ""}`);
    $("setupPercent").textContent = `${view.percent}%`;
  }
  $("setupBytes").textContent = view.bytes ? `받은 양 ${view.bytes}` : "";
  $("setupBytes").hidden = !view.bytes;
  $("setupDetail").textContent = view.detail || "";
  $("setupDetail").hidden = !view.detail;
  $("prepare").hidden = !view.action;
  $("prepare").textContent = view.actionLabel || "번역 준비하기";
  $("cancelPrepare").hidden = !view.canCancel;
}

function renderPill(view) {
  const pill = $("engine");
  if (view.kind === "ready") { pill.textContent = "준비됨"; pill.className = "pill ok"; }
  else if (view.kind === "working" || view.kind === "finishing") {
    pill.textContent = Number.isFinite(view.percent) ? `준비 중 ${view.percent}%` : "준비 중";
    pill.className = "pill";
  } else if (view.kind === "checking") { pill.textContent = "확인 중"; pill.className = "pill"; }
  else if (view.kind === "unsupported") { pill.textContent = "업데이트 필요"; pill.className = "pill bad"; }
  else if (view.kind === "offline") { pill.textContent = "연결 안 됨"; pill.className = "pill bad"; }
  else { pill.textContent = "준비 필요"; pill.className = "pill bad"; }
}

function render(state) {
  current = state;
  const view = modelState(state);
  renderPill(view);
  renderSetup(view);
  $("target").value = ["ko", "en", "ja", "zh"].includes(state.settings.target) ? state.settings.target : "ko";
  $("fontStyle").value = ["auto", "gothic", "myeongjo", "gungseo", "hand"].includes(state.settings.fontStyle) ? state.settings.fontStyle : "auto";
  $("source").value = state.settings.source;
  $("ocrLang").value = state.settings.ocrLang;
  $("pageText").checked = state.settings.pageText === true;
  const ready = view.kind === "ready";
  $("translate").disabled = !translateAllowed();
  // 이 탭이 아직 번역되지 않았어도 전역 자동 번역이 켜져 있으면 전역으로 끌 수 있어야 한다.
  $("original").disabled = !state.page && !state.settings.automaticEnabled && !resumeTranslate;
  const isTranslated = state.page?.view === "translated";
  $("translate").classList.toggle("active", isTranslated);
  $("original").classList.toggle("active", !isTranslated);
  $("autoStatus").textContent = state.settings.automaticEnabled ? "자동 번역 켜짐"
    : state.grant ? "자동 번역 꺼짐" : "자동 번역 꺼짐 · 접근 허용 필요";
  const running = state.page?.running === true;
  $("spinner").hidden = !running;
  $("translateSpinner").hidden = !running;
  let status = "";
  if (state.page) status = state.page.error || state.page.warning || state.page.status || "";
  else if (!origin) status = "이 페이지는 번역할 수 없어요. 일반 웹사이트에서 사용해 주세요.";
  else if (!ready && resumeTranslate) status = "준비가 끝나면 이 페이지를 번역해요.";
  $("statusText").textContent = status;
  const inventory = state.page?.inventory;
  const parts = [];
  if (Number.isInteger(inventory?.images) && inventory.images > 0) parts.push(`이미지 ${inventory.images}개`);
  const sentences = (Number.isInteger(inventory?.textSentences) ? inventory.textSentences : 0) +
    (Number.isInteger(inventory?.imageSentences) ? inventory.imageSentences : 0);
  if (sentences > 0) parts.push(`${sentences}문장`);
  $("summary").textContent = parts.join(" · ");
  $("summary").hidden = parts.length === 0;
  showError(notice);
  if (ready && resumeTranslate) continueAfterReady();
  const keepPolling = running || ["working", "finishing", "checking", "offline"].includes(view.kind);
  if (keepPolling) schedule(view.kind === "offline" ? 2000 : POLL_MS);
}

async function refresh() {
  if (closed) return;
  if (refreshing) { refreshAgain = true; return; }
  refreshing = true;
  clearTimeout(pollTimer);
  pollTimer = 0;
  try {
    const state = await call({ cmd: "popupState" });
    pollFailures = 0;
    if (!closed) render(state);
  } catch (error) {
    showError(error.message);
    // 일시적인 요청 실패(서비스 워커 재시작 등)로 갱신이 멈추지 않게 같은 타이머로 간격을 늘려 다시 묻는다.
    pollFailures += 1;
    schedule(Math.min(POLL_MAX_MS, POLL_MS * 2 ** (pollFailures - 1)));
  } finally {
    refreshing = false;
    if (refreshAgain && !closed) { refreshAgain = false; refresh(); }
  }
}

// MARK: 번역 보기

// gesture=true(버튼 클릭)일 때만 권한 요청을 쓴다 — 클릭 처리의 첫 동작(어떤 await보다 먼저)이어야 확인 창이 뜬다.
// gesture=false(팝업이 열리며 자동 실행·준비 뒤 이어 가기)는 권한 창을 띄우지 않고 이미 허용돼 있는지만 확인한다.
// 자동 실행은 gen(시작 때 autoGen)이 그대로이고 연 탭이 아직 활성·같은 출처일 때만 보낸다.
async function runTranslate(gesture, clickedAt, gen) {
  let permission;
  try {
    permission = Promise.resolve(gesture ? chrome.permissions.request({ origins: [ALL_URLS] }) : chrome.permissions.contains({ origins: [ALL_URLS] }));
  } catch {
    permission = Promise.resolve(false);
  }
  const stale = () => !gesture && (closed || gen !== autoGen); // 버튼 클릭 흐름은 그대로 보낸다
  if (gesture) cancelAuto();
  else if (stale()) return;
  $("translate").disabled = true;
  tell("");
  try {
    const granted = (await permission.catch(() => false)) === true;
    if (stale()) return;
    if (!gesture) {
      let tab = null;
      try { [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); } catch { tab = null; }
      if (stale() || !tab || tab.id !== tabId || !origin || originOf(tab.url) !== origin) return;
    }
    const response = await call({ cmd: "translateNow", automatic: granted, clickedAt, trigger: gesture ? "button" : "open" });
    if (response.superseded) tell("원문 보기가 먼저 처리되어 번역하지 않았어요.");
    else if (response.restricted) tell("이 페이지는 브라우저 정책상 번역할 수 없어요.");
    else if (gesture && !response.automatic) tell("모든 사이트 접근을 허용하지 않아 이 페이지만 번역해요.");
    setTimeout(refresh, 800);
  } catch (error) {
    tell(error.message);
  } finally {
    $("translate").disabled = !translateAllowed();
  }
}

/** 준비가 끝났을 때 한 번만: 팝업을 연 탭이 아직 그 창의 활성 탭이고 주소(출처)가 같을 때만 번역한다. */
function continueAfterReady() {
  if (closed || !resumeTranslate) return;
  resumeTranslate = false;
  runTranslate(false, Date.now(), autoGen);
}

$("translate").addEventListener("click", () => runTranslate(true, Date.now()));

$("original").addEventListener("click", async () => {
  cancelAuto();
  tell("");
  try { await call({ cmd: "toggleOriginal" }); } catch (error) { tell(error.message); }
  refresh();
});

// MARK: 번역 준비(모델 파일 받기)

$("prepare").addEventListener("click", () => {
  // 사용자 클릭 직후 첫 동작으로 모델 주소 접근을 요청한다(이미 허용돼 있으면 창 없이 바로 허용).
  let request;
  try { request = chrome.permissions.request({ origins: DOWNLOAD_ORIGINS }); } catch { request = Promise.resolve(false); }
  const gen = autoGen;
  $("prepare").disabled = true;
  tell("");
  $("setupDetail").textContent = "브라우저가 묻는 창에서 '허용'을 눌러 주세요.";
  $("setupDetail").hidden = false;
  Promise.resolve(request).then((granted) => granted === true, () => false).then(async (granted) => {
    try {
      if (!granted) {
        tell("허용하지 않아 파일을 받지 않았어요. 다시 누르고 '허용'을 선택해 주세요.");
        return;
      }
      if (origin && tabId !== null && gen === autoGen && !closed) resumeTranslate = true;
      const response = await call({ cmd: "prepareModel" });
      if (current && !closed) render({ ...current, engine: response.engine });
    } catch (error) {
      tell(error.message);
    } finally {
      $("prepare").disabled = false;
      refresh();
    }
  });
});

$("cancelPrepare").addEventListener("click", async () => {
  cancelAuto();
  try { await call({ cmd: "cancelPrepare" }); } catch (error) { tell(error.message); }
  refresh();
});

// MARK: 설정

for (const [id, cmd, key, read] of [
  ["target", "setTarget", "target", (el) => el.value],
  ["fontStyle", "setFontStyle", "fontStyle", (el) => el.value],
  ["source", "setSource", "source", (el) => el.value],
  ["ocrLang", "setOcrLang", "ocrLang", (el) => el.value],
  ["pageText", "setPageText", "pageText", (el) => el.checked]
]) {
  $(id).addEventListener("change", async (event) => {
    await call({ cmd, [key]: read(event.target) }).catch((e) => tell(e.message));
    refresh();
  });
}

// 확장 안에 들어 있는 도움말(help.html)을 새 탭으로 연다(네트워크 사용 없음, 사용자가 누를 때만).
$("openHelp").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("help.html") }).then(() => window.close(), (error) => tell(error.message));
});
$("versionLabel").textContent = `버전 ${chrome.runtime.getManifest().version}`;

(async () => {
  const gen = autoGen;
  let tab = null;
  try { [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); } catch { tab = null; }
  tabId = Number.isInteger(tab?.id) ? tab.id : null;
  origin = originOf(tab?.url);
  // 툴바 아이콘을 눌러 팝업이 열릴 때마다 '번역 보기'로 한 번 전환한다(원문으로 되돌리지 않음). 준비가 아직이면
  // 준비가 끝난 뒤 이 팝업에서 이어 간다(준비 버튼을 누르기 전에는 아무것도 받지 않음).
  try {
    const opened = await call({ cmd: "popupState" });
    const view = modelState(opened);
    if (origin && tabId !== null && gen === autoGen && !closed) {
      if (view.kind === "ready") {
        const page = opened.page;
        if (!(page && (page.running === true || page.view === "translated"))) await runTranslate(false, OPENED_AT, gen);
      } else if (["working", "finishing", "checking"].includes(view.kind)) {
        resumeTranslate = true;
      }
    }
  } catch {
    // 실패는 아래 refresh()가 실제 상태와 함께 보여 준다.
  }
  refresh();
})();
