// 바로보기 웹 번역 — 페이지 내용 스크립트(최상위 프레임만, http/https 페이지에서만 동작).
// Barobogi MacOS 확장(BrowserExtension/shared/content.js)의 DOM 수집·복원·이미지 덮개·동적 페이지 대응·취소 로직을
// 그대로 들여왔다. Mac 네이티브 연결(Native Messaging)과 Google·DeepL 자동 전송, Apple Intelligence 문장 다듬기는
// 이 빌드에 없다(클라우드로 자동 전송하지 않음, 설계 근거는 README 참고). 번역·OCR은 background.js가 엔진 문서
// (공통 로컬 모델 M2M100 + Tesseract.js, 선택적으로 Chrome 내장 Translator)로 중계한다.
// - 기본은 이미지 전용: 페이지 글자(DOM)는 브라우저 메뉴의 번역에 맡기고 건드리지 않는다(브라우저가 번역해 둔 DOM을
//   덮어쓰지 않게). '페이지 글자도 번역'을 켰을 때만 텍스트 노드를 바꾼다.
// - 글자는 DOM 텍스트 노드 값만 바꾼다(innerHTML을 바꾸지 않음). 원문은 메모리에 두고 '원문 보기'로 되돌린다.
// - 이미지 속 글자는 보이는 이미지 영역만 캡처·OCR해 이미지 위에 클릭 통과(pointer-events: none) 덮개로 그린다.
// - 자동 번역은 전역 자동 번역이 켜져 있고 이 사이트 접근 권한이 있을 때만, 스크롤·변경이 생기면 보이는 부분만 번역한다.
(() => {
  "use strict";
  if (location.protocol !== "http:" && location.protocol !== "https:") return;
  if (globalThis.__barobogiWebTranslatorLoaded) return;
  globalThis.__barobogiWebTranslatorLoaded = true;
  document.querySelectorAll("barobogi-translator-layer").forEach((host) => host.remove());

  const api = chrome;
  const MAX_UNITS = 600;
  const MAX_WALK = 40000;
  const BATCH_TEXTS = 16; // 로컬 모델은 CPU에서 문장씩 처리하므로 작은 묶음으로 보내 부분 결과가 빨리 보이게 한다
  const BATCH_CHARS = 1500;
  const MAX_TEXT = 5000;
  const CACHE_LIMIT = 4000;
  const RECORD_LIMIT = 30000;
  const MAX_IMAGES = 8;
  const LETTER = /\p{L}/u;
  const SKIP_SELECTOR = [
    "script", "style", "noscript", "template", "textarea", "input", "select", "option", "code", "pre", "kbd",
    "samp", "var", "svg", "math", "canvas", "iframe", "object", "[translate='no']", ".notranslate",
    "[contenteditable='']", "[contenteditable='true']", "barobogi-translator-layer"
  ].join(",");

  const FONT_STYLES = ["auto", "gothic", "myeongjo", "gungseo", "hand"];

  const state = {
    auto: false,
    images: true,
    pageText: false, // 기본 끔: 이미지 전용
    ocrLang: "auto", // 0.2.0 기본: 다국어·가로/세로 자동 인식
    target: "ko",
    source: "auto",
    fontStyle: "auto",
    view: "original",
    pageGen: 0,   // 이동·언어 변경 때 증가: 이전 결과 모두 무효
    scrollGen: 0, // 스크롤·크기 변경 때 증가: 이전 이미지 결과 무효
    url: location.href,
    stopEpoch: 0, // 마지막 원문 보기(전역 끄기) 세대: 이보다 오래된 설정·번역 시작 요청은 무시한다
    running: false,
    rerun: false,
    rerunManual: false,
    timer: 0,
    status: "대기",
    error: "",
    warning: "",
    inventory: null,
    action: null,
    pendingAction: null,
    passAction: null
  };

  // MARK: 번역 동작 시간(경과·단계, 숫자만 — 원문·주소·이미지는 담지 않는다)
  const ACTION_ID = /^[A-Za-z0-9-]{1,40}$/;
  const ACTION_MAX_AGE = 120000;
  const ACTION_MAX_STAGES = 24;
  let actionSeq = 0;

  function clickTime(value) {
    const now = Date.now();
    return Number.isFinite(value) && value <= now + 1000 && value >= now - ACTION_MAX_AGE ? Math.min(value, now) : now;
  }

  function newAction(startedAt, source, id = null) {
    actionSeq += 1;
    return { id: typeof id === "string" && ACTION_ID.test(id) ? id : `a${Date.now().toString(36)}-${actionSeq}`,
             startedAt, source, provisional: source !== "click", gen: null,
             stages: [], outcome: null, endedAt: null };
  }

  function markStage(action, name) {
    if (!action || action.outcome !== null) return;
    const at = Date.now() - action.startedAt;
    const last = action.stages[action.stages.length - 1];
    if (last && last.b === null) {
      if (last.s === name) return;
      last.b = at;
    }
    if (action.stages.length < ACTION_MAX_STAGES) action.stages.push({ s: name, a: at, b: null });
  }

  function finishAction(action, outcome) {
    if (!action || action.outcome !== null) return;
    const at = Date.now() - action.startedAt;
    const last = action.stages[action.stages.length - 1];
    if (last && last.b === null) last.b = Math.max(last.a, at);
    action.outcome = outcome;
    action.endedAt = at;
  }

  function adoptAction(manual) {
    let action = manual ? state.pendingAction : null;
    state.pendingAction = null;
    if (!action || Date.now() - action.startedAt > ACTION_MAX_AGE) action = newAction(Date.now(), "auto");
    action.gen = state.pageGen;
    const lead = Date.now() - action.startedAt;
    if (lead > 0 && !action.stages.length) action.stages.push({ s: "start", a: 0, b: lead });
    markStage(action, "search");
    state.passAction = action;
    if (!action.provisional) commitAction(action);
    return action;
  }

  function commitAction(action) {
    if (!action || action.outcome !== null) return;
    if (state.action === action && !action.provisional) return;
    action.provisional = false;
    const previous = state.action;
    if (previous && previous !== action && previous.outcome === null) finishAction(previous, "cancelled");
    state.action = action;
  }

  const SENTENCE_END = ".!?\n。！？";
  const SENTENCE_PART = new RegExp(`[^${SENTENCE_END}]+`, "g");
  function sentenceCount(text) {
    return (String(text).match(SENTENCE_PART) || []).filter((part) => LETTER.test(part)).length;
  }

  function inventoryOf(pageGen) {
    return state.inventory && state.inventory.gen === pageGen ? state.inventory : null;
  }

  function updateInventory(inventory, changes) {
    if (inventory && state.inventory === inventory) Object.assign(inventory, changes);
  }

  function isBusy() {
    return state.running;
  }

  /** Text 노드 → { original, translated(null이면 원문 유지), target(언어|원문언어), lang(판별 언어 코드|"unknown"|null) } */
  const records = new Map();
  /** `${target}\u0001${source}\u0001${원문}` → 번역문(null이면 번역하지 않음). 메모리 LRU */
  const cache = new Map();
  const langCache = new Map();
  const imageRecords = new Map();
  let ocrInFlight = false;
  let contextDead = false;

  // MARK: 공통

  function isContextInvalidError(error) {
    const message = (error && error.message) || String(error || "");
    return message.includes("Extension context invalidated") || message.includes("context invalidated");
  }

  function retire() {
    if (contextDead) return;
    contextDead = true;
    state.auto = false;
    state.rerun = false;
    state.rerunManual = false;
    state.running = false;
    state.pageGen += 1;
    state.scrollGen += 1;
    clearTimeout(state.timer);
    state.timer = 0;
    ocrInFlight = false;
    setObserving(false);
    removeEventListener("scroll", onScroll, { capture: true });
    removeEventListener("resize", onScroll);
    document.removeEventListener("fullscreenchange", onFullscreenChange);
    document.removeEventListener("webkitfullscreenchange", onFullscreenChange);
    removeEventListener("popstate", onHistoryChange);
    removeEventListener("hashchange", onHistoryChange);
    for (const [node, record] of records) {
      if (!node.isConnected) continue;
      if (record.translated !== null && node.nodeValue === record.translated) node.nodeValue = record.original;
    }
    clearImageOverlays();
    records.clear();
    cache.clear();
    langCache.clear();
  }

  function send(message) {
    if (contextDead) {
      const error = new Error("확장 기능 연결이 끊어졌습니다.");
      error.code = "contextinvalid";
      return Promise.reject(error);
    }
    return new Promise((resolve) => resolve(api.runtime.sendMessage(message)))
      .then((response) => {
        if (!response || response.ok !== true) {
          const error = new Error(response?.message || "");
          error.code = response?.code || "error";
          throw error;
        }
        return response;
      })
      .catch((error) => {
        if (!contextDead && isContextInvalidError(error)) retire();
        if (contextDead) error.code = "contextinvalid";
        throw error;
      });
  }

  function setStatus(text) { state.status = text; }

  /** 번역 결과를 구분하는 기준: 번역 언어와 원문 언어 설정이 모두 같아야 같은 결과다. */
  function profile() { return `${state.target}|${state.source}|${state.ocrLang}`; }

  /** 페이지 lang 속성 — 원문 언어 자동 감지의 힌트로만 쓴다(근거 없는 짧은 한자 문구 등). */
  function pageLangHint() {
    const lang = (document.documentElement.getAttribute("lang") || "").trim();
    return /^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8}){0,2}$/.test(lang) ? lang.split("-")[0].toLowerCase() : null;
  }

  /** 지금 화면에 번역으로 보이는 모든 텍스트 노드를 원문으로 되돌린다(설정이 바뀌어 이전 결과가 섞이지 않게). */
  function revertAllRecords() {
    for (const [node, record] of records) {
      if (node.isConnected && record.translated !== null && node.nodeValue === record.translated) node.nodeValue = record.original;
    }
    records.clear();
  }

  function isAutoLike() {
    return state.auto && state.view === "translated";
  }

  /** texts[start]부터 항목 수·글자 수 상한 안에서 다음 묶음을 고른다. 첫 항목은 혼자라도 넣는다. */
  function nextBatch(texts, start, maxTexts, maxChars) {
    const batch = [];
    let chars = 0;
    let next = start;
    while (next < texts.length && batch.length < maxTexts && (batch.length === 0 || chars + texts[next].length <= maxChars)) {
      chars += texts[next].length;
      batch.push(texts[next]);
      next += 1;
    }
    return { batch, chars, next };
  }

  function cacheKey(text) { return `${profile()}\u0001${text}`; }

  function cachePut(text, value) {
    const key = cacheKey(text);
    cache.delete(key);
    cache.set(key, value);
    while (cache.size > CACHE_LIMIT) cache.delete(cache.keys().next().value);
  }

  function cacheGet(text) {
    const key = cacheKey(text);
    if (!cache.has(key)) return undefined;
    const value = cache.get(key);
    cache.delete(key);
    cache.set(key, value);
    return value;
  }

  function langPut(text, lang) {
    langCache.delete(text);
    langCache.set(text, lang);
    while (langCache.size > CACHE_LIMIT) langCache.delete(langCache.keys().next().value);
  }

  function langGet(text) {
    if (!langCache.has(text)) return undefined;
    const value = langCache.get(text);
    langCache.delete(text);
    langCache.set(text, value);
    return value;
  }

  function nextFrames(count) {
    return new Promise((resolve) => {
      const step = (n) => (n <= 0 ? resolve() : requestAnimationFrame(() => step(n - 1)));
      step(count);
    });
  }

  // MARK: 글꼴(고딕/명조/궁서/손글씨) — 패키지에 포함한 글꼴만 쓴다(온라인 글꼴 의존 안 함, 라이선스는 fonts/*.txt)

  const FONT_FILES = { gothic: "fonts/NanumGothic-Regular.ttf", myeongjo: "fonts/NanumMyeongjo-Regular.ttf",
                        gungseo: "fonts/ChosunGs.ttf", hand: "fonts/NanumPenScript-Regular.ttf" };
  const FONT_FAMILIES = { gothic: "BarobogiNanumGothic", myeongjo: "BarobogiNanumMyeongjo",
                           gungseo: "BarobogiChosunGungseo", hand: "BarobogiNanumPen" };
  const FONT_FALLBACKS = { gothic: "system-ui,sans-serif", myeongjo: "serif", gungseo: "serif", hand: "cursive" };
  const fontLoadPromises = new Map();

  function loadBundledFont(style) {
    if (style === "auto") return Promise.resolve(true);
    const cached = fontLoadPromises.get(style);
    if (cached) return cached;
    const family = FONT_FAMILIES[style];
    const file = FONT_FILES[style];
    if (!family || !file) return Promise.resolve(false);
    const promise = Promise.resolve()
      .then(() => new FontFace(family, `url(${api.runtime.getURL(file)})`).load())
      .then((loaded) => { document.fonts.add(loaded); return true; })
      .catch(() => { fontLoadPromises.delete(style); return false; });
    fontLoadPromises.set(style, promise);
    return promise;
  }

  // 페이지 글자(텍스트 노드)는 글꼴을 바꾸지 않는다: 텍스트 노드를 <span>으로 감싸면 React 등
  // 동적 프레임워크의 DOM 재조정과 충돌해 페이지가 깨질 수 있다. 글꼴 선택은 이미지 오버레이에만 적용한다.

  function resolveFontStyle(itemFontStyle) {
    if (state.fontStyle !== "auto" && FONT_STYLES.includes(state.fontStyle)) return state.fontStyle;
    return itemFontStyle === "myeongjo" || itemFontStyle === "gungseo" || itemFontStyle === "hand" ? itemFontStyle : "gothic";
  }

  function contrastColor(hex) {
    if (typeof hex !== "string" || !/^#[0-9A-Fa-f]{6}$/.test(hex)) return "#FFFFFF";
    const n = parseInt(hex.slice(1), 16);
    const luminance = (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
    return luminance > 0.55 ? "#000000" : "#FFFFFF";
  }

  function fontFamilyFor(style) {
    const family = FONT_FAMILIES[style] || FONT_FAMILIES.gothic;
    const fallback = FONT_FALLBACKS[style] || FONT_FALLBACKS.gothic;
    return `"${family}",${fallback}`;
  }

  let layerHost = null;
  let layerRoot = null;

  function fullscreenTarget() {
    return document.fullscreenElement || document.webkitFullscreenElement || null;
  }

  function layer() {
    const parent = fullscreenTarget() || document.documentElement;
    if (layerHost && layerHost.isConnected) {
      if (layerHost.parentNode !== parent) parent.appendChild(layerHost);
      return layerRoot;
    }
    layerHost = document.createElement("barobogi-translator-layer");
    layerHost.style.cssText = "all: initial; position: fixed; left: 0; top: 0; width: 0; height: 0; " +
      "z-index: 2147483647; pointer-events: none; contain: layout style; color-scheme: only light;";
    layerRoot = layerHost.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent =
      ":host,.img,.mask,.t,.tt{color-scheme:only light}" +
      ".img{position:absolute;pointer-events:none;overflow:hidden}" +
      ".mask{position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none}" +
      ".t{position:absolute;box-sizing:border-box;overflow:hidden;pointer-events:none;user-select:none;" +
      "display:flex;align-items:flex-start;justify-content:flex-start;text-align:left;background:transparent;" +
      "font-family:system-ui,sans-serif;line-height:1.15;white-space:normal;" +
      "word-break:keep-all;overflow-wrap:anywhere;padding:0 1px}" +
      ".t.vert{justify-content:flex-start;align-items:flex-start}" +
      ".t.ctr{justify-content:center;align-items:center;text-align:center}" +
      ".tt{display:inline-block;flex-shrink:0;max-width:none;max-height:none}" +
      ".fail{position:absolute;right:2px;bottom:2px;max-width:70%;padding:1px 5px;border-radius:3px;" +
      "background:rgba(0,0,0,.72);color:#fff;font:11px system-ui,sans-serif;" +
      "line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none}";
    layerRoot.appendChild(style);
    parent.appendChild(layerHost);
    applyLayerVisibility();
    return layerRoot;
  }

  let captureHidden = false;

  function applyLayerVisibility() {
    if (layerHost) layerHost.style.visibility = state.view === "translated" && !captureHidden ? "visible" : "hidden";
  }

  function clearImageOverlays() {
    for (const record of imageRecords.values()) record.box.remove();
    imageRecords.clear();
  }

  // MARK: 텍스트 수집(보이는 부분 위주)

  const range = document.createRange();

  function inBand(rect, margin) {
    return rect.width > 0 && rect.height > 0 && rect.bottom >= -margin && rect.top <= innerHeight + margin &&
      rect.right >= 0 && rect.left <= innerWidth;
  }

  const SINGLE_TOKEN = /^[\p{L}\p{N}][\p{L}\p{N}+#.\-]{0,23}$/u;
  const LABEL_CONTROL = "button,[role='button'],[role='tab'],[role='combobox'],[aria-haspopup],[role='option'],[role='menuitemradio']";
  function isCodeLanguageLabel(parent, trimmed) {
    if (!SINGLE_TOKEN.test(trimmed)) return false;
    const control = parent.closest(LABEL_CONTROL);
    if (!control) return false;
    let el = control.parentElement;
    for (let depth = 0; depth < 6 && el && el !== document.body; depth += 1, el = el.parentElement) {
      const blocks = el.querySelectorAll("pre");
      if (blocks.length) {
        const codeChars = [...blocks].reduce((total, block) => total + block.textContent.length, 0);
        return el.textContent.length - codeChars <= 400;
      }
    }
    return false;
  }

  /** 요소 안 글자를 번역 전 원문으로 모은다(이미 번역한 노드는 기록해 둔 원문). */
  function originalTextOf(el, limit, separator = "") {
    const parts = [];
    let length = 0;
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node && length < limit; node = walker.nextNode()) {
      if (node.parentElement && node.parentElement.closest("script,style,noscript,template,barobogi-translator-layer")) continue;
      const record = records.get(node);
      const value = record && node.nodeValue === record.translated ? record.original : node.nodeValue;
      parts.push(value);
      length += value.length;
    }
    return parts.join(separator).replace(/\s+/g, " ").trim().slice(0, limit);
  }

  function isProductNameLabel(parent, trimmed) {
    if (!/^[A-Za-z][A-Za-z0-9.+\-]{1,23}$/.test(trimmed)) return false;
    const card = parent.closest("a[href]");
    if (!card || card.textContent.length > 600) return false;
    const source = originalTextOf(card, 600, " ");
    const word = trimmed.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return new RegExp(`(^|\\s)\\S*\\d\\S*\\s+${word}($|[^\\p{L}\\p{N}])`, "u").test(source);
  }

  function collectUnits(done = null) {
    const body = document.body;
    if (!body) return [];
    const margin = innerHeight * 0.5;
    const parentOK = new Map();
    const visible = [];
    const near = [];
    const walker = document.createTreeWalker(body, NodeFilter.SHOW_TEXT);
    let walked = 0;
    for (let node = walker.nextNode(); node && walked < MAX_WALK; node = walker.nextNode()) {
      walked += 1;
      const value = node.nodeValue;
      if (!value || value.length < 2) continue;
      const record = records.get(node);
      let source = value;
      let finished = false;
      if (record) {
        if (record.target === profile() && (value === record.translated || (record.translated === null && value === record.original))) {
          if (!done || done.length >= MAX_UNITS) continue;
          finished = true;
          source = record.original;
        } else if (value === record.translated) source = record.original;
        else if (value !== record.original) records.delete(node);
      }
      const trimmed = source.trim();
      if (trimmed.length < 2 || trimmed.length > MAX_TEXT || !LETTER.test(trimmed)) continue;
      const parent = node.parentElement;
      if (!parent) continue;
      let ok = parentOK.get(parent);
      if (ok === undefined) {
        ok = !parent.closest(SKIP_SELECTOR) && !parent.isContentEditable;
        for (let el = parent; ok && el; el = el.parentElement) {
          const style = getComputedStyle(el);
          if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" ||
              Number(style.opacity) <= 0.01 || style.contentVisibility === "hidden") ok = false;
        }
        parentOK.set(parent, ok);
      }
      if (!ok) continue;
      if (isCodeLanguageLabel(parent, trimmed) || isProductNameLabel(parent, trimmed)) continue;
      range.selectNodeContents(node);
      const rect = range.getBoundingClientRect();
      if (!inBand(rect, margin)) continue;
      const unit = { node, value, source, trimmed };
      if (finished) { done.push(unit); continue; }
      if (rect.bottom >= 0 && rect.top <= innerHeight) visible.push(unit);
      else near.push(unit);
      if (visible.length >= MAX_UNITS) break;
    }
    return visible.concat(near).slice(0, MAX_UNITS);
  }

  function pruneRecords() {
    for (const node of records.keys()) {
      if (!node.isConnected) records.delete(node);
    }
    while (records.size > RECORD_LIMIT) {
      records.delete(records.keys().next().value);
    }
  }

  function applyUnit(unit, translatedTrimmed, lang) {
    if (unit.node.nodeValue !== unit.value) return; // 그사이 페이지가 바꿨으면 건드리지 않는다
    const lead = unit.source.match(/^\s*/)[0];
    const trail = unit.source.match(/\s*$/)[0];
    const translated = typeof translatedTrimmed === "string" && translatedTrimmed.length > 0 ? lead + translatedTrimmed + trail : null;
    const record = { original: unit.source, translated, target: profile() };
    if (lang !== undefined) record.lang = lang;
    records.set(unit.node, record);
    const want = state.view === "translated" && translated !== null ? translated : unit.source;
    if (unit.node.nodeValue !== want) unit.node.nodeValue = want;
  }

  /** 화면 근처 일반 글자를 모아 배경(숨은 엔진 문서로 중계)에 보내 번역한다. 같은 원문은 한 번만 보낸다. */
  async function translateTextPass(pageGen) {
    if (!state.pageText) return;
    pruneRecords();
    const done = [];
    const units = collectUnits(done);
    const inventory = inventoryOf(pageGen);
    const counted = units.concat(done);
    updateInventory(inventory, { textMessages: counted.length,
                                 textSentences: counted.reduce((sum, unit) => sum + sentenceCount(unit.trimmed), 0) });
    const groups = new Map(); // 원문 → unit[]
    for (const unit of units) {
      const cached = cacheGet(unit.trimmed);
      if (cached !== undefined) { applyUnit(unit, cached, langGet(unit.trimmed)); continue; }
      if (!groups.has(unit.trimmed)) groups.set(unit.trimmed, []);
      groups.get(unit.trimmed).push(unit);
    }
    const texts = [...groups.keys()];
    if (!texts.length) return;
    const action = state.passAction && state.passAction.gen === pageGen ? state.passAction : null;
    commitAction(action);
    markStage(action, "text");
    updateInventory(inventory, { phase: "translating" });
    let start = 0;
    while (start < texts.length) {
      const { batch, next } = nextBatch(texts, start, BATCH_TEXTS, BATCH_CHARS);
      start = next;
      if (!stillCurrent(pageGen)) return;
      const hint = pageLangHint();
      const response = await send({ cmd: "translate", target: state.target, source: state.source, texts: batch,
                                    ...(hint ? { hint } : {}), ...(action ? { action: action.id } : {}) });
      if (!stillCurrent(pageGen)) return; // 세대가 바뀌었으면(설정 변경 포함) 늦은 응답을 버린다
      if (response.missing && response.missing.length) state.warning = `번역 엔진 준비 필요: ${response.missing.join(", ")}`;
      if (response.warning) state.warning = response.warning;
      const langs = Array.isArray(response.langs) && response.langs.length === batch.length ? response.langs : null;
      response.texts.forEach((value, index) => {
        const ok = typeof value === "string";
        if (ok) cachePut(batch[index], value);
        const lang = langs ? langs[index] : undefined;
        if (ok && langs) langPut(batch[index], lang);
        for (const unit of groups.get(batch[index]) || []) applyUnit(unit, ok ? value : null, lang);
      });
    }
  }

  // MARK: 이미지 OCR

  function membersKey(members) {
    return `${profile()}|${members.map((m) => `${m.src}|${m.currentSrc}`).join("|")}`;
  }

  function repositionOverlays() {
    for (const [img, record] of imageRecords) {
      const geometry = recordGeometry(img, record);
      const rect = geometry ? geometry.rect : null;
      if (!rect || rect.width === 0 || Math.abs(rect.width - record.elemW) > 2 || Math.abs(rect.height - record.elemH) > 2 ||
          !img.complete || !isImageVisible(img) || record.key !== membersKey(record.members)) {
        record.box.remove();
        imageRecords.delete(img);
        continue;
      }
      record.box.style.left = `${rect.left + record.offX}px`;
      record.box.style.top = `${rect.top + record.offY}px`;
      record.box.style.display = "";
    }
  }

  const STRIP_MAX = 8;

  function unionRect(rects) {
    const left = Math.min(...rects.map((r) => r.left)), top = Math.min(...rects.map((r) => r.top));
    const right = Math.max(...rects.map((r) => r.right)), bottom = Math.max(...rects.map((r) => r.bottom));
    return { left, top, right, bottom, width: right - left, height: bottom - top };
  }

  function isImageVisible(img) {
    for (let el = img; el instanceof Element; el = el.parentElement) {
      const style = getComputedStyle(el);
      if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") return false;
    }
    return true;
  }

  function isImageCaptureReady(img) {
    for (let el = img; el instanceof Element; el = el.parentElement) {
      const style = getComputedStyle(el);
      if (Number(style.opacity) < 0.98) return false;
      for (const match of style.filter.matchAll(/brightness\(([^)]+)\)/g)) {
        const value = match[1].trim();
        const amount = parseFloat(value) / (value.endsWith("%") ? 100 : 1);
        if (Number.isFinite(amount) && amount < 0.98) return false;
      }
    }
    return true;
  }

  function verticalImageStrip(img) {
    let ancestor = img.parentElement;
    for (let depth = 0; ancestor && ancestor !== document.body && depth < 4; ancestor = ancestor.parentElement, depth += 1) {
      const imgs = ancestor.getElementsByTagName("img");
      if (imgs.length < 2) continue;
      if (imgs.length > STRIP_MAX || ancestor.textContent.trim().length > 40) return null;
      const members = Array.from(imgs);
      for (const m of members) {
        if (!m.complete || !m.naturalWidth || !m.naturalHeight || m.closest(SKIP_SELECTOR) || !isImageVisible(m)) return null;
      }
      const pairs = members.map((m) => ({ m, r: m.getBoundingClientRect() })).sort((a, b) => a.r.top - b.r.top);
      if (pairs.length === 2) {
        const horizontal = [...pairs].sort((a, b) => a.r.left - b.r.left);
        const [left, right] = horizontal.map((p) => p.r);
        const gap = right.left - left.right;
        if (left.width >= 300 && right.width >= 300 && left.height >= 400 && right.height >= 400 &&
            Math.abs(left.top - right.top) <= 2 && Math.abs(left.height - right.height) <= 2 && gap >= -4 && gap <= 3) {
          return { members: horizontal.map((p) => p.m), rects: horizontal.map((p) => p.r) };
        }
      }
      const first = pairs[0].r;
      for (let i = 0; i < pairs.length; i += 1) {
        const r = pairs[i].r;
        if (r.width <= 0 || r.height <= 0 || Math.abs(r.left - first.left) > 2 || Math.abs(r.width - first.width) > 2) return null;
        if (i > 0) {
          const gap = r.top - pairs[i - 1].r.bottom;
          if (gap > 3 || gap < -4) return null;
        }
      }
      return { members: pairs.map((p) => p.m), rects: pairs.map((p) => p.r) };
    }
    return null;
  }

  function imageStrip(img) {
    const own = verticalImageStrip(img);
    let ancestor = img.parentElement;
    for (let depth = 0; ancestor && ancestor !== document.body && depth < 4; ancestor = ancestor.parentElement, depth += 1) {
      const all = Array.from(ancestor.getElementsByTagName("img"));
      if (all.length > 48 || ancestor.textContent.trim().length > 40) break;
      const seen = new Set(), pages = [];
      for (const member of all) {
        const r = member.getBoundingClientRect();
        if (seen.has(member) || Math.min(innerWidth, r.right) - Math.max(0, r.left) < r.width * 0.3 || r.bottom <= 0 || r.top >= innerHeight ||
            !member.complete || !member.naturalWidth || member.closest(SKIP_SELECTOR) || !isImageVisible(member)) continue;
        const strip = verticalImageStrip(member);
        const members = strip ? strip.members : [member];
        members.forEach((m) => seen.add(m));
        const rects = strip ? strip.rects : [r];
        pages.push({ members, rects, rect: unionRect(rects) });
      }
      if (pages.length !== 2) continue;
      pages.sort((a, b) => a.rect.left - b.rect.left);
      const [left, right] = pages.map((p) => p.rect), gap = right.left - left.right;
      if (left.width < 300 || right.width < 300 || left.height < 400 || right.height < 400 ||
          Math.abs(left.top - right.top) > 2 || Math.abs(left.height - right.height) > 2 || gap < -4 || gap > 3) continue;
      const members = pages.flatMap((p) => p.members);
      if (!members.includes(img) || members.length > STRIP_MAX) continue;
      return { members, rects: pages.flatMap((p) => p.rects) };
    }
    return own;
  }

  function recordGeometry(img, record) {
    const members = record.members;
    if (members.length > 1) {
      const strip = img.isConnected ? imageStrip(img) : null;
      if (!strip || strip.members.length !== members.length || strip.members.some((m, i) => m !== members[i])) return null;
      return { rect: unionRect(strip.rects), rects: strip.rects };
    }
    if (!img.isConnected) return null;
    const rect = img.getBoundingClientRect();
    return { rect, rects: [rect] };
  }

  const COVER_PROBE = [0.2, 0.5, 0.8];
  const COVER_MIN_ALPHA = 0.05;
  let imageCovers = new Set();
  let coverProbeSheet = null;

  function colorAlpha(color) {
    if (!color || color === "transparent") return 0;
    const m = /\(([^)]*)\)/.exec(color);
    if (!m) return 1;
    const slash = m[1].split("/");
    const parts = slash.length > 1 ? [slash[1]] : m[1].split(",");
    if (slash.length === 1 && parts.length < 4) return 1;
    const value = parts[parts.length - 1].trim();
    const alpha = parseFloat(value) / (value.endsWith("%") ? 100 : 1);
    return Number.isFinite(alpha) ? alpha : 1;
  }

  function paintAlpha(style) {
    if (style.display === "none" || style.visibility === "hidden") return 0;
    const backdrop = style.backdropFilter || style.webkitBackdropFilter || "none";
    if (backdrop !== "none" || style.backgroundImage !== "none") return 1;
    return colorAlpha(style.backgroundColor);
  }

  function coverAlpha(el, members) {
    const holds = (node) => members.some((m) => node.contains(m));
    const ancestor = holds(el);
    let chain = 1;
    if (!ancestor) {
      for (let node = el; node instanceof Element && !holds(node); node = node.parentElement) {
        chain *= Number(getComputedStyle(node).opacity);
      }
    }
    if (!(chain >= COVER_MIN_ALPHA)) return 0;
    let alpha = ancestor ? 0 : chain * paintAlpha(getComputedStyle(el));
    for (const pseudo of ["::before", "::after"]) {
      const style = getComputedStyle(el, pseudo);
      if (style.content === "none" || style.content === "normal") continue;
      alpha = Math.max(alpha, chain * Number(style.opacity) * paintAlpha(style));
    }
    return alpha;
  }

  function coveredCandidates(list) {
    const covered = new Set();
    if (!list.length || typeof document.elementsFromPoint !== "function") return covered;
    let previousSheets = null;
    try {
      if (typeof CSSStyleSheet === "function" && "adoptedStyleSheets" in document) {
        if (!coverProbeSheet) {
          coverProbeSheet = new CSSStyleSheet();
          coverProbeSheet.replaceSync("*,*::before,*::after{pointer-events:auto!important}");
        }
        previousSheets = document.adoptedStyleSheets;
        document.adoptedStyleSheets = [...previousSheets, coverProbeSheet];
      }
    } catch {
      previousSheets = null;
    }
    try {
      for (const candidate of list) {
        const members = candidate.members || [candidate.img];
        const { x, y, w, h } = candidate.clip;
        let probed = 0;
        const found = [];
        for (const fy of COVER_PROBE) {
          for (const fx of COVER_PROBE) {
            const stack = document.elementsFromPoint(x + w * fx, y + h * fy);
            const at = stack.findIndex((el) => members.includes(el));
            if (at < 0) continue;
            probed += 1;
            for (let k = 0; k < at; k += 1) {
              const el = stack[k];
              if (el.nodeName.startsWith("BAROBOGI-TRANSLATOR-")) continue;
              if (coverAlpha(el, members) >= COVER_MIN_ALPHA) { found.push(el); break; }
            }
          }
        }
        if (probed && found.length * 2 > probed) {
          covered.add(candidate);
          found.forEach((el) => imageCovers.add(el));
        }
      }
    } finally {
      if (previousSheets) {
        try { document.adoptedStyleSheets = previousSheets; } catch { /* 무시 */ }
      }
    }
    return covered;
  }

  function touchesImageCover(node) {
    if (!(node instanceof Element)) return false;
    for (const cover of imageCovers) {
      if (node === cover || node.contains(cover)) return true;
    }
    return false;
  }

  function candidateUnchanged(candidate) {
    const members = candidate.members || [candidate.img];
    const rects = candidate.rects || [candidate.rect];
    if (candidate.key !== membersKey(members)) return false;
    return members.every((img, index) => {
      if (!img.isConnected || !img.complete) return false;
      if (!isImageVisible(img)) return false;
      const now = img.getBoundingClientRect();
      const then = rects[index];
      return Math.abs(now.left - then.left) <= 1 && Math.abs(now.top - then.top) <= 1 &&
        Math.abs(now.width - then.width) <= 1 && Math.abs(now.height - then.height) <= 1;
    });
  }

  function captureReadyCandidates(list) {
    const ready = list.filter((candidate) => candidateUnchanged(candidate) && candidate.members.every(isImageCaptureReady));
    const covered = coveredCandidates(ready);
    return ready.filter((candidate) => !covered.has(candidate));
  }

  function imageCandidates(includeStable = false) {
    imageCovers = new Set();
    const list = [];
    const grouped = new Set();
    for (const img of document.images) {
      if (grouped.has(img) || !img.complete) continue;
      const own = img.getBoundingClientRect();
      if (own.bottom <= 0 || own.top >= innerHeight || own.right <= 0 || own.left >= innerWidth) continue;
      const strip = imageStrip(img);
      if (strip) strip.members.forEach((m) => grouped.add(m));
      else if (img.naturalWidth < 64 || img.naturalHeight < 32) continue;
      const members = strip ? strip.members : [img];
      const rects = strip ? strip.rects : [own];
      const rect = strip ? unionRect(rects) : own;
      if (rect.width < 80 || rect.height < 40) continue;
      const clip = {
        x: Math.max(0, rect.left), y: Math.max(0, rect.top),
        r: Math.min(innerWidth, rect.right), b: Math.min(innerHeight, rect.bottom)
      };
      const w = clip.r - clip.x;
      const h = clip.b - clip.y;
      const fullH = strip ? Math.min(rect.height, innerHeight) : rect.height;
      if (w < 60 || h < 30 || w * h < rect.width * fullH * 0.3) continue;
      if (!strip && img.closest(SKIP_SELECTOR)) continue;
      if (!strip && !isImageVisible(img)) continue;
      if (!members.every(isImageCaptureReady)) continue;
      const anchor = members[0];
      const key = membersKey(members);
      const existing = imageRecords.get(anchor);
      const offX = clip.x - rect.left;
      const offY = clip.y - rect.top;
      const stable = existing && existing.key === key && existing.offX <= offX + 1 && existing.offY <= offY + 1 &&
          existing.offX + existing.w >= offX + w - 1 && existing.offY + existing.h >= offY + h - 1;
      if (stable && !includeStable) continue;
      list.push({ img: anchor, members, rects, key, rect, clip: { x: clip.x, y: clip.y, w, h }, area: w * h, stable });
    }
    const covered = coveredCandidates(list);
    return list.filter((candidate) => !covered.has(candidate)).sort((a, b) => b.area - a.area).slice(0, MAX_IMAGES);
  }

  function imageInventory() {
    repositionOverlays();
    const candidates = imageCandidates(true);
    let sentences = 0, pending = false;
    for (const candidate of candidates) {
      const existing = candidate.stable ? imageRecords.get(candidate.img) : null;
      if (existing && Array.isArray(existing.items)) sentences += existing.items.length;
      else pending = true;
    }
    return { images: candidates.length, imageSentences: candidates.length ? (pending ? null : sentences) : 0 };
  }

  const LETTER_CJK = /[ᄀ-ᇿ㄰-㆏가-힣぀-ヿ㐀-䶿一-鿿豈-﫿]/;
  const READABLE_MIN_FONT = 11;

  function fitFontSize(div, text, minFont, preferredMax, vertical) {
    div.style.overflow = "visible";
    div.style.pointerEvents = "none";
    const title = !vertical && div.classList.contains("ctr") && text.style.whiteSpace === "nowrap";
    text.style.lineHeight = title ? "1" : "1.15";
    text.style.transform = "";
    const box = div.getBoundingClientRect();
    const inset = title ? Math.max(1, Math.min(3, preferredMax * 0.04))
      : Math.max(1, Math.min(18, preferredMax * 0.12, Math.min(box.width, box.height) * 0.12));
    text.style.boxSizing = "border-box";
    text.style.padding = `${inset}px`;
    const width = Math.max(1, div.clientWidth), height = Math.max(1, div.clientHeight);
    if (vertical) { text.style.height = `${height}px`; text.style.width = "auto"; }
    else { text.style.width = `${width}px`; text.style.height = "auto"; }
    const fits = () => text.scrollWidth <= width + 1 && text.scrollHeight <= height + 1;
    const top = Math.max(minFont, preferredMax);
    div.style.fontSize = `${top}px`;
    if (fits()) return { size: top, fits: true };
    div.style.fontSize = `${minFont}px`;
    if (!fits()) return { size: minFont, fits: false };
    let lo = minFont, hi = top;
    for (let iter = 0; iter < 8 && hi - lo > 0.5; iter += 1) {
      const mid = (lo + hi) / 2;
      div.style.fontSize = `${mid}px`;
      if (fits()) lo = mid; else hi = mid;
    }
    const size = Math.floor(lo * 2) / 2;
    div.style.fontSize = `${size}px`;
    return { size, fits: true };
  }

  const KANA_RESIDUE = /[ぁ-ゖゝ-ゟァ-ヺヽ-ヿㇰ-ㇿｦ-ｯｱ-ﾝ]/u;

  function untranslatedResidue(original, translated, target) {
    const text = String(translated || "");
    if (!/^ja/.test(target) && KANA_RESIDUE.test(text)) return true;
    if (/^(ja|zh)/.test(target) || typeof original !== "string" || !original) return false;
    return (text.match(/\p{Script=Han}{2,}/gu) || []).some((run) => original.includes(run));
  }

  /** 번역 실패·원문 그대로이거나 원문이 섞여 돌아온 결과도 원본 이미지 글자를 그대로 노출하지 않는다("번역 확인 필요"로 표시). */
  function markUnresolved(items, renderTarget) {
    const sameText = (text) => String(text || "").normalize("NFKC").replace(/\s+/gu, "").toLocaleLowerCase();
    return items.map((item) => {
      const unresolved = !item.t || untranslatedResidue(item.o, item.t, renderTarget) ||
        (/^ko/.test(renderTarget) && item.o && sameText(item.o) === sameText(item.t) &&
        /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u.test(item.o));
      return unresolved ? { ...item, t: "번역 확인 필요", unresolved: true } : item;
    });
  }

  /** 이미지 위에 번역 글자를 그린다. OCR 결과(items)는 background→숨은 엔진 문서가 만든 문단 단위 항목이다.
   *  글자 상자(g)가 없는 항목은 문단 전체 상자를 단색으로 덮는다(없는 상자를 지어내지 않음). */
  async function renderImage(candidate, items, langs) {
    return drawImage(candidate, items, langs);
  }

  async function drawImage(candidate, items, langs) {
    const renderTarget = state.target;
    items = markUnresolved(items, renderTarget);
    const { img, rect, clip } = candidate;
    const pageGen = state.pageGen, scrollGen = state.scrollGen, fontStyle = state.fontStyle;
    const previous = imageRecords.get(img);
    if (previous) previous.box.remove();
    const members = candidate.members || [img];
    for (const member of members) {
      const stale = member !== img ? imageRecords.get(member) : null;
      if (stale) { stale.box.remove(); imageRecords.delete(member); }
    }
    const root = layer();
    const box = document.createElement("div");
    box.className = "img";
    box.style.left = `${clip.x}px`;
    box.style.top = `${clip.y}px`;
    box.style.width = `${clip.w}px`;
    box.style.height = `${clip.h}px`;
    root.appendChild(box);
    const record = {
      key: candidate.key, members, box,
      offX: clip.x - rect.left, offY: clip.y - rect.top, w: clip.w, h: clip.h,
      elemW: rect.width, elemH: rect.height,
      langs: langs && typeof langs === "object" ? langs : undefined,
      items, done: false
    };
    imageRecords.set(img, record);
    const renderCurrent = () => {
      if (stillCurrent(pageGen) && state.scrollGen === scrollGen && state.fontStyle === fontStyle &&
          imageRecords.get(img) === record && candidateUnchanged(candidate)) return true;
      box.remove();
      if (imageRecords.get(img) === record) imageRecords.delete(img);
      return false;
    };

    const MIN_FONT = READABLE_MIN_FONT;
    const MAX_FONT = 240;

    // 원문 가림: 인식한 문단 배경색(item.bg)으로 글자 상자(item.g, 없으면 문단 전체)를 불투명하게 덮는다(단색 덮개,
    // 사진처럼 정교한 배경 복원은 하지 않는다. README의 알려진 제한 참고).
    const dpr = Math.max(1, Math.min(4, Number(window.devicePixelRatio) || 1));
    const maskCanvas = document.createElement("canvas");
    maskCanvas.className = "mask";
    maskCanvas.width = Math.max(1, Math.round(clip.w * dpr));
    maskCanvas.height = Math.max(1, Math.round(clip.h * dpr));
    const maskCtx = maskCanvas.getContext("2d");
    if (!renderCurrent()) return;
    if (maskCtx) {
      maskCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
      for (let i = 0; i < items.length; i += 1) {
        const item = items[i];
        const color = typeof item.bg === "string" && /^#[0-9A-Fa-f]{6}$/.test(item.bg) ? item.bg : "#FFFFFF";
        const boxes = Array.isArray(item.g) && item.g.length ? item.g : [[item.x, item.y, item.w, item.h]];
        const sizes = boxes.map((g) => Math.max(g[2] * clip.w, g[3] * clip.h)).sort((a, b) => a - b);
        const pad = Math.max(1.5, (sizes[Math.floor(sizes.length / 2)] || 0) * 0.08);
        maskCtx.fillStyle = color;
        for (const g of boxes) {
          if (!g.every(Number.isFinite) || g[2] <= 0 || g[3] <= 0) continue;
          maskCtx.fillRect(g[0] * clip.w - pad, g[1] * clip.h - pad, g[2] * clip.w + pad * 2, g[3] * clip.h + pad * 2);
        }
      }
      const maskImage = document.createElement("img");
      maskImage.className = "mask";
      maskImage.alt = "";
      maskImage.src = maskCanvas.toDataURL("image/png");
      let displayMask = maskImage;
      try { await maskImage.decode(); } catch { displayMask = maskCanvas; }
      if (!renderCurrent()) return;
      box.appendChild(displayMask);
    }

    function bodyGlyphSize(list) {
      const sorted = list.slice().sort((a, b) => a - b);
      while (sorted.length >= 3 && sorted[sorted.length - 1] > sorted[sorted.length - 2] * 2) sorted.pop();
      const ref = sorted[Math.floor((sorted.length - 1) * 0.75)];
      const body = sorted.filter((d) => d >= ref * 0.6);
      return body[Math.floor(body.length / 2)];
    }

    function glyphEstimate(item, vertical) {
      if (!Array.isArray(item.g) || !item.g.length) return null;
      const flags = typeof item.gl === "string" && item.gl.length === item.g.length ? item.gl : null;
      const cjk = LETTER_CJK.test(item.o || item.t);
      const dims = [], letters = [];
      item.g.forEach((g, index) => {
        const gw = g[2] * clip.w, gh = g[3] * clip.h;
        if (gw <= 0 || gh <= 0) return;
        if (gw >= clip.w * 0.9 || gh >= clip.h * 0.9) return;
        const size = cjk ? (vertical ? gw : gh) : Math.max(gw, gh);
        dims.push(size);
        if (flags && flags[index] === "1") letters.push(size);
      });
      if (letters.length) return bodyGlyphSize(letters);
      if (dims.length < 2) return null;
      const sorted = dims.slice().sort((a, b) => a - b);
      const median = sorted[Math.floor(sorted.length / 2)];
      if (median <= 0) return null;
      const filtered = dims.filter((d) => d >= median * 0.45);
      if (!filtered.length) return null;
      filtered.sort((a, b) => a - b);
      return filtered[Math.floor(filtered.length / 2)];
    }

    function isVerticalFlow(item, w, h) {
      // 엔진이 문단마다 실제 글자 배치(가로 패스/일본어 세로 패스 병합 결과)에서 온 가로/세로 신호를 주면 그대로 따른다.
      if (item.v === 1) return true;
      if (item.v === 0) return false;
      if (!LETTER_CJK.test(item.o || item.t)) return false;
      if (Array.isArray(item.g) && item.g.length >= 2) {
        const dx = [], dy = [];
        for (let k = 1; k < item.g.length; k += 1) {
          const a = item.g[k - 1], b = item.g[k];
          dx.push(Math.abs((b[0] + b[2] / 2 - a[0] - a[2] / 2) * clip.w));
          dy.push(Math.abs((b[1] + b[3] / 2 - a[1] - a[3] / 2) * clip.h));
        }
        const median = (list) => list.slice().sort((x, y) => x - y)[Math.floor(list.length / 2)];
        const across = median(dx), down = median(dy);
        return down === across ? w > 0 && h / w > 1.6 : down > across;
      }
      return w > 0 && h / w > 1.6;
    }

    const geoms = items.map((item) => {
      const w = item.w * clip.w, h = item.h * clip.h;
      const sourceVertical = isVerticalFlow(item, w, h);
      const glyph = glyphEstimate(item, sourceVertical);
      const estimate = glyph != null ? glyph : Math.min(w, h) * 0.968 * 0.88;
      return {
        w, h, sourceVertical, vertical: sourceVertical, estimate, cx: (item.x + item.w / 2) * clip.w,
        left: item.x * clip.w, top: item.y * clip.h, bottom: (item.y + item.h) * clip.h
      };
    });

    const groupOf = geoms.map((_, i) => i);
    const find = (i) => { while (groupOf[i] !== i) i = groupOf[i]; return i; };
    for (let i = 0; i < geoms.length; i += 1) {
      if (!geoms[i].sourceVertical) continue;
      for (let j = i + 1; j < geoms.length; j += 1) {
        if (!geoms[j].sourceVertical) continue;
        const a = geoms[i], b = geoms[j];
        const gap = Math.abs(a.cx - b.cx);
        const closeEnough = gap <= Math.max(a.w, b.w) * 1.5;
        const overlap = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        const minSpan = Math.min(a.bottom - a.top, b.bottom - b.top);
        const overlapsEnough = minSpan > 0 && overlap / minSpan >= 0.7;
        const similarSize = Math.max(a.estimate, b.estimate) <= Math.min(a.estimate, b.estimate) * 1.3;
        if (closeEnough && overlapsEnough && similarSize) {
          const ra = find(i), rb = find(j);
          if (ra !== rb) groupOf[rb] = ra;
        }
      }
    }
    for (let i = 0; i < geoms.length; i += 1) {
      if (geoms[i].sourceVertical) continue;
      for (let j = i + 1; j < geoms.length; j += 1) {
        if (geoms[j].sourceVertical) continue;
        const a = geoms[i], b = geoms[j];
        const [upper, lower] = a.top <= b.top ? [a, b] : [b, a];
        const gap = lower.top - upper.bottom;
        const heightRatio = lower.h / Math.max(upper.h, 0.0001);
        const alignedLeft = Math.abs(a.left - b.left) < Math.max(a.w, b.w) * 0.12;
        const similarSize = Math.max(a.estimate, b.estimate) <= Math.min(a.estimate, b.estimate) * 1.3;
        if (gap >= -upper.h * 0.3 && gap < upper.h * 0.9 && heightRatio > 0.65 && heightRatio < 1.5 && alignedLeft && similarSize) {
          const ra = find(i), rb = find(j);
          if (ra !== rb) groupOf[rb] = ra;
        }
      }
    }
    const byRoot = new Map();
    geoms.forEach((_, i) => {
      const r = find(i);
      if (!byRoot.has(r)) byRoot.set(r, []);
      byRoot.get(r).push(i);
    });
    const groupFs = items.map((item) => item.fs);
    const groupFw = items.map((item) => item.fw === 700);
    byRoot.forEach((idxs) => {
      if (idxs.length < 2) return;
      const sorted = idxs.map((i) => geoms[i].estimate).sort((x, y) => x - y);
      const median = sorted[Math.floor(sorted.length / 2)];
      idxs.forEach((i) => { geoms[i].estimate = median; });
      const votes = new Map();
      idxs.forEach((i) => { if (typeof items[i].fs === "string") votes.set(items[i].fs, (votes.get(items[i].fs) || 0) + 1); });
      let top = null;
      votes.forEach((count, style) => { if (!top || count > votes.get(top)) top = style; });
      const bold = idxs.filter((i) => items[i].fw === 700).length * 2 >= idxs.length;
      idxs.forEach((i) => { if (top) groupFs[i] = top; groupFw[i] = bold; });
    });

    const bounds = geoms.map((g) => {
      const room = g.sourceVertical || g.estimate < 40 ? Math.max(MIN_FONT, g.estimate) : 0;
      return g.sourceVertical ? {
        left: Math.max(0, g.left - room * 0.6),
        right: Math.min(clip.w, g.left + g.w + room * 0.4),
        top: Math.max(0, g.top - room * 0.2),
        bottom: Math.min(clip.h, g.bottom + room * 0.6)
      } : {
        left: g.left,
        right: Math.min(clip.w, g.left + g.w + room * 1.2),
        top: g.top,
        bottom: Math.min(clip.h, g.bottom + room * 0.8)
      };
    });
    for (let i = 0; i < bounds.length; i += 1) {
      for (let j = i + 1; j < bounds.length; j += 1) {
        const a = bounds[i], b = bounds[j];
        const left = Math.max(a.left, b.left), right = Math.min(a.right, b.right);
        const top = Math.max(a.top, b.top), bottom = Math.min(a.bottom, b.bottom);
        if (left >= right || top >= bottom) continue;
        const ga = geoms[i], gb = geoms[j];
        const originalOverlap = ga.left < gb.left + gb.w && ga.left + ga.w > gb.left &&
            ga.top < gb.bottom && ga.bottom > gb.top;
        const stackedBody = !ga.sourceVertical && !gb.sourceVertical && ga.estimate < 40 && gb.estimate < 40 &&
          Math.min(ga.left + ga.w, gb.left + gb.w) - Math.max(ga.left, gb.left) > Math.min(ga.w, gb.w) * 0.5 &&
          Math.abs(ga.top + ga.h / 2 - gb.top - gb.h / 2) > Math.min(ga.h, gb.h) * 0.3;
        if (originalOverlap && !stackedBody) continue;
        const ay = ga.top + ga.h / 2, by = gb.top + gb.h / 2;
        if (!stackedBody && Math.abs(ga.cx - gb.cx) >= Math.abs(ay - by)) {
          const center = (ga.cx + gb.cx) / 2;
          const split = center > left && center < right ? center : (left + right) / 2;
          const [before, after] = ga.cx <= gb.cx ? [a, b] : [b, a];
          before.right = split;
          after.left = split;
        } else {
          const center = (ay + by) / 2;
          const split = center > top && center < bottom ? center : (top + bottom) / 2;
          const [before, after] = ay <= by ? [a, b] : [b, a];
          before.bottom = split;
          after.top = split;
        }
      }
    }

    const styles = items.map((_, i) => resolveFontStyle(groupFs[i]));
    const uniqueStyles = [...new Set(styles)];
    await Promise.all(uniqueStyles.map((style) => loadBundledFont(style)));
    if (!renderCurrent()) return;

    const joiner = /^(ja|zh)/.test(renderTarget) ? "" : " ";
    const overlapArea = (a, b) => Math.max(0, Math.min(a.right, b.right) - Math.max(a.left, b.left)) *
      Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
    const units = [];
    const unitOf = new Array(items.length);
    const addUnit = (members2, area) => {
      units.push({ members: members2, area: { ...area }, vertical: geoms[members2[0]].sourceVertical, parts: [] });
      members2.forEach((i) => { unitOf[i] = units.length - 1; });
    };
    byRoot.forEach((idxs) => {
      if (idxs.length >= 2 && idxs.every((i) => !items[i].unresolved)) {
        const vertical = geoms[idxs[0]].sourceVertical;
        const members2 = idxs.slice().sort((a, b) => {
          const ga = geoms[a], gb = geoms[b];
          const tolerance = Math.max(ga.estimate, gb.estimate) * 0.5;
          if (vertical) return Math.abs(ga.cx - gb.cx) > tolerance ? gb.cx - ga.cx : ga.top - gb.top;
          return Math.abs(ga.top - gb.top) > tolerance ? ga.top - gb.top : ga.left - gb.left;
        });
        const area = members2.reduce((u, i) => ({
          left: Math.min(u.left, bounds[i].left), right: Math.max(u.right, bounds[i].right),
          top: Math.min(u.top, bounds[i].top), bottom: Math.max(u.bottom, bounds[i].bottom)
        }), { ...bounds[members2[0]] });
        const intrudes = bounds.some((b, j) => !members2.includes(j) && overlapArea(area, b) > 1);
        if (!intrudes) { addUnit(members2, area); return; }
      }
      idxs.forEach((i) => addUnit([i], bounds[i]));
    });

    for (let i = 0; i < units.length; i += 1) {
      for (let j = i + 1; j < units.length; j += 1) {
        const a = units[i].area, b = units[j].area;
        const left = Math.max(a.left, b.left), right = Math.min(a.right, b.right);
        const top = Math.max(a.top, b.top), bottom = Math.min(a.bottom, b.bottom);
        if (right - left <= 1 || bottom - top <= 1) continue;
        const ga = geoms[units[i].members[0]], gb = geoms[units[j].members[0]];
        const ay = ga.top + ga.h / 2, by = gb.top + gb.h / 2;
        if (Math.abs(ga.cx - gb.cx) < 1 && Math.abs(ay - by) < 1) continue;
        const sideBySide = Math.abs(ga.cx - gb.cx) >= Math.abs(ay - by);
        if (sideBySide) {
          const split = Math.max(left, Math.min(right, (ga.cx + gb.cx) / 2));
          const [before, after] = ga.cx <= gb.cx ? [a, b] : [b, a];
          before.right = split;
          after.left = split;
        } else {
          const split = Math.max(top, Math.min(bottom, (ay + by) / 2));
          const [before, after] = ay <= by ? [a, b] : [b, a];
          before.bottom = split;
          after.top = split;
        }
      }
    }

    const place = (div, area) => {
      div.style.left = `${area.left}px`;
      div.style.top = `${area.top}px`;
      div.style.width = `${Math.max(0, area.right - area.left)}px`;
      div.style.height = `${Math.max(0, area.bottom - area.top)}px`;
    };
    const setOrientation = (div, vertical, centered) => {
      div.classList.toggle("vert", vertical);
      div.classList.toggle("ctr", centered);
      div.style.writingMode = vertical ? "vertical-rl" : "";
      // 세로 칸에 영어 번역문을 넣을 때는 글자를 하나씩 세우지 않고 90도 돌려 읽히게 한다(한·중·일 글자는 똑바로 세움).
      div.style.textOrientation = vertical ? (renderTarget === "en" ? "mixed" : "upright") : "";
    };

    for (const unit of units) {
      const lead = unit.members[0];
      const item = items[lead];
      const div = document.createElement("div");
      div.className = "t";
      place(div, unit.area);
      div.style.color = contrastColor(item.bg);
      if (!maskCtx) div.style.background = typeof item.bg === "string" && /^#[0-9A-Fa-f]{6}$/.test(item.bg) ? item.bg : "#FFFFFF";
      if (groupFw[lead]) div.style.fontWeight = "700";
      const fontStyle = styles[lead];
      div.style.fontFamily = fontFamilyFor(fontStyle);
      const text = document.createElement("span");
      text.className = "tt";
      if (!item.unresolved) {
        if (unit.members.length === 1) { text.textContent = item.t; unit.parts.push(text); }
        else {
          unit.members.forEach((i, k) => {
            if (k) text.appendChild(document.createTextNode(joiner));
            const part = document.createElement("span");
            part.textContent = items[i].t;
            text.appendChild(part);
            unit.parts.push(part);
          });
        }
      }
      div.appendChild(text);
      box.appendChild(div);
      unit.div = div;
      unit.text = text;
      if (item.unresolved) {
        setOrientation(div, unit.vertical, false);
        unit.estimate = geoms[lead].estimate;
        unit.minFont = MIN_FONT;
        unit.preferredMax = MIN_FONT;
        unit.fitted = { size: MIN_FONT, fits: true };
        continue;
      }
      const { estimate } = geoms[lead];
      const sourcePx = Math.max(1, estimate);
      const scaledMin = Math.min(MIN_FONT, Math.max(1, Math.floor(sourcePx)));
      unit.estimate = estimate;
      unit.minFont = scaledMin;
      unit.preferredMax = Math.min(MAX_FONT, Math.max(scaledMin, Math.round(sourcePx)));
      const title = !unit.vertical && estimate >= 40 && text.textContent.length <= 30 &&
        (unit.area.right - unit.area.left) >= (unit.area.bottom - unit.area.top) * 1.6;
      unit.title = title;
      const verticalXs = (item.g || []).filter((_, i) => !item.gl || item.gl[i] === "1")
        .map((g) => (g[0] + g[2] / 2) * clip.w);
      const singleVerticalColumn = unit.vertical && unit.members.length === 1 && geoms[lead].w <= estimate * 1.8 &&
        verticalXs.length > 0 && Math.max(...verticalXs) - Math.min(...verticalXs) <= estimate * 0.65;
      text.style.whiteSpace = title || singleVerticalColumn ? "nowrap" : "normal";
      setOrientation(div, unit.vertical, title);
      unit.fitted = fitFontSize(div, text, unit.minFont, unit.preferredMax, unit.vertical);
    }

    units.forEach((unit) => {
      if (unit.title || (unit.fitted.fits && unit.fitted.size >= unit.preferredMax * 0.75)) return;
      const a = unit.area;
      const others = units.filter((u) => u !== unit).map((other) => other.area);
      const lines = Math.max(MIN_FONT, unit.estimate) * 1.2 * 2;
      const growBottom = (r, limit) => others.reduce((edge, o) =>
        (o.left < r.right && o.right > r.left && o.bottom > r.bottom ? Math.min(edge, Math.max(r.bottom, o.top)) : edge), limit);
      const growLeft = (r, limit) => others.reduce((edge, o) =>
        (o.top < r.bottom && o.bottom > r.top && o.left < r.left ? Math.max(edge, Math.min(r.left, o.right)) : edge), limit);
      const growRight = (r, limit) => others.reduce((edge, o) =>
        (o.top < r.bottom && o.bottom > r.top && o.right > r.right ? Math.min(edge, Math.max(r.right, o.left)) : edge), limit);
      const next = { ...a };
      if (unit.vertical) next.left = growLeft(next, Math.max(0, a.left - lines));
      else {
        next.right = growRight(next, Math.min(clip.w, a.right + (a.right - a.left) * 0.5));
        next.bottom = growBottom(next, Math.min(clip.h, a.bottom + lines));
      }
      if (next.bottom - a.bottom < 1 && a.left - next.left < 1 && next.right - a.right < 1) return;
      place(unit.div, next);
      const result = fitFontSize(unit.div, unit.text, unit.minFont, unit.preferredMax, unit.vertical);
      if (result.size > unit.fitted.size || (result.fits && !unit.fitted.fits)) {
        unit.area = next;
        unit.fitted = result;
      } else {
        place(unit.div, a);
        unit.fitted = fitFontSize(unit.div, unit.text, unit.minFont, unit.preferredMax, unit.vertical);
      }
    });

    for (const unit of units) {
      if (!unit.fitted.fits && unit.text.style.whiteSpace === "nowrap") {
        unit.text.style.whiteSpace = "normal";
        unit.fitted = fitFontSize(unit.div, unit.text, unit.minFont, unit.preferredMax, unit.vertical);
      }
    }

    byRoot.forEach((idxs) => {
      const ids = [...new Set(idxs.map((i) => unitOf[i]))];
      if (ids.length < 2) return;
      const sorted = ids.map((u) => units[u].fitted.size).sort((a, b) => a - b);
      const median = sorted[Math.floor(sorted.length / 2)];
      ids.forEach((u) => {
        const unit = units[u];
        if (unit.fitted.size <= median) return;
        unit.fitted = fitFontSize(unit.div, unit.text, Math.min(unit.minFont, median), median, unit.vertical);
      });
    });

    for (const unit of units) {
      const item = items[unit.members[0]];
      const { div, text, fitted } = unit;
      const stroke = div.style.color === "rgb(255, 255, 255)" || div.style.color === "white" || div.style.color === "#FFFFFF" ? "#303030" : "#FFFFFF";
      if (stroke) {
        const inset = parseFloat(text.style.padding) || 1;
        const r = Math.min(inset / 3, Math.max(1, Math.min(1.5, fitted.size * 0.025)));
        const offsets = [[r, 0], [-r, 0], [0, r], [0, -r], [r, r], [-r, -r], [r, -r], [-r, r]];
        text.style.textShadow = offsets.map(([x, y]) => `${x}px ${y}px 0 ${stroke}`).join(",") + `,0 0 ${r * 2}px ${stroke}`;
      }
      if (!fitted.fits) {
        const plate = typeof item.bg === "string" && /^#[0-9A-Fa-f]{6}$/.test(item.bg) ? item.bg : "#FFFFFF";
        text.style.background = plate;
        text.style.borderRadius = "3px";
        text.style.boxDecorationBreak = "clone";
        text.style.webkitBoxDecorationBreak = "clone";
      }
      div.style.overflow = "hidden";
    }

    if (items.some((it) => it.unresolved)) {
      const fail = document.createElement("div");
      fail.className = "fail";
      fail.textContent = "번역 확인 필요";
      box.appendChild(fail);
    }

    if (renderCurrent()) record.done = true;
  }

  function rerenderImageRecords(imgs) {
    for (const [img, record] of Array.from(imageRecords.entries())) {
      if (imgs && !imgs.has(img)) continue;
      if (!img.isConnected || !Array.isArray(record.items)) continue;
      const geometry = recordGeometry(img, record);
      if (!geometry) continue;
      const { rect, rects } = geometry;
      const candidate = {
        img, members: record.members, rects, rect, key: record.key,
        clip: { x: rect.left + record.offX, y: rect.top + record.offY, w: record.w, h: record.h }
      };
      renderImage(candidate, record.items, record.langs).catch(() => {});
    }
  }

  function rerenderImageFonts() { rerenderImageRecords(null); }

  function imageCardText(img) {
    let card = "";
    for (let el = img.parentElement, depth = 0; el && el !== document.body && depth < 4; el = el.parentElement, depth += 1) {
      if (el.textContent.length > 600) break;
      card = originalTextOf(el, 600, " ");
    }
    return card;
  }

  function withoutImageNames(img, items) {
    if (!Array.isArray(items) || !items.length) return items;
    const alt = `${img.alt || ""} ${img.getAttribute("aria-label") || ""}`;
    const card = imageCardText(img);
    const escape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return items.filter((item) => {
      const word = typeof item.o === "string" ? item.o.trim() : "";
      if (!/^[A-Za-z][A-Za-z0-9.+\-]{1,23}$/.test(word)) return true;
      const w = escape(word);
      if (new RegExp(`(^|[^\\p{L}\\p{N}])${w}($|[^\\p{L}\\p{N}])`, "u").test(alt)) return false;
      return !new RegExp(`(^|\\s)\\S*\\d\\S*\\s+${w}($|[^\\p{L}\\p{N}])`, "u").test(card);
    });
  }

  function viewportOverlapArea(el) {
    const rect = el.getBoundingClientRect();
    const w = Math.max(0, Math.min(innerWidth, rect.right) - Math.max(0, rect.left));
    const h = Math.max(0, Math.min(innerHeight, rect.bottom) - Math.max(0, rect.top));
    return w * h;
  }

  function imageAnimationsDone() {
    if (typeof document.getAnimations !== "function") return Promise.resolve();
    const waits = [];
    for (const animation of document.getAnimations()) {
      const target = animation.effect && animation.effect.target;
      if (!(target instanceof Element) || animation.playState !== "running") continue;
      const imgs = target.tagName === "IMG" ? [target] : target.querySelectorAll("img");
      const relevant = Array.from(imgs).some((candidateImg) =>
        isImageVisible(candidateImg) && viewportOverlapArea(candidateImg) >= 60 * 30);
      if (!relevant) continue;
      const end = animation.effect.getComputedTiming().endTime;
      if (!Number.isFinite(end)) continue;
      const left = (end - Number(animation.currentTime || 0)) / Math.abs(animation.playbackRate || 1);
      waits.push(Promise.race([
        animation.finished.catch(() => {}),
        new Promise((resolve) => setTimeout(resolve, Math.max(0, left)))
      ]));
    }
    return Promise.all(waits);
  }

  async function imagePass(pageGen) {
    repositionOverlays();
    if (!state.images || document.visibilityState !== "visible") return;
    const action = state.passAction && state.passAction.gen === pageGen ? state.passAction : null;
    markStage(action, "capture");
    await imageAnimationsDone();
    if (!stillCurrent(pageGen) || document.visibilityState !== "visible") return;
    repositionOverlays();
    let candidates = imageCandidates();
    const inventory = inventoryOf(pageGen);
    const known = imageInventory();
    updateInventory(inventory, { images: known.images, imageSentences: known.imageSentences });
    if (!candidates.length) return;
    const scrollGen = state.scrollGen;
    const sx = scrollX, sy = scrollY;
    const viewport = { w: innerWidth, h: innerHeight };
    ocrInFlight = true;
    commitAction(action);
    try {
      const decoded = await Promise.all(candidates.map((c) =>
        Promise.all(c.members.map((m) => m.decode())).then(() => true, () => false)));
      candidates = candidates.filter((c, index) => decoded[index]);
      if (!candidates.length) return;
      captureHidden = true;
      applyLayerVisibility();
      let capture;
      try {
        await nextFrames(2);
        candidates = captureReadyCandidates(candidates);
        if (!candidates.length || !stillCurrent(pageGen) || scrollGen !== state.scrollGen) return;
        capture = await send({ cmd: "capture" });
      } finally {
        captureHidden = false;
        applyLayerVisibility();
      }
      if (!stillCurrent(pageGen) || scrollGen !== state.scrollGen || scrollX !== sx || scrollY !== sy) return;
      candidates = captureReadyCandidates(candidates);
      if (!candidates.length) return;
      const regions = candidates.map((c, index) => ({ k: `i${index}`, x: c.clip.x, y: c.clip.y, w: c.clip.w, h: c.clip.h }));
      updateInventory(inventory, { phase: "ocr" });
      markStage(action, "ocr");
      const pageHint = pageLangHint();
      const response = await send({ cmd: "ocr", captureId: capture.captureId, target: state.target, source: state.source,
                                    ocrLang: state.ocrLang, viewport, regions, ...(pageHint ? { hint: pageHint } : {}),
                                    ...(action ? { action: action.id } : {}) });
      if (!stillCurrent(pageGen) || scrollGen !== state.scrollGen || scrollX !== sx || scrollY !== sy) return;
      if (response.missing && response.missing.length) state.warning = `번역 엔진 준비 필요: ${response.missing.join(", ")}`;
      if (response.warning) state.warning = response.warning;
      markStage(action, "render");
      for (const image of response.images) {
        if (pageGen !== state.pageGen || scrollGen !== state.scrollGen) break;
        const index = Number(String(image.k).slice(1));
        const candidate = candidates[index];
        if (!candidate || `i${index}` !== image.k) continue;
        if (!candidateUnchanged(candidate)) continue;
        await renderImage(candidate, withoutImageNames(candidate.img, image.items), image.langs);
      }
      const finalInventory = imageInventory();
      updateInventory(inventory, { images: finalInventory.images, imageSentences: finalInventory.imageSentences });
    } finally {
      ocrInFlight = false;
    }
  }

  // MARK: 번역 실행

  function checkNavigation() {
    if (location.href === state.url) return false;
    state.url = location.href;
    state.pageGen += 1;
    state.action = null;
    clearImageOverlays();
    send({ cmd: "cancel" }).catch(() => {});
    return true;
  }

  function stillCurrent(pageGen) {
    if (contextDead) return false;
    if (checkNavigation()) state.rerun = true;
    return pageGen === state.pageGen;
  }

  async function runPass(manual = false) {
    if (contextDead) return;
    if (state.running) {
      state.rerun = true;
      if (manual) state.rerunManual = true;
      return;
    }
    if (!manual && !isAutoLike()) return;
    if (document.visibilityState !== "visible") return;
    checkNavigation();
    state.running = true;
    let imageInv = { images: 0, imageSentences: 0 };
    if (state.images) {
      try { imageInv = imageInventory(); } catch { imageInv = { images: 0, imageSentences: 0 }; }
    }
    state.inventory = { gen: state.pageGen, phase: "search", textMessages: null, textSentences: null,
                        images: imageInv.images, imageSentences: imageInv.imageSentences };
    const action = adoptAction(manual);
    reportProgress();
    state.error = "";
    state.warning = "";
    const pageGen = state.pageGen;
    try {
      setStatus("번역 중");
      await translateTextPass(pageGen);
      if (pageGen === state.pageGen) {
        if (state.images) setStatus("이미지 글자 확인 중");
        try {
          await imagePass(pageGen);
        } catch (error) {
          if (error.code !== "cancelled" && error.code !== "stale" && error.code !== "tab_hidden") {
            state.warning = `이미지: ${error.message}`;
          }
        }
      }
      if (pageGen === state.pageGen) {
        finishAction(action, "done");
        setStatus(state.warning ? "완료 · 일부 경고" : "완료");
      } else {
        finishAction(action, "cancelled");
      }
    } catch (error) {
      if (error.code === "cancelled" || error.code === "stale" || error.code === "contextinvalid") {
        finishAction(action, "cancelled");
      } else {
        state.error = error.message || "번역하지 못했습니다.";
        setStatus("오류");
        finishAction(action, "error");
      }
    } finally {
      state.running = false;
      reportProgress();
      if ((state.rerun || state.rerunManual) && !contextDead) {
        const manualRerun = state.rerunManual;
        state.rerun = false;
        state.rerunManual = false;
        if (manualRerun || isAutoLike()) runPass(manualRerun);
      }
    }
  }

  function setView(view) {
    if (state.view === view) return;
    state.view = view;
    for (const [node, record] of records) {
      if (!node.isConnected) { records.delete(node); continue; }
      if (record.translated === null) continue;
      const from = view === "translated" ? record.original : record.translated;
      const to = view === "translated" ? record.translated : record.original;
      if (node.nodeValue === from) node.nodeValue = to;
    }
    applyLayerVisibility();
    setStatus(view === "translated" ? "번역 표시" : "원문 표시");
    reportProgress();
  }

  // MARK: 변경 감시(자동 번역일 때만) — 자기 변경은 걸러 무한 반복을 막는다.

  function invalidateImage(img) {
    for (const [anchor, record] of imageRecords) {
      if (anchor !== img && !record.members.includes(img)) continue;
      record.box.remove();
      imageRecords.delete(anchor);
    }
    state.scrollGen += 1;
    if (ocrInFlight) send({ cmd: "cancel", kind: "ocr" }).catch(() => {});
  }

  const observer = new MutationObserver((mutations) => {
    let changed = checkNavigation();
    let removed = false;
    for (const mutation of mutations) {
      if (mutation.type === "attributes") {
        const target = mutation.target;
        if (target === layerHost) continue;
        const attr = mutation.attributeName;
        if (target.tagName === "IMG") {
          if (attr !== "class" && attr !== "style") invalidateImage(target);
          changed = true;
        } else if (target.tagName === "SOURCE") {
          if (attr !== "src" && attr !== "srcset") continue;
          const picture = target.parentElement;
          const img = picture && picture.tagName === "PICTURE" ? picture.querySelector("img") : null;
          if (img) invalidateImage(img);
          changed = true;
        } else if (attr === "class" || attr === "style") {
          let relevant = false;
          for (const [img, record] of imageRecords) {
            if (record.members.some((m) => target.contains(m))) relevant = true;
          }
          if (!relevant && target.querySelector("img")) relevant = true;
          if (!relevant && touchesImageCover(target)) relevant = true;
          if (relevant) changed = true;
        }
      } else if (mutation.type === "characterData") {
        const record = records.get(mutation.target);
        if (record && (mutation.target.nodeValue === record.translated || mutation.target.nodeValue === record.original)) continue;
        changed = true;
      } else {
        if (mutation.removedNodes.length) removed = true;
        for (const node of mutation.removedNodes) {
          if (touchesImageCover(node)) changed = true;
        }
        for (const node of mutation.addedNodes) {
          if (node !== layerHost) changed = true;
        }
      }
    }
    if (removed) {
      for (const [img, record] of imageRecords) {
        if (record.members.every((m) => m.isConnected)) continue;
        record.box.remove();
        imageRecords.delete(img);
      }
    }
    if (changed) onPageChanged();
  });
  let observing = false;

  function onPageChanged() {
    if (isAutoLike()) schedule();
  }

  function onImageLoad(event) {
    if (event.target instanceof HTMLImageElement && isAutoLike()) schedule();
  }

  function onCoverSettled(event) {
    if (!isAutoLike()) return;
    if (imageCovers.size && touchesImageCover(event.target)) schedule();
    else if (event.propertyName === "opacity" && event.target instanceof Element &&
             !event.target.closest(SKIP_SELECTOR) && Number(getComputedStyle(event.target).opacity) > 0.01 &&
             LETTER.test(event.target.textContent || "")) schedule();
  }

  function setObserving(on) {
    if (on && !observing && document.body) {
      observer.observe(document.body, {
        childList: true, subtree: true, characterData: true,
        attributes: true, attributeFilter: ["src", "srcset", "class", "style"]
      });
      document.addEventListener("load", onImageLoad, true);
      document.addEventListener("transitionend", onCoverSettled, true);
      document.addEventListener("animationend", onCoverSettled, true);
      observing = true;
    } else if (!on && observing) {
      observer.disconnect();
      document.removeEventListener("load", onImageLoad, true);
      document.removeEventListener("transitionend", onCoverSettled, true);
      document.removeEventListener("animationend", onCoverSettled, true);
      observing = false;
    }
  }

  const SCHEDULE_DELAY = 350;
  function schedule() {
    clearTimeout(state.timer);
    state.timer = setTimeout(() => { state.timer = 0; runPass(false); }, SCHEDULE_DELAY);
  }

  // MARK: 스크롤·크기·표시 상태

  function onScroll(event) {
    state.scrollGen += 1;
    if (ocrInFlight) send({ cmd: "cancel", kind: "ocr" }).catch(() => {});
    const scroller = event?.target;
    if (scroller instanceof Element) {
      for (const [img, record] of imageRecords) {
        if (record.members.some((m) => scroller.contains(m))) record.box.style.display = "none";
      }
    }
    if (isAutoLike()) schedule();
  }

  function onFullscreenChange() {
    if (layerHost) {
      const parent = fullscreenTarget() || document.documentElement;
      if (layerHost.parentNode !== parent) parent.appendChild(layerHost);
    }
    state.scrollGen += 1;
    if (ocrInFlight) send({ cmd: "cancel", kind: "ocr" }).catch(() => {});
    clearImageOverlays();
    if (isAutoLike()) schedule();
  }

  addEventListener("scroll", onScroll, { passive: true, capture: true });
  addEventListener("resize", onScroll, { passive: true });
  document.addEventListener("fullscreenchange", onFullscreenChange);
  document.addEventListener("webkitfullscreenchange", onFullscreenChange);
  function onHistoryChange() {
    checkNavigation();
    if (isAutoLike()) schedule();
  }
  addEventListener("popstate", onHistoryChange);
  addEventListener("hashchange", onHistoryChange);
  addEventListener("pagehide", () => send({ cmd: "cancel" }).catch(() => {}));
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState !== "visible") {
      if (ocrInFlight) send({ cmd: "cancel", kind: "ocr" }).catch(() => {});
    } else if (isAutoLike()) {
      schedule();
    }
  });

  // MARK: 확장 메시지

  const letterCount = (text) => (typeof text === "string" ? Array.from(text.replace(/\s+/gu, "")).length : 0);

  function translatedLetters() {
    let text = 0, image = 0, imageItems = 0;
    if (state.view !== "translated") return { text, image, imageItems };
    const current = profile();
    for (const [node, record] of records) {
      if (record.translated === null || record.target !== current || !node.isConnected || node.nodeValue !== record.translated) continue;
      text += letterCount(record.original);
    }
    const seen = new Set();
    for (const [img, record] of imageRecords) {
      if (seen.has(record) || !img.isConnected || !record.box.isConnected || !Array.isArray(record.items)) continue;
      seen.add(record);
      for (const item of record.items) {
        if (!item || item.unresolved || typeof item.t !== "string" || !item.t.trim()) continue;
        const n = letterCount(item.o);
        if (n <= 0) continue;
        image += n;
        imageItems += 1;
      }
    }
    return { text, image, imageItems };
  }

  function snapshot() {
    let translated = 0;
    const langCounts = {};
    let hasLangData = false;
    const letters = translatedLetters();
    for (const record of records.values()) {
      if (record.translated !== null) translated += 1;
      if (record.lang) { hasLangData = true; langCounts[record.lang] = (langCounts[record.lang] || 0) + 1; }
    }
    for (const record of imageRecords.values()) {
      if (!record.langs) continue;
      for (const [lang, c] of Object.entries(record.langs)) {
        const n = Number(c);
        if (!Number.isFinite(n) || n <= 0) continue;
        hasLangData = true;
        langCounts[lang] = (langCounts[lang] || 0) + n;
      }
    }
    const action = state.action;
    const actionSnapshot = action && action.gen === state.pageGen ? {
      id: action.id, startedAt: action.startedAt, source: action.source,
      outcome: action.outcome, endedAt: action.endedAt,
      stage: action.stages.length && action.stages[action.stages.length - 1].b === null
        ? action.stages[action.stages.length - 1].s : null
    } : null;
    return {
      ok: true, view: state.view, auto: state.auto, images: state.images, pageText: state.pageText, ocrLang: state.ocrLang,
      target: state.target, source: state.source,
      fontStyle: state.fontStyle, status: state.status, error: state.error, warning: state.warning,
      translated, imageCount: imageRecords.size,
      letters: { total: letters.text + letters.image, text: letters.text, image: letters.image, imageItems: letters.imageItems },
      langCounts: hasLangData ? langCounts : null,
      running: isBusy(),
      inventory: inventoryOf(state.pageGen),
      action: actionSnapshot
    };
  }

  function reportProgress() {
    if (contextDead) return;
    try {
      const result = api.runtime.sendMessage({ cmd: "progress", running: isBusy(), view: state.view });
      if (result && typeof result.catch === "function") result.catch(() => {});
    } catch { /* 확장 컨텍스트 무효화 등 — 조용히 무시 */ }
  }

  api.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (contextDead || sender.id !== api.runtime.id || !message || typeof message.cmd !== "string") return false;
    switch (message.cmd) {
      case "configure": {
        if (!Number.isFinite(message.epoch) || message.epoch < state.stopEpoch) { sendResponse(snapshot()); return false; }
        const targetChanged = typeof message.target === "string" && message.target !== state.target;
        const sourceChanged = typeof message.source === "string" && message.source !== state.source;
        const fontStyleChanged = typeof message.fontStyle === "string" && FONT_STYLES.includes(message.fontStyle) &&
          message.fontStyle !== state.fontStyle;
        state.auto = message.auto === true;
        state.images = message.images !== false;
        const pageText = message.pageText === true;
        if (pageText !== state.pageText) {
          state.pageText = pageText;
          if (!pageText) revertAllRecords(); // 이 확장이 바꾼 글자만 원문으로 되돌린다(브라우저 번역 결과는 건드리지 않음)
        }
        const ocrLangChanged = typeof message.ocrLang === "string" && message.ocrLang !== state.ocrLang;
        if (fontStyleChanged) {
          state.fontStyle = message.fontStyle;
          rerenderImageFonts();
        }
        if (targetChanged || sourceChanged || ocrLangChanged) {
          if (targetChanged) state.target = message.target;
          if (sourceChanged) state.source = message.source;
          if (ocrLangChanged) state.ocrLang = message.ocrLang;
          state.pageGen += 1;
          revertAllRecords();
          state.warning = "";
          clearImageOverlays();
          send({ cmd: "cancel" }).catch(() => {});
        }
        if (state.auto || message.translateNow === true) setObserving(true);
        if (message.translateNow === true) {
          const trigger = message.trigger === "button" ? "click" : "open";
          if (trigger === "click" || !state.running) state.pendingAction = newAction(clickTime(message.clickedAt), trigger);
          setView("translated");
          clearTimeout(state.timer);
          state.timer = 0;
          runPass(true);
        } else if (state.auto) {
          setView("translated");
          schedule();
        }
        sendResponse(snapshot());
        return false;
      }
      case "toggleOriginal":
        if (Number.isFinite(message.epoch)) state.stopEpoch = Math.max(state.stopEpoch, message.epoch);
        state.auto = false;
        state.rerun = false;
        state.rerunManual = false;
        state.pendingAction = null;
        setObserving(false);
        clearTimeout(state.timer);
        state.timer = 0;
        state.pageGen += 1;
        state.scrollGen += 1;
        clearImageOverlays();
        setView("original");
        sendResponse(snapshot());
        return false;
      case "state":
        sendResponse(snapshot());
        return false;
      default:
        return false;
    }
  });
})();
