"use strict";
// 바로보기 웹 번역 — 배경 서비스 워커(Chrome·Whale MV3).
// - 이 파일은 페이지 번역 요청을 검증하고, 실제 번역·OCR·모델 내려받기는 화면에 보이지 않는 엔진 문서(engine.html,
//   offscreen 문서, 프로필당 하나)로 넘긴다. 무거운 모델(WASM)은 서비스 워커가 아니라 그 문서의 전용 Worker에서 돈다.
//   보이는 창·탭·사이드패널은 열지 않는다.
// - 저장하는 값: 번역 언어·원문 언어·페이지 글자 번역 여부·OCR 언어(+사용자가 골랐다는 표시)·글꼴·
//   전역 자동 번역 켜짐 여부·설정 이전 버전 번호, 모델 내려받기 진행 표시(엔진 문서 대신 저장)뿐이다.
//   페이지 내용은 저장하지 않는다. 이미지 속 글자 번역은 항상 켜져 있다(0.3.0부터 옵션 아님).
// - 탭별로 요청 ID를 추적해 탭 이동·닫기·취소 때 그 탭의 요청만 정리한다.
// - 전역 자동 번역은 세대(control.epoch)로 직렬화한다: 끄기는 즉시 세대를 올리고, 비동기 흐름은 보내기 직전 세대를
//   다시 확인한다(권한 철회·원문 보기 뒤 늦은 요청이 되살아나지 않게).

// 중국어(번체) 출력은 공통 로컬 모델이 지원하지 않아 0.3.0부터 고를 수 없다(예전에 골라 둔 값은 한국어로 돌아간다).
const TARGETS = ["ko", "en", "ja", "zh"];
const SOURCES = ["auto", "ko", "en", "ja", "zh"]; // 원문 중국어는 간체·번체 모두 "zh"(공통 모델이 하나로 다룸)
// "auto"(0.2.0 기본): 다국어 가로 + 일본어 세로 후보 자동 인식. 나머지는 어려운 이미지용 수동 지정.
const OCR_LANGS = ["auto", "jpn_vert", "jpn", "eng", "chi_sim", "kor"];
const ALL_URLS = "<all_urls>";
const DOWNLOAD_ORIGINS = ["https://huggingface.co/*", "https://*.hf.co/*"]; // 번역 모델 파일 주소(선택 권한)
const TAB_MESSAGE_TIMEOUT = 5000;
const LIMITS = { texts: 150, textLength: 5000, chars: 40000, regions: 16, glyphsPerItem: 128, glyphsTotal: 8192 };
const CAPTURE_MIN_INTERVAL = 700; // chrome.tabs.captureVisibleTab 호출 빈도 제한(초당 2회) 아래로 유지
const CAPTURE_TTL = 15000;
const CAPTURE_CALL_TIMEOUT = 10000;
const FONT_STYLES = ["auto", "gothic", "myeongjo", "gungseo", "hand"];
// pageText: 페이지 글자(DOM)도 이 확장으로 번역할지(기본 끔 — 페이지 글자는 브라우저 메뉴의 번역을 쓰고, 이 확장은 이미지만).
const DEFAULTS = { target: "ko", source: "auto", images: true, automaticEnabled: false, fontStyle: "auto", pageText: false, ocrLang: "auto" };
const SETTINGS_VERSION = 2; // 0.2.0: OCR 기본값 jpn → auto 이전(아래 migrateSettings)

function codedError(code, message) {
  const error = new Error(message || code);
  error.code = code;
  return error;
}

function originOf(url) {
  try {
    const parsed = new URL(url);
    return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.origin : null;
  } catch {
    return null;
  }
}

// MARK: - 설정 이전(0.1.x → 0.2.0, 한 번만, 지우지 않음)
// 0.1.x는 OCR 언어 기본값이 "jpn"이었고, 사용자가 고를 때만 저장했으며 "누가 정했는지" 표시가 없었다.
// - 저장된 값이 없음: 예전 기본값을 쓰던 것 → 새 기본값 "auto"가 그대로 적용된다(쓸 것 없음).
// - 저장된 값이 "jpn": 0.1.x 화면에는 자동 항목이 없었고 "jpn"이 첫 기본 항목이었다. 자동 인식이 일본어 가로를 포함하므로
//   한 번만 "auto"로 바꾼다(사용자가 일부러 일본어 가로만 원하면 다시 고르면 되고, 이후에는 바꾸지 않는다).
// - "jpn_vert"·"eng"·"chi_sim"·"kor": 기본값과 다른, 분명히 사용자가 고른 값이므로 그대로 둔다.
// 다른 설정·모델 캐시(Cache API)는 건드리지 않는다. 0.2.0부터는 사용자가 고르면 ocrLangOrigin: "user"를 함께 저장한다.
const migration = (async () => {
  try {
    const stored = await chrome.storage.local.get({ settingsVersion: 0, ocrLang: null, ocrLangOrigin: null });
    if (stored.settingsVersion >= SETTINGS_VERSION) return;
    const update = { settingsVersion: SETTINGS_VERSION };
    if (stored.ocrLang === "jpn" && stored.ocrLangOrigin !== "user") update.ocrLang = "auto";
    await chrome.storage.local.set(update);
  } catch { /* 저장소를 못 쓰면 기본값으로 동작 */ }
})();

async function loadSettings() {
  await migration;
  const stored = await chrome.storage.local.get(DEFAULTS);
  return {
    target: TARGETS.includes(stored.target) ? stored.target : "ko",
    source: SOURCES.includes(stored.source) ? stored.source : stored.source === "zh-Hant" ? "zh" : "auto",
    images: true, // 그림 속 글자 번역은 항상 켬(예전에 끈 값이 남아 있어도 다시 켤 화면이 없으므로 따르지 않는다)
    pageText: stored.pageText === true,
    ocrLang: OCR_LANGS.includes(stored.ocrLang) ? stored.ocrLang : "auto",
    automaticEnabled: stored.automaticEnabled === true,
    fontStyle: FONT_STYLES.includes(stored.fontStyle) ? stored.fontStyle : "auto"
  };
}

// MARK: - 전역 자동 번역 권한·세대

function hasGlobalGrant() {
  return chrome.permissions.contains({ origins: [ALL_URLS] }).then((g) => g === true, () => false);
}

function originPermitted(origin) {
  return chrome.permissions.contains({ origins: [`${origin}/*`] }).then((g) => g === true, () => false);
}

const control = { epoch: Date.now(), armed: true, chain: Promise.resolve() };

function serially(task) {
  const run = control.chain.then(task);
  control.chain = run.catch(() => {});
  return run;
}

function nextEpoch() {
  control.epoch = Math.max(Date.now(), control.epoch + 1);
  return control.epoch;
}

async function autoStillAllowed(epoch, origin = null) {
  if (epoch !== control.epoch) return null;
  const settings = await loadSettings();
  if (!settings.automaticEnabled) return null;
  if (!(await hasGlobalGrant())) {
    if (control.armed && epoch === control.epoch) globalStop().catch(() => {});
    return null;
  }
  if (origin && !(await originPermitted(origin))) return null;
  return epoch === control.epoch ? settings : null;
}

// MARK: - 숨은 엔진 문서(engine.html, offscreen 문서) 연결
// 번역·OCR·모델 내려받기는 화면에 보이지 않는 offscreen 문서 하나(프로필당 하나)에서 돈다. 배경은 번역·OCR·상태·내려받기
// 요청 직전에 그 문서가 있는지 확인하고(runtime.getContexts, 정확한 문서 주소) 없으면 만든다. 만드는 중에는 같은 생성 작업
// 하나만 기다려 두 번 만들지 않는다. offscreen 문서는 runtime API만 쓸 수 있으므로 설정·탭·권한·저장소는 배경이 맡고,
// 문서는 "engine" 포트로 요청을 받아 결과만 돌려준다. offscreen을 지원하지 않는 브라우저에서는 보이는 창으로 대신하지 않고
// 업데이트를 안내한다.

const ENGINE_PATH = "engine.html";
const ENGINE_URL = chrome.runtime.getURL(ENGINE_PATH);
const POPUP_URL = chrome.runtime.getURL("popup.html");
// 엔진이 이 시간 동안 살아 있다는 신호(alive, 5초 간격 + 실제 진행 때)를 보내지 않으면 실패 처리한다.
const ENGINE_IDLE_TIMEOUT = 150000;
const ENGINE_MAX_TIMEOUT = 20 * 60 * 1000;  // 요청 하나의 절대 상한(느린 CPU에서 큰 묶음도 진행 중이면 기다린다)
const ENGINE_MAX_PENDING = 48;
const ENGINE_CONNECT_TIMEOUT = 20000;       // 문서를 만들거나 깨운 뒤 포트가 연결되기를 기다리는 시간
const UNSUPPORTED_MESSAGE = "이 브라우저 버전에서는 바로보기를 쓸 수 없어요. 브라우저를 최신 버전으로 업데이트해 주세요.";

let engine = null; // { port, pending: Map(id → entry), closed } — 검증을 마친 현재 엔진 포트 하나
const engineWaiters = new Set(); // ensureEngine이 포트 연결을 기다리는 중
const tabRequests = new Map(); // tabId → Map(id → kind)
let engineSeq = 0;
let creatingEngine = null; // 진행 중인 offscreen 문서 생성(중복 생성 잠금)

function nextRequestId() {
  engineSeq = (engineSeq + 1) % 1000000000;
  return `e${Date.now().toString(36)}-${engineSeq}`;
}

function offscreenSupported() {
  return !!(chrome.offscreen && typeof chrome.offscreen.createDocument === "function" &&
            typeof chrome.runtime.getContexts === "function");
}

function engineContexts() {
  return chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"], documentUrls: [ENGINE_URL] });
}

async function ensureEngineDocument() {
  if (!offscreenSupported()) throw codedError("unsupported_browser", UNSUPPORTED_MESSAGE);
  if ((await engineContexts()).length) return;
  if (!creatingEngine) {
    creatingEngine = chrome.offscreen.createDocument({
      url: ENGINE_PATH,
      // WORKERS: 번역 모델·OCR·내려받기 전용 Worker. BLOBS: 캡처 이미지(data URL → Blob → ImageBitmap)와 OCR 입력 처리.
      reasons: ["WORKERS", "BLOBS"],
      justification: "이 PC 안에서 이미지 글자 인식·번역 Worker를 실행하고 번역 모델 파일을 받아 보관합니다."
    }).catch(async (error) => {
      // 프로필당 하나뿐이라, 다른 흐름이 방금 만들었다면 그 문서를 그대로 쓴다.
      if ((await engineContexts().catch(() => [])).length) return;
      throw codedError("engine_failed", `번역 준비를 시작하지 못했어요. 브라우저를 다시 시작한 뒤 시도해 주세요. (${(error && error.message) || error})`);
    }).finally(() => { creatingEngine = null; });
  }
  await creatingEngine;
}

/** 엔진 포트를 돌려준다. 문서가 없으면 만들고, 문서는 있는데 포트가 없으면(배경 재시작) 다시 연결하라고 깨운다. */
async function ensureEngine() {
  if (engine) return engine;
  await ensureEngineDocument();
  if (engine) return engine;
  return new Promise((resolve, reject) => {
    const waiter = { resolve, reject, timer: 0 };
    waiter.timer = setTimeout(() => {
      engineWaiters.delete(waiter);
      // 응답하지 않는 문서는 닫아 두고 다음 요청 때 새로 만든다(보이는 창으로 대신하지 않음).
      if (!engine) chrome.offscreen.closeDocument().catch(() => {});
      reject(codedError("engine_not_ready", "번역 준비가 응답하지 않아요. 잠시 뒤 다시 시도해 주세요."));
    }, ENGINE_CONNECT_TIMEOUT);
    engineWaiters.add(waiter);
    chrome.runtime.sendMessage({ target: "engine", cmd: "connect" }).catch(() => {});
  });
}

function trackTab(tabId, id, kind) {
  if (!Number.isInteger(tabId)) return;
  if (!tabRequests.has(tabId)) tabRequests.set(tabId, new Map());
  tabRequests.get(tabId).set(id, kind);
}

function untrackTab(tabId, id) {
  const map = tabRequests.get(tabId);
  if (!map) return;
  map.delete(id);
  if (!map.size) tabRequests.delete(tabId);
}

function settle(owner, id, entry) {
  clearTimeout(entry.idleTimer);
  clearTimeout(entry.maxTimer);
  owner.pending.delete(id);
  untrackTab(entry.tabId, id);
}

function failPending(owner, message) {
  for (const [id, entry] of [...owner.pending]) {
    settle(owner, id, entry);
    entry.reject(codedError("engine_not_ready", message));
  }
}

function armIdle(owner, id, entry) {
  clearTimeout(entry.idleTimer);
  entry.idleTimer = setTimeout(() => {
    settle(owner, id, entry);
    entry.reject(codedError("timeout", "번역이 응답하지 않아 멈췄어요. 다시 시도해 주세요."));
  }, ENGINE_IDLE_TIMEOUT);
}

/** kind: "text"|"ocr" — cancelTabEngineRequests가 특정 종류만 취소할 때 쓴다. */
async function engineRequest(tabId, type, payload, kind = "other") {
  const current = await ensureEngine();
  if (current.pending.size >= ENGINE_MAX_PENDING) {
    throw codedError("busy", "번역 대기열이 가득 찼어요. 잠시 뒤 다시 시도해 주세요.");
  }
  const id = nextRequestId();
  return new Promise((resolve, reject) => {
    const entry = { resolve, reject, tabId, kind, idleTimer: 0, maxTimer: 0 };
    current.pending.set(id, entry);
    trackTab(tabId, id, kind);
    armIdle(current, id, entry);
    entry.maxTimer = setTimeout(() => {
      settle(current, id, entry);
      try { current.port.postMessage({ id, type: "cancel" }); } catch { /* 연결 끊김 */ }
      reject(codedError("timeout", "번역이 너무 오래 걸려 중단했어요(20분). 범위를 줄여 다시 시도해 주세요."));
    }, ENGINE_MAX_TIMEOUT);
    try {
      current.port.postMessage({ id, type, payload });
    } catch {
      settle(current, id, entry);
      reject(codedError("engine_not_ready", "번역 준비와 연결하지 못했어요. 다시 시도해 주세요."));
    }
  });
}

/** 상태 확인·내려받기 시작/취소: 엔진 대기열을 거치지 않고 바로 답한다(짧은 고정 시간 초과). */
async function engineControl(type, payload = {}) {
  const current = await ensureEngine();
  const id = nextRequestId();
  return new Promise((resolve, reject) => {
    const entry = { resolve, reject, tabId: null, kind: "status", idleTimer: 0, maxTimer: 0 };
    current.pending.set(id, entry);
    entry.idleTimer = setTimeout(() => { settle(current, id, entry); reject(codedError("timeout", "")); }, 6000);
    try { current.port.postMessage({ id, type, payload }); } catch { settle(current, id, entry); reject(codedError("engine_not_ready", "")); }
  });
}

/** kind가 있으면(예: "ocr") 그 종류의 요청만 취소한다. kind가 없으면(이동·탭 닫힘 등) 이 탭의 모든 요청을 취소한다. */
function cancelTabEngineRequests(tabId, kind = null) {
  const map = tabRequests.get(tabId);
  if (!map) return;
  for (const [id, entryKind] of [...map]) {
    if (kind && entryKind !== kind) continue;
    const entry = engine ? engine.pending.get(id) : null;
    if (entry) {
      settle(engine, id, entry);
      entry.reject(codedError("cancelled", ""));
      try { engine.port.postMessage({ id, type: "cancel" }); } catch { /* 연결 끊김 */ }
    }
    map.delete(id);
  }
  if (!map.size) tabRequests.delete(tabId);
}

/** 이 확장의 offscreen 엔진 문서만 엔진 포트를 열 수 있다: 정확한 문서 주소, 탭 없음, 그리고 그 주소의 offscreen 문서가
 *  지금 실제로 있어야 한다. MessageSender.documentId는 선택 값이라, 주어졌으면 그 문서와 엄격히 대조하고(형식이 틀리면 거절)
 *  없으면 위 조건만으로 승인한다 — 그 주소(engine.html)는 offscreen으로만 만들고 팝업·도움말·웹 페이지와 겹치지 않으며,
 *  탭에서 연 engine.html은 sender.tab이 있어 걸러진다. */
async function isEngineSender(sender) {
  if (!sender || sender.id !== chrome.runtime.id || sender.tab || sender.url !== ENGINE_URL || !offscreenSupported()) return false;
  const docId = sender.documentId;
  if (docId !== undefined && (typeof docId !== "string" || !docId)) return false;
  try {
    return (await engineContexts()).some((context) => context.contextType === "OFFSCREEN_DOCUMENT" &&
      context.documentUrl === ENGINE_URL && (docId === undefined || context.documentId === docId));
  } catch { return false; }
}

// MARK: 모델 내려받기 진행 표시(엔진 문서 대신 저장) — 이 키 하나만, 정해진 모양으로만 읽고 쓴다(임의 키 쓰기 중계 없음).

const SESSION_KEY = "modelDownloadSession";
const SESSION_PHASES = new Set(["starting", "checking", "connecting", "running", "verifying", "finalizing"]);

function sanitizeSession(value) {
  if (!value || typeof value !== "object" || typeof value.owner !== "string" || !/^[A-Za-z0-9]{1,40}$/.test(value.owner)) return null;
  const num = (v) => (Number.isFinite(v) && v >= 0 ? v : 0);
  return {
    owner: value.owner, at: num(value.at), phase: SESSION_PHASES.has(value.phase) ? value.phase : "",
    done: num(value.done), file: typeof value.file === "string" ? value.file.slice(0, 200) : "",
    fileIndex: Number.isInteger(value.fileIndex) ? value.fileIndex : -1, fileCount: num(value.fileCount),
    fileDone: num(value.fileDone), fileSize: num(value.fileSize), skipped: num(value.skipped)
  };
}

function handleSession(owner, message) {
  if (message.op === "get" && typeof message.id === "string" && /^s\d{1,9}$/.test(message.id)) {
    chrome.storage.local.get(SESSION_KEY).then((stored) => stored[SESSION_KEY] || null, () => null).then((value) => {
      try { owner.port.postMessage({ type: "session", id: message.id, value: sanitizeSession(value) }); } catch { /* 연결 끊김 */ }
    });
  } else if (message.op === "set") {
    const value = sanitizeSession(message.value);
    if (value) chrome.storage.local.set({ [SESSION_KEY]: value }).catch(() => {});
  } else if (message.op === "remove") {
    chrome.storage.local.remove(SESSION_KEY).catch(() => {});
  }
}

function onEngineMessage(owner, message) {
  if (!message || typeof message !== "object") return;
  if (message.type === "alive" && Array.isArray(message.ids)) {
    for (const id of message.ids.slice(0, 256)) {
      const entry = typeof id === "string" ? owner.pending.get(id) : null;
      if (entry && entry.kind !== "status") armIdle(owner, id, entry);
    }
    return;
  }
  if (message.type === "session") { handleSession(owner, message); return; }
  if (typeof message.id !== "string") return;
  const entry = owner.pending.get(message.id);
  if (!entry) return;
  settle(owner, message.id, entry);
  if (message.ok === true) entry.resolve(message.result);
  else entry.reject(codedError(message.code || "error", message.message || ""));
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "engine") return;
  const candidate = { port, pending: new Map(), closed: false };
  const verified = isEngineSender(port.sender).then((ok) => ok && !candidate.closed);
  port.onDisconnect.addListener(() => {
    candidate.closed = true;
    if (engine === candidate) engine = null;
    // 끊긴 이 포트로 보낸 요청만 실패 처리한다.
    failPending(candidate, "번역 처리가 중간에 멈췄어요. 다시 시도해 주세요.");
  });
  // 메시지 처리기는 바로 단다(연결 직후 보낸 메시지를 놓치지 않게). 처리는 검증을 마친 현재 포트일 때만, 받은 순서대로 한다.
  port.onMessage.addListener((message) => {
    verified.then((ok) => { if (ok && engine === candidate) onEngineMessage(candidate, message); });
  });
  verified.then((ok) => {
    if (!ok) { try { port.disconnect(); } catch { /* 이미 끊김 */ } return; }
    const previous = engine;
    engine = candidate;
    if (previous && previous !== candidate) {
      try { previous.port.disconnect(); } catch { /* 이미 끊김 */ }
      failPending(previous, "번역 처리가 중간에 멈췄어요. 다시 시도해 주세요.");
    }
    for (const waiter of engineWaiters) { clearTimeout(waiter.timer); waiter.resolve(candidate); }
    engineWaiters.clear();
  });
});

async function engineStatusSnapshot() {
  try {
    const result = await engineControl("status");
    return { connected: true, ...result };
  } catch (error) {
    return { connected: false, code: error.code || "error", message: error.message || "" };
  }
}

// MARK: - 툴바 아이콘·배지(간단): 처리 중 "…", 번역 보기 "ON", 원문 보기 빈 배지

const tabProgress = new Map(); // tabId → { view, running }

async function updateTabIcon(tabId) {
  const info = tabProgress.get(tabId) || { view: "original", running: false };
  if (typeof chrome.action?.setBadgeText !== "function") return;
  const text = info.running ? "…" : (info.view === "translated" ? "ON" : "");
  try {
    await chrome.action.setBadgeText({ tabId, text });
    await chrome.action.setBadgeBackgroundColor({ tabId, color: "#0A84FF" });
    await chrome.action.setTitle({ tabId, title: info.running ? "바로보기 웹 번역 — 번역 중…" : "바로보기 웹 번역" });
  } catch { /* 탭이 닫혔을 수 있음 */ }
}

function handleProgress(message, sender) {
  const tabId = sender.tab?.id;
  if (!Number.isInteger(tabId)) return;
  tabProgress.set(tabId, { view: message.view === "original" ? "original" : "translated", running: message.running === true });
  updateTabIcon(tabId).catch(() => {});
}

// MARK: - 보이는 탭 캡처(메모리에만 잠깐 보관, 탭당 최신 1장)

const captures = new Map(); // tabId → { id, dataUrl, url, time }
let lastCaptureAt = 0;
let captureQueue = Promise.resolve();
const captureTickets = new Map();

function dropCapture(tabId) {
  captures.delete(tabId);
  captureTickets.set(tabId, (captureTickets.get(tabId) || 0) + 1);
}

function captureErrorCode(error) {
  const text = String((error && error.message) || error || "");
  if (/MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND|quota/i.test(text)) return "capture_rate_limited";
  if (/<all_urls>|activeTab|permission|Cannot access contents/i.test(text)) return "capture_denied";
  if (/No (tab|window) with id/i.test(text)) return "stale";
  return "capture_failed";
}

const CAPTURE_MESSAGES = {
  capture_denied: "이미지 번역에는 화면 캡처 권한이 필요합니다. 툴바의 바로보기 아이콘에서 '번역'을 눌러 주세요.",
  capture_rate_limited: "화면 캡처 요청이 몰려 이번에는 이미지를 확인하지 못했습니다. 잠시 뒤 다시 시도하세요.",
  capture_failed: "화면을 캡처하지 못해 이미지 글자를 번역하지 못했습니다.",
  stale: ""
};

async function assertCaptureTab(tab) {
  let now;
  try { now = await chrome.tabs.get(tab.id); } catch { throw codedError("stale", ""); }
  if (!now || now.windowId !== tab.windowId || now.url !== tab.url) throw codedError("stale", "");
  if (!now.active) throw codedError("tab_hidden", "보이는 탭이 아니어서 이미지를 캡처하지 않았습니다.");
}

function captureVisible(tab, epoch) {
  const ticket = captureTickets.get(tab.id) || 0;
  const run = captureQueue.then(() => captureNow(tab, epoch, ticket));
  captureQueue = run.catch(() => {});
  return run;
}

async function captureNow(tab, epoch, ticket) {
  if (!originOf(tab.url)) throw codedError("restricted_page", "이 페이지는 캡처하지 않습니다.");
  const cancelled = () => epoch !== control.epoch || (captureTickets.get(tab.id) || 0) !== ticket;
  if (cancelled()) throw codedError("cancelled", "");
  const wait = lastCaptureAt + CAPTURE_MIN_INTERVAL - Date.now();
  if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
  if (cancelled()) throw codedError("cancelled", "");
  await assertCaptureTab(tab);
  if (cancelled()) throw codedError("cancelled", "");
  lastCaptureAt = Date.now();
  let dataUrl;
  try {
    let timer = 0;
    dataUrl = await Promise.race([
      chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 90 }),
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error("capture timeout")), CAPTURE_CALL_TIMEOUT); })
    ]).finally(() => clearTimeout(timer));
  } catch (error) {
    const code = captureErrorCode(error);
    throw codedError(code, CAPTURE_MESSAGES[code]);
  }
  await assertCaptureTab(tab).catch(() => { throw codedError("stale", ""); });
  if (cancelled()) throw codedError("cancelled", "");
  if (typeof dataUrl !== "string" || !/^data:image\/(png|jpeg);base64,/.test(dataUrl)) throw codedError("capture_failed", "캡처에 실패했습니다.");
  if (dataUrl.length > 15 * 1024 * 1024) throw codedError("image_too_large", "캡처 이미지가 너무 큽니다. 창을 줄여 주세요.");
  const id = nextRequestId();
  captures.set(tab.id, { id, dataUrl, url: tab.url, time: Date.now() });
  return id;
}

function takeCapture(tabId, id) {
  const entry = captures.get(tabId);
  captures.delete(tabId);
  if (!entry || entry.id !== id || Date.now() - entry.time > CAPTURE_TTL) return null;
  return entry.dataUrl;
}

// MARK: - 응답 검증(엔진·내용 스크립트 모두 신뢰하지 않고 모양만 통과시킨다)

function validTexts(texts) {
  if (!Array.isArray(texts) || texts.length === 0 || texts.length > LIMITS.texts) return false;
  let total = 0;
  for (const text of texts) {
    if (typeof text !== "string" || text.length > LIMITS.textLength) return false;
    total += text.length;
  }
  return total <= LIMITS.chars;
}

function validRegions(regions) {
  return Array.isArray(regions) && regions.length > 0 && regions.length <= LIMITS.regions && regions.every((r) =>
    r && typeof r.k === "string" && /^[A-Za-z0-9_-]{1,32}$/.test(r.k) &&
    ["x", "y", "w", "h"].every((key) => Number.isFinite(r[key])) && r.w >= 1 && r.h >= 1);
}

const LANG_CODE = /^[A-Za-z]{2,8}(-[A-Za-z0-9]{2,8}){0,2}$/;

function sanitizeLangs(langs, expectedLength) {
  if (!Array.isArray(langs) || langs.length !== expectedLength) return null;
  return langs.map((lang) => {
    if (lang === null) return null;
    if (lang === "unknown") return "unknown";
    return typeof lang === "string" && LANG_CODE.test(lang) ? lang : null;
  });
}

const GLYPH_COORD_TOLERANCE = 0.01;
function clampGlyphCoord(n) {
  if (n < 0) return n >= -GLYPH_COORD_TOLERANCE ? 0 : null;
  if (n > 1) return n <= 1 + GLYPH_COORD_TOLERANCE ? 1 : null;
  return n;
}

function sanitizeGlyphs(g, remainingBudget, gl) {
  if (!Array.isArray(g) || remainingBudget <= 0) return { boxes: [], letters: "" };
  const flags = typeof gl === "string" && gl.length === g.length && /^[01]*$/.test(gl) ? gl : null;
  const result = [];
  let letters = "";
  for (let index = 0; index < g.length; index += 1) {
    const entry = g[index];
    if (result.length >= LIMITS.glyphsPerItem || result.length >= remainingBudget) break;
    if (!Array.isArray(entry) || entry.length !== 4 || !entry.every((n) => Number.isFinite(n))) continue;
    const x = clampGlyphCoord(entry[0]), y = clampGlyphCoord(entry[1]);
    const w = clampGlyphCoord(entry[2]), h = clampGlyphCoord(entry[3]);
    if (x === null || y === null || w === null || h === null || w <= 0 || h <= 0) continue;
    result.push([x, y, w, h]);
    if (flags) letters += flags[index];
  }
  return { boxes: result, letters };
}

function sanitizeImages(images) {
  if (!Array.isArray(images)) return [];
  const hex = /^#[0-9A-Fa-f]{6}$/;
  let glyphBudget = LIMITS.glyphsTotal;
  return images.slice(0, LIMITS.regions).map((image) => ({
    k: typeof image?.k === "string" ? image.k : "",
    items: (Array.isArray(image?.items) ? image.items : []).filter((item) =>
      item && typeof item.t === "string" &&
      ["x", "y", "w", "h"].every((key) => Number.isFinite(item[key]) && item[key] >= -0.5 && item[key] <= 1.5)
    ).map((item) => {
      const { boxes: g, letters: gl } = sanitizeGlyphs(item.g, glyphBudget, item.gl);
      glyphBudget -= g.length;
      return {
        x: item.x, y: item.y, w: item.w, h: item.h, t: item.t.length <= LIMITS.textLength ? item.t : "",
        bg: hex.test(item.bg) ? item.bg : "#FFFFFF",
        ...(typeof item.o === "string" ? { o: item.o.slice(0, 700) } : {}),
        ...(item.v === 1 || item.v === 0 ? { v: item.v } : {}),
        // 문단별 원문 언어(sl: 번역에 쓴 판별 결과, lh: OCR 문자 종류에서 온 힌트). 형식만 통과시킨다.
        ...(typeof item.sl === "string" && (item.sl === "unknown" || LANG_CODE.test(item.sl)) ? { sl: item.sl } : {}),
        ...(typeof item.lh === "string" && LANG_CODE.test(item.lh) ? { lh: item.lh } : {}),
        ...(g.length ? { g } : {}),
        ...(g.length && gl.length === g.length ? { gl } : {})
      };
    }),
    langs: typeof image?.langs === "object" && image.langs ? image.langs : {}
  }));
}

function sanitizeWarning(warning) { return typeof warning === "string" ? warning.slice(0, 300) : ""; }

// MARK: - 내용 스크립트 요청 처리

async function handleContent(message, sender) {
  const tab = sender.tab;
  if (message.cmd !== "cancel" && !originOf(sender.url || tab.url)) {
    throw codedError("restricted_page", "이 페이지는 번역하지 않습니다.");
  }
  const epoch = control.epoch;
  switch (message.cmd) {
    case "translate": {
      if (!TARGETS.includes(message.target) || !SOURCES.includes(message.source) || !validTexts(message.texts)) {
        throw codedError("bad_request", "잘못된 번역 요청입니다.");
      }
      const hint = typeof message.hint === "string" && LANG_CODE.test(message.hint) ? message.hint : null;
      const result = await engineRequest(tab.id,
        "translate", { texts: message.texts, target: message.target, source: message.source, hint }, "text");
      if (epoch !== control.epoch) throw codedError("cancelled", "");
      const texts = Array.isArray(result.texts) && result.texts.length === message.texts.length
        ? result.texts.map((t) => (typeof t === "string" ? t : null)) : null;
      if (!texts) throw codedError("bad_response", "번역 엔진 응답 형식이 올바르지 않습니다.");
      return { ok: true, texts, missing: Array.isArray(result.missing) ? result.missing.filter((m) => typeof m === "string") : [],
               langs: sanitizeLangs(result.langs, texts.length), warning: sanitizeWarning(result.warning) };
    }
    case "capture": {
      const captureId = await captureVisible(tab, epoch);
      if (epoch !== control.epoch) { captures.delete(tab.id); throw codedError("cancelled", ""); }
      return { ok: true, captureId };
    }
    case "ocr": {
      const viewport = message.viewport;
      if (!TARGETS.includes(message.target) || !SOURCES.includes(message.source) || !validRegions(message.regions) ||
          !OCR_LANGS.includes(message.ocrLang) || !viewport || !Number.isFinite(viewport.w) || !Number.isFinite(viewport.h)) {
        throw codedError("bad_request", "잘못된 이미지 요청입니다.");
      }
      const dataUrl = takeCapture(tab.id, message.captureId);
      if (!dataUrl) throw codedError("stale", "");
      // hint: 페이지 lang 속성(한자만 있는 문단의 일본어/중국어 판단에만 보조로 쓰임).
      const hint = typeof message.hint === "string" && LANG_CODE.test(message.hint) ? message.hint : null;
      const result = await engineRequest(tab.id, "ocr",
        { dataUrl, viewport: { w: viewport.w, h: viewport.h }, regions: message.regions, target: message.target, source: message.source,
          ocrLang: message.ocrLang, hint },
        "ocr");
      if (epoch !== control.epoch) throw codedError("cancelled", "");
      return { ok: true, images: sanitizeImages(result.images),
               missing: Array.isArray(result.missing) ? result.missing.filter((m) => typeof m === "string") : [],
               warning: sanitizeWarning(result.warning) };
    }
    case "cancel": {
      dropCapture(tab.id);
      cancelTabEngineRequests(tab.id, message.kind === "ocr" || message.kind === "text" ? message.kind : null);
      return { ok: true };
    }
    default:
      throw codedError("bad_request", "알 수 없는 요청입니다.");
  }
}

// MARK: - 내용 스크립트 주입과 전달

async function injectContent(tabId, origin) {
  let current = null;
  try { current = originOf((await chrome.tabs.get(tabId)).url); } catch { current = null; }
  if (!current || current !== origin) throw codedError("restricted_page", "이 페이지는 브라우저 정책상 확장이 접근할 수 없습니다.");
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  } catch {
    throw codedError("restricted_page", "이 페이지는 브라우저 정책상 확장이 접근할 수 없습니다.");
  }
}

async function sendToTab(tabId, message) {
  let timer = 0;
  try {
    return await Promise.race([
      Promise.resolve(chrome.tabs.sendMessage(tabId, message)),
      new Promise((resolve) => { timer = setTimeout(() => resolve(null), TAB_MESSAGE_TIMEOUT); })
    ]);
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function sendIfCurrent(tabId, epoch, message) {
  if (epoch !== control.epoch) return Promise.resolve(null);
  return sendToTab(tabId, message);
}

function configureMessage(settings, epoch, extra = {}) {
  return { cmd: "configure", epoch, auto: settings.automaticEnabled === true, target: settings.target, source: settings.source,
           images: settings.images !== false, pageText: settings.pageText === true, ocrLang: settings.ocrLang,
           fontStyle: settings.fontStyle, ...extra };
}

async function queryAllTabs() {
  try { return (await chrome.tabs.query({})).filter((tab) => Number.isInteger(tab.id)); } catch { return []; }
}

async function applyAutoToTab(tabId, epoch) {
  let origin = null;
  try { origin = originOf((await chrome.tabs.get(tabId)).url); } catch { return null; }
  if (!origin || !(await autoStillAllowed(epoch, origin))) return null;
  const present = await sendToTab(tabId, { cmd: "state" });
  if (!present) {
    try { await injectContent(tabId, origin); } catch { return null; }
  }
  const settings = await autoStillAllowed(epoch, origin);
  if (!settings) return null;
  return sendIfCurrent(tabId, epoch, configureMessage(settings, epoch));
}

async function configureAllTabs(epoch, exceptTabId = null) {
  const tabs = await queryAllTabs();
  await Promise.all(tabs.filter((tab) => tab.id !== exceptTabId).map((tab) => applyAutoToTab(tab.id, epoch)));
}

function globalStop() {
  const epoch = nextEpoch();
  control.armed = false;
  return serially(async () => {
    await chrome.storage.local.set({ automaticEnabled: false }).catch(() => {});
    const tabs = await queryAllTabs();
    const pages = new Map();
    await Promise.all(tabs.map(async (tab) => {
      captures.delete(tab.id);
      cancelTabEngineRequests(tab.id);
      pages.set(tab.id, await sendToTab(tab.id, { cmd: "toggleOriginal", epoch }));
    }));
    captures.clear();
    return { epoch, pages };
  });
}

async function reconcile() {
  const epoch = control.epoch;
  const verdict = await serially(async () => {
    const settings = await loadSettings();
    if (!settings.automaticEnabled) { control.armed = false; return "off"; }
    const ok = await hasGlobalGrant();
    if (epoch !== control.epoch) return "off";
    if (ok) { control.armed = true; return "on"; }
    return "stop";
  });
  if (verdict === "stop") await globalStop();
  return verdict === "on";
}

async function reconfigure(tabId, origin) {
  const epoch = control.epoch;
  const latest = await loadSettings();
  const global = latest.automaticEnabled ? await autoStillAllowed(epoch) : null;
  let page = null;
  if (tabId !== null && origin) {
    const tabAuto = global !== null && (await originPermitted(origin));
    page = await sendIfCurrent(tabId, epoch, configureMessage({ ...latest, automaticEnabled: tabAuto }, epoch));
  }
  if (global && epoch === control.epoch) configureAllTabs(epoch, tabId).catch(() => {});
  return page;
}

// MARK: - 팝업 요청 처리

async function handlePopup(message, receivedEpoch = control.epoch, stopping = null) {
  const settings = await loadSettings();
  const tabId = Number.isInteger(message.tabId) ? message.tabId : null;
  let origin = null;
  if (tabId !== null) {
    try { origin = originOf((await chrome.tabs.get(tabId)).url); } catch { origin = null; }
  }
  switch (message.cmd) {
    case "popupState": {
      await reconcile();
      const grant = await hasGlobalGrant();
      const page = tabId !== null && origin ? await sendToTab(tabId, { cmd: "state" }) : null;
      const status = await engineStatusSnapshot();
      return { ok: true, settings: await loadSettings(), origin, page, grant, engine: status };
    }
    case "pageProgress": {
      const page = tabId !== null && origin ? await sendToTab(tabId, { cmd: "state" }) : null;
      return { ok: true, page };
    }
    case "engineStatus":
      return { ok: true, engine: await engineStatusSnapshot() };
    case "setTarget": {
      if (!TARGETS.includes(message.target)) throw codedError("bad_request", "지원하지 않는 언어입니다.");
      await chrome.storage.local.set({ target: message.target });
      return { ok: true, page: await reconfigure(tabId, origin) };
    }
    case "setSource": {
      if (!SOURCES.includes(message.source)) throw codedError("bad_request", "지원하지 않는 원문 언어입니다.");
      await chrome.storage.local.set({ source: message.source });
      return { ok: true, page: await reconfigure(tabId, origin) };
    }
    case "setPageText": {
      await chrome.storage.local.set({ pageText: message.pageText === true });
      return { ok: true, page: await reconfigure(tabId, origin) };
    }
    case "setOcrLang": {
      if (!OCR_LANGS.includes(message.ocrLang)) throw codedError("bad_request", "지원하지 않는 OCR 언어입니다.");
      await chrome.storage.local.set({ ocrLang: message.ocrLang, ocrLangOrigin: "user" });
      return { ok: true, page: await reconfigure(tabId, origin) };
    }
    case "prepareModel": {
      // 팝업이 사용자 클릭 안에서 모델 주소 접근을 요청해 허용받은 뒤에만 온다. 실제로 허용됐는지 여기서 다시 확인한다.
      if (!(await chrome.permissions.contains({ origins: DOWNLOAD_ORIGINS }).catch(() => false))) {
        throw codedError("permission_denied", "파일을 받으려면 접근 허용이 필요해요. '번역 준비하기'를 다시 누르고 허용해 주세요.");
      }
      return { ok: true, engine: { connected: true, ...(await engineControl("prepare")) } };
    }
    case "cancelPrepare":
      return { ok: true, engine: { connected: true, ...(await engineControl("cancelPrepare")) } };
    case "setFontStyle": {
      if (!FONT_STYLES.includes(message.fontStyle)) throw codedError("bad_request", "지원하지 않는 글꼴입니다.");
      await chrome.storage.local.set({ fontStyle: message.fontStyle });
      return { ok: true, page: await reconfigure(tabId, origin) };
    }
    case "translateNow": {
      if (tabId === null) throw codedError("bad_request", "탭을 찾을 수 없습니다.");
      // 받은 순간의 세대로 판단한다: 그 뒤 처리된 원문 보기(globalStop)는 이 요청을 취소한다(앞선 await 순서와 무관).
      let epoch = receivedEpoch;
      const wantAuto = message.automatic === true;
      const outcome = await serially(async () => {
        if (epoch !== control.epoch) return "superseded";
        const granted = wantAuto && (await hasGlobalGrant());
        if (epoch !== control.epoch) return "superseded";
        if (granted) { control.armed = true; await chrome.storage.local.set({ automaticEnabled: true }); return "auto"; }
        if (message.tabOnly === true) return "manual";
        return (await loadSettings()).automaticEnabled ? "stop" : "manual";
      });
      if (outcome === "superseded") return { ok: true, page: null, automatic: false, superseded: true };
      const automatic = outcome === "auto";
      if (outcome === "stop") epoch = (await globalStop()).epoch;
      if (!origin) {
        if (automatic && epoch === control.epoch) configureAllTabs(epoch, tabId).catch(() => {});
        return { ok: true, page: null, automatic, restricted: true };
      }
      // 이미 번역 중이면(그리고 팝업을 열 때는 이미 번역 보기여도) 다시 번역하지 않는다(같은 계산을 두 번 하지 않음).
      const present = await sendToTab(tabId, { cmd: "state" });
      if (present && (present.running === true || (present.view === "translated" && message.trigger !== "button"))) {
        if (automatic && epoch === control.epoch) configureAllTabs(epoch, tabId).catch(() => {});
        return { ok: true, page: present, automatic, already: true };
      }
      try {
        await injectContent(tabId, origin);
      } catch (error) {
        if (automatic && epoch === control.epoch) configureAllTabs(epoch, tabId).catch(() => {});
        return { ok: true, page: null, automatic, restricted: true, message: error.message };
      }
      const latest = await loadSettings();
      const tabAuto = automatic && latest.automaticEnabled && (await originPermitted(origin));
      if (epoch !== control.epoch) return { ok: true, page: null, automatic: false, superseded: true };
      const next = { ...latest, automaticEnabled: tabAuto };
      const page = await sendIfCurrent(tabId, epoch, configureMessage(next, epoch, {
        translateNow: true, trigger: message.trigger === "button" ? "button" : "open",
        ...(Number.isFinite(message.clickedAt) ? { clickedAt: message.clickedAt } : {}) }));
      if (automatic && epoch === control.epoch) configureAllTabs(epoch, tabId).catch(() => {});
      return { ok: true, page, automatic };
    }
    case "toggleOriginal": {
      const { pages } = await (stopping || globalStop());
      return { ok: true, page: tabId !== null ? pages.get(tabId) ?? null : null };
    }
    default:
      throw codedError("bad_request", "알 수 없는 요청입니다.");
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object" || typeof message.cmd !== "string") return false;
  if (sender.id !== chrome.runtime.id) return false;
  const reply = (promise) => {
    promise.then(sendResponse, (error) => sendResponse({ ok: false, code: error.code || "error", message: error.message || "" }));
    return true;
  };
  // 설정·번역 시작·원문 보기·모델 준비 같은 관리 명령은 탭이 없는 팝업 문서(정확한 주소)에서만 받는다. 엔진 문서는 포트로만
  // 말하고, 웹 페이지의 내용 스크립트(sender.url이 웹 주소)는 번역·캡처·OCR·취소·진행 알림만 보낼 수 있다.
  if (!sender.tab && sender.url === POPUP_URL) {
    // 원문 보기는 받는 즉시 세대를 올리고(globalStop), 번역 요청은 받은 순간의 세대로 판단한다: 받은 순서대로 이긴다.
    const stopping = message.cmd === "toggleOriginal" ? globalStop() : null;
    stopping?.catch(() => {});
    return reply(handlePopup(message, control.epoch, stopping));
  }
  if (sender.tab && typeof sender.url === "string" && originOf(sender.url)) {
    if (typeof sender.frameId === "number" && sender.frameId !== 0) return false;
    if (message.cmd === "progress") { handleProgress(message, sender); return false; }
    return reply(handleContent(message, sender));
  }
  return false;
});

// MARK: - 탭 수명

chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === "loading") {
    dropCapture(tabId);
    cancelTabEngineRequests(tabId);
    tabProgress.delete(tabId);
    updateTabIcon(tabId).catch(() => {});
  }
  if (info.status !== "complete" || !tab?.url || !originOf(tab.url)) return;
  applyAutoToTab(tabId, control.epoch).catch(() => {});
});

chrome.tabs.onRemoved.addListener((tabId) => {
  captures.delete(tabId);
  captureTickets.delete(tabId);
  cancelTabEngineRequests(tabId);
  tabProgress.delete(tabId);
  if (!control.armed) return;
  setTimeout(() => {
    if (!control.armed) return;
    chrome.tabs.query({}).then((tabs) => {
      if (control.armed && tabs.length === 0) globalStop().catch(() => {});
    }).catch(() => {});
  }, 0);
});

chrome.tabs.onActivated.addListener(({ tabId }) => { applyAutoToTab(tabId, control.epoch).catch(() => {}); });

// 모델 주소 접근은 팝업의 '번역 준비하기' 클릭으로만 요청한다. 권한 확인 창 때문에 팝업이 먼저 닫혀도 허용되면 준비를 시작한다
// (팝업이 열려 있으면 팝업도 같은 요청을 보내지만, 엔진 문서는 이미 받는 중이면 다시 시작하지 않는다).
if (chrome.permissions?.onAdded) {
  chrome.permissions.onAdded.addListener((added) => {
    const origins = added?.origins || [];
    if (DOWNLOAD_ORIGINS.some((o) => origins.includes(o))) engineControl("prepare").catch(() => {});
  });
}

// 페이지 접근(모든 사이트 등)을 거두면 전역 자동 번역을 끈다. 모델 주소만 거둔 경우에는 끄지 않는다(모델 준비는 prepareModel의
// contains 확인이 막는다). 그때도 모든 사이트 접근이 실제로 남아 있는지는 contains로 다시 확인한다.
if (chrome.permissions?.onRemoved) {
  chrome.permissions.onRemoved.addListener((removed) => {
    const origins = removed?.origins || [];
    if (!origins.length) return;
    if (origins.every((o) => DOWNLOAD_ORIGINS.includes(o))) {
      hasGlobalGrant().then((ok) => { if (!ok && control.armed) globalStop().catch(() => {}); });
      return;
    }
    globalStop().catch(() => {});
  });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  const autoOff = changes.automaticEnabled && changes.automaticEnabled.newValue !== true;
  if (autoOff && control.armed) globalStop().catch(() => {});
});

chrome.runtime.onStartup?.addListener(async () => {
  if (!(await reconcile())) return;
  const epoch = control.epoch;
  let active = [];
  try { active = await chrome.tabs.query({ active: true }); } catch { active = []; }
  await Promise.all(active.filter((tab) => Number.isInteger(tab.id)).map((tab) => applyAutoToTab(tab.id, epoch)));
});

reconcile().catch(() => {});

// 설치·업데이트 때 창이나 탭을 열지 않는다. 처음 사용 안내와 모델 준비는 툴바 아이콘 팝업에서 한다.

(async () => {
  let tabs = [];
  try { tabs = await chrome.tabs.query({}); } catch { tabs = []; }
  await Promise.all(tabs.filter((tab) => Number.isInteger(tab.id)).map(async (tab) => {
    const page = await sendToTab(tab.id, { cmd: "state" });
    if (page && !tabProgress.has(tab.id)) {
      tabProgress.set(tab.id, { view: page.view === "original" ? "original" : "translated", running: page.running === true });
    }
    updateTabIcon(tab.id).catch(() => {});
  }));
})().catch(() => {});
