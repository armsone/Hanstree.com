"use strict";
// 바로보기 웹 번역 — 공통 로컬 번역 엔진 제어(숨은 엔진 문서 전용, Chrome·Whale 공통).
// - 다운로드: download-worker.js(전용 Worker)가 고정 파일만 받아 검증 후 Cache API에 둔다. 취소는 Worker terminate.
//   상태는 권한 요청 → 확인 → 연결 → 수신(실제 바이트) → 검증·저장 → 완료 표시로 나눠 알리고, 바이트가 끊기면 "응답 없음"을 표시한다.
//   이 문서(offscreen 엔진 문서)가 닫히면 Worker도 멈춘다. 내려받기 소유자는 Web Locks(navigator.locks) 독점 잠금 하나로 정한다:
//   엔진 문서가 다시 만들어지는 사이에도 두 곳에서 동시에 받지 않고, 문서가 닫히면 브라우저가 잠금을 풀어 주므로 하트비트 시간
//   추정이 필요 없다. 진행 표시(파일 이름·바이트 수만)는 1초에 한 번 이하로 저장한다. offscreen 문서는 runtime 외 확장 API를
//   쓸 수 없으므로 저장은 호스트(page.js)가 넘겨준 sessionStore(배경 포트 중계, 이 키 하나만)로 한다(모델 내용은 저장하지 않음).
// - 실행: model-worker.js(전용 module Worker)가 Transformers.js + ONNX Runtime Web(WASM, 단일 스레드)로 M2M100을 돌린다.
//   UI 스레드는 막히지 않고, 멈추면(토큰이 오래 나오지 않으면) Worker를 끝내고 새로 만들 수 있다.
// - 번역할 글자는 Worker 메시지로만 오가며 저장하지 않는다(이 문서 메모리 안의 짧은 결과 캐시만, 문서를 닫으면 사라짐).

const MODEL = globalThis.BAROBOGI_MODEL;
const MODEL_TOTAL = globalThis.BAROBOGI_MODEL_TOTAL;
const STALL_MS = 120000;       // 한 조각 번역 중 새 토큰이 이만큼 없으면 멈춘 것으로 보고 Worker를 다시 만든다
const LOAD_STALL_MS = 600000;  // 모델 불러오기(WASM 세션 생성) 중 진행 신호가 이만큼 없으면 실패로 본다
const MAX_CHUNK = 300;         // 한 번에 모델에 넣는 원문 글자 수 상한(문장 경계 우선)
const RESULT_CACHE_LIMIT = 2000;

const STALL_NOTICE_MS = 20000; // 이만큼 바이트가 오지 않으면 "네트워크 응답 없음"을 표시한다(다운로드 Worker는 60초에 끊는다)
const SESSION_WRITE_MS = 1000;              // 진행 표시 쓰기 간격 하한(저장소 이벤트 폭주 방지)
const DOWNLOAD_LOCK = "barobogi-model-download"; // Web Locks 이름: 이 확장 출처 안에서 내려받기 소유자는 하나
const LOCKS = typeof navigator !== "undefined" && navigator.locks && typeof navigator.locks.request === "function" ? navigator.locks : null;

const listeners = new Set();
const model = {
  cache: "unknown",   // unknown|checking|missing|partial|complete|error
  cachedBytes: 0,
  cachedFiles: 0,
  // idle|permission(브라우저 권한 요청 중)|starting|checking|connecting|running|verifying|finalizing|failed|cancelled|done
  download: "idle",
  downloadDone: 0,
  downloadError: "",
  downloadErrorCode: "",
  downloadFile: "",
  downloadFileIndex: -1,
  downloadFileCount: 0,
  downloadFileDone: 0,
  downloadFileSize: 0,
  downloadSkipped: 0,
  lastActivityAt: 0,
  stalled: false,
  interrupted: false, // 이전 내려받기가 엔진 문서가 닫히며(브라우저 종료 등) 끊겼음(다시 만든 뒤 저장소 확인으로 알게 됨)
  otherWindow: false, // 다른 엔진 문서가 지금 내려받기 잠금을 쥐고 있음
  foreign: null,      // 그 문서가 알린 진행(phase, done, file, fileIndex, fileCount, fileDone, fileSize, skipped)
  locksUnsupported: !LOCKS,
  runtime: "idle",    // idle|loading|ready|error
  runtimeError: "",
  loadFile: "",
  loadLoaded: null,
  loadTotal: null
};

function emit() { for (const fn of listeners) { try { fn(snapshot()); } catch { /* UI 오류 무시 */ } } }
function snapshot() { return { ...model, total: MODEL_TOTAL }; }
function onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }

// MARK: 캐시 상태(네트워크 요청 없음)

async function checkCache() {
  model.cache = "checking";
  emit();
  try {
    const cache = await caches.open(MODEL.cacheName);
    const ready = await cache.match(globalThis.BAROBOGI_MODEL_READY_URL);
    let bytes = 0, files = 0;
    for (const file of MODEL.files) {
      const url = globalThis.BAROBOGI_MODEL_URL(file.path);
      const [entry, mark] = await Promise.all([cache.match(url), cache.match(url + globalThis.BAROBOGI_VERIFIED_SUFFIX)]);
      if (entry && mark) { bytes += file.size; files += 1; }
    }
    model.cachedBytes = bytes;
    model.cachedFiles = files;
    model.cache = ready && bytes === MODEL_TOTAL ? "complete" : bytes > 0 ? "partial" : "missing";
  } catch (error) {
    model.cache = "error";
    model.downloadError = String((error && error.message) || error);
  }
  await readSession();
  emit();
  return model.cache;
}

// MARK: 진행 중 표시(배경이 modelDownloadSession 키 하나로 저장 — 끊긴 내려받기를 알리려고)와 내려받기 소유권(Web Locks)

const sessionOwner = `w${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
let ownsLock = false;    // 이 문서가 내려받기 소유자로 잠금을 쥐고 있음
let holdingLock = false; // 이 문서가 잠금을 쥐고 있음(소유자이거나 끊긴 표시 정리 중): 잠금은 독점이므로 그동안 다른 문서는 쥐지 않는다
let watching = false;
let lastSessionWrite = 0;
let sessionWriteTimer = 0;

// 진행 표시 저장소: 호스트가 useSessionStore로 넘긴다({ get(): Promise<값|null>, set(값), remove(): Promise }).
// 넘기기 전에는 아무것도 저장하지 않는다.
let sessionStore = { get: async () => null, set: () => {}, remove: async () => {} };
function useSessionStore(store) { sessionStore = store; }

async function getSession() {
  try { return (await sessionStore.get()) || null; } catch { return null; }
}

function foreignOf(stored) {
  if (!stored) return null;
  const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : null);
  return {
    phase: typeof stored.phase === "string" ? stored.phase : "", done: num(stored.done), file: typeof stored.file === "string" ? stored.file : "",
    fileIndex: Number.isInteger(stored.fileIndex) ? stored.fileIndex : -1, fileCount: num(stored.fileCount),
    fileDone: num(stored.fileDone), fileSize: num(stored.fileSize), skipped: num(stored.skipped)
  };
}

/** 다른 문서가 내려받는 중인지 실제 잠금 상태로 정한다. 잠금이 없는데 남은 표시는 그 문서가 닫혀 끊긴 것이다. */
async function readSession() {
  const stored = await getSession();
  if (holdingLock) { model.otherWindow = false; model.foreign = null; return; }
  if (!LOCKS) { model.otherWindow = false; model.foreign = null; return; }
  let held = false;
  try { held = (await LOCKS.query()).held.some((lock) => lock.name === DOWNLOAD_LOCK); } catch { held = false; }
  if (holdingLock) { model.otherWindow = false; model.foreign = null; return; }
  if (held) {
    model.otherWindow = true;
    if (stored && stored.owner !== sessionOwner) model.foreign = foreignOf(stored);
    watchForeign();
    return;
  }
  model.otherWindow = false;
  model.foreign = null;
  if (stored && stored.owner !== sessionOwner) clearStaleSession();
}

/** 잠금 없이 남은 다른 문서의 표시를 지운다. 잠금을 잠깐 쥐고(ifAvailable) 확인하므로, 그 사이 새 소유자가 생겼으면 건드리지 않는다. */
function clearStaleSession() {
  if (!LOCKS) return;
  LOCKS.request(DOWNLOAD_LOCK, { ifAvailable: true }, async (lock) => {
    if (!lock) return; // 누군가 잠금을 쥐고 있다: 살아 있는 내려받기일 수 있으므로 표시를 지우지 않는다
    holdingLock = true;
    try {
      const stored = await getSession();
      if (stored && stored.owner !== sessionOwner) {
        await Promise.resolve(sessionStore.remove()).catch(() => {});
        if (model.cache !== "complete") { model.interrupted = true; emit(); }
      }
    } finally { holdingLock = false; }
  }).catch(() => {});
}

/** 다른 문서가 잠금을 쥐고 있는 동안 기다렸다가(그 문서가 끝내거나 닫히면 브라우저가 잠금을 넘겨줌) 캐시를 다시 확인한다.
 *  주기적 확인·하트비트 없이 실제 잠금 해제로만 깨어난다. 확인은 잠금 안에서 해 다른 문서와 서로 깨우는 반복이 생기지 않게 한다. */
function watchForeign() {
  if (watching || !LOCKS || holdingLock) return;
  watching = true;
  LOCKS.request(DOWNLOAD_LOCK, async () => {
    holdingLock = true;
    try {
      const stored = await getSession();
      const stale = !!stored && stored.owner !== sessionOwner; // 정상 종료한 소유자는 표시를 지우고 잠금을 푼다
      if (stale) await Promise.resolve(sessionStore.remove()).catch(() => {});
      await checkCache();
      if (stale && model.cache !== "complete") { model.interrupted = true; emit(); }
    } finally { holdingLock = false; }
  }).catch(() => {}).finally(() => { watching = false; });
}

/** 소유자만 쓴다. 단계가 바뀔 때는 바로(force), 바이트 진행은 1초에 한 번 이하로. */
function writeSession(force = false) {
  if (!ownsLock) return;
  const now = Date.now();
  if (!force && now - lastSessionWrite < SESSION_WRITE_MS) {
    if (!sessionWriteTimer) sessionWriteTimer = setTimeout(() => { sessionWriteTimer = 0; writeSession(true); }, SESSION_WRITE_MS - (now - lastSessionWrite));
    return;
  }
  clearTimeout(sessionWriteTimer);
  sessionWriteTimer = 0;
  lastSessionWrite = now;
  try {
    sessionStore.set({
      owner: sessionOwner, at: now, phase: model.download, done: model.downloadDone, file: model.downloadFile,
      fileIndex: model.downloadFileIndex, fileCount: model.downloadFileCount, fileDone: model.downloadFileDone,
      fileSize: model.downloadFileSize, skipped: model.downloadSkipped
    });
  } catch { /* 저장하지 못해도 내려받기는 계속한다 */ }
}

function endSession() {
  clearTimeout(sessionWriteTimer);
  sessionWriteTimer = 0;
  return Promise.resolve(sessionStore.remove()).catch(() => {});
}
// 다른 문서가 잠금을 쥔 동안의 진행은 watchForeign이 잠금 해제를 기다렸다가 캐시를 다시 확인해 반영한다
// (offscreen 문서는 프로필당 하나라 보통은 이 문서 하나뿐이다).

async function deleteCache() {
  terminateModel("모델 캐시를 지웠습니다.");
  cancelDownload();
  await caches.delete(MODEL.cacheName).catch(() => false);
  model.download = "idle";
  model.downloadDone = 0;
  resetDownloadDetail();
  model.runtime = "idle";
  model.runtimeError = "";
  await checkCache();
}

// MARK: 다운로드

let downloadWorker = null;
let downloadPromise = null;
let downloadFinish = null;
let permissionTicket = 0;
let stallTimer = 0;

const BUSY_DOWNLOAD = new Set(["permission", "starting", "checking", "connecting", "running", "verifying", "finalizing"]);
function isDownloadBusy() { return BUSY_DOWNLOAD.has(model.download); }

function resetDownloadDetail() {
  model.downloadError = "";
  model.downloadErrorCode = "";
  model.downloadFile = "";
  model.downloadFileIndex = -1;
  model.downloadFileCount = MODEL.files.length;
  model.downloadFileDone = 0;
  model.downloadFileSize = 0;
  model.downloadSkipped = 0;
  model.stalled = false;
  model.interrupted = false;
}

/** 사용자 클릭 직후(비동기 권한 요청 전에) 동기로 부른다: 화면이 바로 "권한 요청 중"으로 바뀐다. 돌려준 표를 startDownload에 넘긴다. */
function beginPermissionRequest() {
  if (isDownloadBusy()) return 0;
  resetDownloadDetail();
  model.download = "permission";
  model.downloadDone = model.cachedBytes;
  emit();
  permissionTicket += 1;
  return permissionTicket;
}

/** 권한 요청을 기다리는 중 사용자가 취소하면 늦게 끝난 권한 응답으로 내려받기가 시작되지 않게 한다. */
function cancelPermissionRequest() {
  if (model.download !== "permission") return;
  permissionTicket += 1;
  model.download = "cancelled";
  model.downloadError = "권한 요청을 취소했습니다. 아직 아무것도 내려받지 않았습니다.";
  emit();
}

function armStallWatch() {
  clearInterval(stallTimer);
  stallTimer = setInterval(() => {
    if (!["connecting", "running"].includes(model.download)) { if (model.stalled) { model.stalled = false; emit(); } return; }
    const stalled = Date.now() - model.lastActivityAt > STALL_NOTICE_MS;
    if (stalled !== model.stalled) { model.stalled = stalled; emit(); }
  }, 1000);
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** 사용자 클릭에서 부른다(ticket: beginPermissionRequest가 준 값, 없으면 0). 이미 받은(검증된) 파일은 건너뛰고,
 *  중간에 끊긴 파일은 처음부터 다시 받는다. 언제나 끝나는 Promise("done"|"failed"|"cancelled"|"busy"|"stale")를 돌려준다.
 *  Web Locks 잠금을 ifAvailable로 잡은 문서만 받고, 끝나거나 취소되거나 문서가 닫힐 때까지 잠금을 쥔다. */
function startDownload(ticket = 0, { permissionGranted = null } = {}) {
  if (downloadPromise) return downloadPromise;
  if (ticket && ticket !== permissionTicket) return Promise.resolve("stale");
  if (model.download !== "permission" && isDownloadBusy()) return Promise.resolve("busy");
  resetDownloadDetail();
  model.downloadDone = model.cachedBytes;
  model.permissionGranted = permissionGranted;
  if (!LOCKS) {
    // 잠금 없이는 두 엔진 문서가 같은 캐시에 동시에 쓰는 것을 막을 수 없다: 경쟁 상태를 만들지 않고 분명히 알린다.
    model.download = "failed";
    model.downloadErrorCode = "locks_unsupported";
    model.downloadError = "이 브라우저 버전에서는 파일을 받을 수 없어요. 브라우저를 최신 버전으로 업데이트해 주세요.";
    emit();
    return Promise.resolve("failed");
  }
  model.download = "starting";
  model.lastActivityAt = Date.now();
  emit();
  downloadPromise = (async () => {
    for (let attempt = 0; ; attempt += 1) {
      let outcome;
      try {
        outcome = await LOCKS.request(DOWNLOAD_LOCK, { ifAvailable: true }, async (lock) => {
          if (!lock) return null;
          holdingLock = true;
          ownsLock = true;
          model.otherWindow = false;
          model.foreign = null;
          try { return await runDownload(); } finally { ownsLock = false; holdingLock = false; }
        });
      } catch (error) {
        model.download = "failed";
        model.downloadErrorCode = "lock";
        model.downloadError = `내려받기 잠금을 얻지 못했습니다: ${(error && error.message) || error}`;
        emit();
        return "failed";
      }
      if (outcome !== null) return outcome;
      // 잠금을 다른 문서가 쥐고 있다. 진행 표시가 있으면 실제 소유자다. 표시가 없으면 다른 문서가 잠깐 상태를 확인하는 중일 수
      // 있어 짧게 몇 번만 다시 시도한다(잠금은 계속 ifAvailable로만 요청한다).
      const stored = await getSession();
      if ((stored && stored.owner !== sessionOwner) || attempt >= 4 || model.download !== "starting") {
        if (model.download !== "starting") return model.download;
        model.download = "failed";
        model.downloadErrorCode = "other_window";
        model.downloadError = "이미 다른 곳에서 받는 중이에요. 끝나면 자동으로 확인합니다.";
        model.otherWindow = true;
        model.foreign = stored && stored.owner !== sessionOwner ? foreignOf(stored) : model.foreign;
        watchForeign();
        emit();
        return "failed";
      }
      await sleep(250);
    }
  })();
  const current = downloadPromise;
  current.finally(() => { if (downloadPromise === current) downloadPromise = null; }).catch(() => {});
  return current;
}

/** 잠금을 쥔 상태에서만 부른다. 다운로드 Worker가 끝나고 캐시 재확인까지 마친 뒤에 끝나는 Promise를 돌려준다(그동안 잠금 유지). */
function runDownload() {
  model.interrupted = false;
  return new Promise((resolve) => {
    let worker = null;
    let finished = false;
    const finish = (state, error = "", code = "") => {
      if (finished) return;
      finished = true;
      if (downloadWorker === worker) downloadWorker = null;
      downloadFinish = null;
      try { worker && worker.terminate(); } catch { /* 이미 끝남 */ }
      clearInterval(stallTimer);
      model.stalled = false;
      if (state === "done") {
        // 완료 표시를 실제로 다시 확인할 때까지 "완료 표시 저장·확인 중"(진행 중)으로 둔다. 그 사이 "일부만 저장됨"이나
        // 내려받기 버튼이 잠깐 보이지 않게 한다.
        model.download = "finalizing";
        model.downloadFile = "";
        emit();
        checkCache().catch(() => model.cache).then((cache) => {
          if (cache === "complete") {
            model.download = "done";
          } else {
            model.download = "failed";
            model.downloadErrorCode = "verify";
            model.downloadError = "모든 파일을 받았지만 저장소에서 완료 표시를 확인하지 못했습니다. '다시 시도'를 누르면 검증된 파일은 건너뜁니다.";
          }
          return endSession();
        }).then(() => { emit(); resolve(model.download); });
        return;
      }
      model.download = state;
      model.downloadError = error;
      model.downloadErrorCode = code;
      emit();
      endSession().then(() => checkCache()).then(() => resolve(model.download), () => resolve(model.download));
    };
    downloadFinish = finish;
    try {
      worker = new Worker(chrome.runtime.getURL("engine/download-worker.js"));
    } catch (error) {
      finish("failed", `다운로드 Worker를 만들지 못했습니다: ${(error && error.message) || error}`, "worker");
      return;
    }
    downloadWorker = worker;
    worker.onmessage = (event) => {
      const message = event.data || {};
      if (message.type === "phase") {
        model.lastActivityAt = Date.now();
        model.download = { checking: "checking", connecting: "connecting", downloading: "running", verifying: "verifying", finalizing: "finalizing" }[message.phase] || model.download;
        if (typeof message.file === "string") model.downloadFile = message.file;
        else if (message.phase === "finalizing") model.downloadFile = "";
        if (Number.isInteger(message.fileIndex)) model.downloadFileIndex = message.fileIndex;
        if (Number.isFinite(message.fileSize)) model.downloadFileSize = message.fileSize;
        if (Number.isFinite(message.done)) model.downloadDone = message.done;
        if (Number.isInteger(message.skipped)) model.downloadSkipped = message.skipped;
        if (message.phase === "connecting") model.downloadFileDone = 0;
        writeSession(true);
        emit();
      } else if (message.type === "progress") {
        model.lastActivityAt = Date.now();
        model.downloadDone = Number(message.done) || 0;
        model.downloadFile = message.file || model.downloadFile;
        if (Number.isInteger(message.fileIndex)) model.downloadFileIndex = message.fileIndex;
        model.downloadFileDone = Number(message.fileDone) || 0;
        model.downloadFileSize = Number(message.fileSize) || model.downloadFileSize;
        if (Number.isInteger(message.skipped)) model.downloadSkipped = message.skipped;
        model.stalled = false;
        writeSession();
        emit();
      } else if (message.type === "done") {
        model.downloadDone = MODEL_TOTAL;
        finish("done");
      } else if (message.type === "error") {
        finish("failed", String(message.message || "내려받지 못했습니다."), String(message.code || "error"));
      }
    };
    worker.onerror = (event) => { event.preventDefault?.(); finish("failed", event.message || "다운로드 Worker 오류", "worker"); };
    writeSession(true);
    armStallWatch();
    try {
      worker.postMessage({ type: "start" });
    } catch (error) {
      finish("failed", `다운로드 Worker를 시작하지 못했습니다: ${(error && error.message) || error}`, "worker");
    }
  });
}

function cancelDownload() {
  if (model.download === "permission") { cancelPermissionRequest(); return; }
  if (downloadFinish) downloadFinish("cancelled", "사용자가 취소했습니다. 다시 받으면 검증을 마친 파일은 건너뛰고, 받던 파일은 처음부터 다시 받습니다.", "cancelled");
}

// MARK: 모델 Worker

let modelWorker = null;
let loadPromise = null;
let jobSeq = 0;
const jobs = new Map(); // jobId → { resolve, reject, timer, onTokens }

function terminateModel(reason) {
  const worker = modelWorker;
  modelWorker = null;
  loadPromise = null;
  const pendingLoad = worker && worker._load;
  if (worker) { worker._load = null; worker.terminate(); }
  if (pendingLoad) pendingLoad({ type: "terminated", message: reason || "번역 Worker를 다시 시작했습니다." });
  for (const [id, job] of jobs) {
    clearTimeout(job.timer);
    job.reject(Object.assign(new Error(reason || "번역 Worker를 다시 시작했습니다."), { code: "engine_restarted" }));
    jobs.delete(id);
  }
  if (model.runtime !== "error") model.runtime = "idle";
  model.loadFile = "";
  model.loadLoaded = null;
  model.loadTotal = null;
  emit();
}

function ensureWorker() {
  if (modelWorker) return modelWorker;
  const worker = new Worker(chrome.runtime.getURL("engine/model-worker.js"), { type: "module" });
  modelWorker = worker;
  worker.onmessage = (event) => {
    if (modelWorker !== worker) return;
    const message = event.data || {};
    if (message.type === "tokens" || message.type === "result" || message.type === "error") {
      const job = jobs.get(message.jobId);
      if (!job) return;
      if (message.type === "tokens") { job.touch(); job.onTokens?.(message.count); return; }
      clearTimeout(job.timer);
      jobs.delete(message.jobId);
      if (message.type === "result") job.resolve(String(message.text || ""));
      else job.reject(Object.assign(new Error(message.message || "번역하지 못했습니다."), { code: message.code || "translate_failed" }));
    } else if (worker._load) {
      worker._load(message);
    }
  };
  worker.onerror = (event) => {
    if (modelWorker !== worker) return;
    model.runtime = "error";
    model.runtimeError = event.message || "번역 Worker 오류";
    if (worker._load) {
      const pendingLoad = worker._load;
      worker._load = null;
      pendingLoad({ type: "loadError", code: "load_failed", message: model.runtimeError });
    }
    terminateModel(model.runtimeError);
  };
  return worker;
}

/** 캐시가 완료된 경우에만 모델을 불러온다(네트워크 요청 없음). 진행 신호(파일별 읽은 바이트·세션 생성 단계)를 그대로 보여 준다. */
function loadModel() {
  if (model.runtime === "ready" && modelWorker) return Promise.resolve();
  if (loadPromise) return loadPromise;
  if (model.cache !== "complete") {
    // 다른 엔진 문서가 방금 내려받기를 끝냈을 수 있다: 거절하기 전에 저장소를 한 번 더 확인한다(네트워크 없음).
    return checkCache().then((cache) => {
      if (cache !== "complete") throw Object.assign(new Error("로컬 번역 모델을 아직 내려받지 않았습니다."), { code: "model_missing" });
      return loadModel();
    });
  }
  let worker;
  try {
    worker = ensureWorker();
  } catch (error) {
    // Worker 생성자 예외도 끝나는 Promise로 돌려준다(호출 쪽 .catch가 받도록, 멈춘 "불러오는 중" 없이).
    modelWorker = null;
    model.runtime = "error";
    model.runtimeError = `번역 Worker를 만들지 못했습니다: ${(error && error.message) || error}`;
    emit();
    return Promise.reject(Object.assign(new Error(model.runtimeError), { code: "load_failed" }));
  }
  model.runtime = "loading";
  model.runtimeError = "";
  emit();
  loadPromise = new Promise((resolve, reject) => {
    let timer = 0;
    const arm = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        worker._load = null;
        model.runtime = "error";
        model.runtimeError = "모델을 불러오는 중 진행 신호가 10분 동안 없어 중단했습니다.";
        terminateModel(model.runtimeError);
        reject(Object.assign(new Error(model.runtimeError), { code: "load_stalled" }));
      }, LOAD_STALL_MS);
    };
    arm();
    worker._load = (message) => {
      if (message.type === "loadProgress") {
        arm();
        model.loadFile = message.file || model.loadFile;
        model.loadLoaded = message.loaded;
        model.loadTotal = message.total;
        emit();
      } else if (message.type === "loaded") {
        clearTimeout(timer);
        worker._load = null;
        model.runtime = "ready";
        model.loadFile = "";
        emit();
        resolve();
      } else if (message.type === "terminated") {
        clearTimeout(timer);
        reject(Object.assign(new Error(message.message), { code: "engine_restarted" }));
      } else if (message.type === "loadError") {
        clearTimeout(timer);
        worker._load = null;
        model.runtime = "error";
        model.runtimeError = message.message || "모델을 불러오지 못했습니다.";
        terminateModel(model.runtimeError);
        model.runtime = "error";
        emit();
        reject(Object.assign(new Error(model.runtimeError), { code: message.code || "load_failed" }));
      }
    };
    worker.postMessage({ type: "load" });
  });
  loadPromise.catch(() => {});
  return loadPromise;
}

function runChunk(text, src, tgt, onTokens) {
  const worker = modelWorker;
  if (!worker || model.runtime !== "ready") {
    return Promise.reject(Object.assign(new Error("모델이 준비되지 않았습니다."), { code: "model_not_ready" }));
  }
  const jobId = `j${++jobSeq}`;
  const maxNewTokens = Math.max(32, Math.min(256, 16 + Math.ceil(text.length * 2.5)));
  return new Promise((resolve, reject) => {
    const job = { resolve, reject, onTokens, timer: 0 };
    job.touch = () => {
      clearTimeout(job.timer);
      job.timer = setTimeout(() => {
        // 토큰이 오래 나오지 않으면 WASM 계산이 멈췄거나 매우 느린 것이다: Worker를 다시 만들어 대기열을 풀어 준다.
        terminateModel("번역 조각 처리 중 2분 동안 진행이 없어 번역 Worker를 다시 시작했습니다.");
      }, STALL_MS);
    };
    job.touch();
    jobs.set(jobId, job);
    worker.postMessage({ type: "translate", jobId, text, src, tgt, maxNewTokens });
  });
}

// MARK: 문장 나누기·조각 번역

/** 긴 원문을 문장 경계(。．！？.!? 줄바꿈)에서 MAX_CHUNK 이하 조각으로 나눈다. 경계가 없으면 공백, 그것도 없으면 글자 수로 자른다. */
function splitChunks(text) {
  const pieces = String(text).match(/[^。．！？!?.\n]+[。．！？!?.\n]*|[。．！？!?.\n]+/gu) || [String(text)];
  const chunks = [];
  let current = "";
  const push = (value) => { if (value.trim()) chunks.push(value); };
  for (let piece of pieces) {
    while (piece.length > MAX_CHUNK) {
      let cut = piece.lastIndexOf(" ", MAX_CHUNK);
      if (cut < MAX_CHUNK / 2) cut = MAX_CHUNK;
      if (current) { push(current); current = ""; }
      push(piece.slice(0, cut));
      piece = piece.slice(cut);
    }
    if ((current + piece).length > MAX_CHUNK) { push(current); current = ""; }
    current += piece;
  }
  push(current);
  return chunks;
}

const resultCache = new Map();
function cacheKey(text, src, tgt) { return `${src}>${tgt}\u0001${text}`; }

/** 하나의 원문을 조각별로 번역해 합친다. isCancelled()가 참이면 다음 조각 전에 멈춘다(지금 조각은 끝까지 기다림).
 *  onChunk(doneChunks, totalChunks, tokens)는 실제 진행(조각 완료·토큰 생성)에서만 불린다. */
async function translateText(text, src, tgt, { isCancelled, onChunk } = {}) {
  const key = cacheKey(text, src, tgt);
  if (resultCache.has(key)) return resultCache.get(key);
  await loadModel();
  const chunks = splitChunks(text);
  const out = [];
  for (let i = 0; i < chunks.length; i += 1) {
    if (isCancelled && isCancelled()) throw Object.assign(new Error(""), { code: "cancelled" });
    const chunk = chunks[i];
    const lead = chunk.match(/^\s*/)[0], trail = chunk.match(/\s*$/)[0];
    const translated = await runChunk(chunk.trim(), src, tgt, (tokens) => onChunk && onChunk(i, chunks.length, tokens));
    out.push(lead + translated.trim() + trail);
    if (onChunk) onChunk(i + 1, chunks.length, 0);
  }
  const joined = out.join(""); // 각 조각이 원래 앞뒤 공백을 그대로 지니므로 그냥 잇는다
  if (resultCache.size >= RESULT_CACHE_LIMIT) resultCache.delete(resultCache.keys().next().value);
  resultCache.set(key, joined);
  return joined;
}

function clearResultCache() { resultCache.clear(); }

globalThis.BarobogiLocalModel = {
  MODEL, MODEL_TOTAL, snapshot, onChange, checkCache, deleteCache,
  beginPermissionRequest, isDownloadBusy, startDownload, cancelDownload, loadModel, terminateModel, translateText, splitChunks, clearResultCache,
  useSessionStore
};
