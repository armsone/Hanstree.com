"use strict";
// 바로보기 웹 번역 — 번역 라우터(숨은 엔진 문서 전용).
// 기본 엔진: 공통 로컬 모델(M2M100 418M, engine/local-model.js) — Chrome·Whale 모두 같은 경로, window.Translator와 무관.
// 선택 엔진: Chrome 내장 Translator API(기기 내 처리). 0.3.0부터는 화면에서 준비하지 않으며 엔진 문서도 nativeFirst: false로
//   부르므로 자동으로 준비·사용하지 않는다(코드만 남김, API 존재 여부만으로 준비됐다고 표시하지 않음).
//   공식 문서: https://developer.chrome.com/docs/ai/translator-api
// 원문 언어 자동 감지는 engine/langdetect.js(franc-min + 유니코드 문자 종류 + 페이지·OCR 힌트)로 한다.

const TARGET_LANGS = ["ko", "en", "ja", "zh", "zh-Hant"];
const LOCAL_LANGS = ["ko", "en", "ja", "zh"]; // M2M100이 실제로 지원하는 이 UI의 언어(번체 출력은 보장하지 않으므로 제외)
const SOURCE_LANGS = ["auto", "ko", "en", "ja", "zh"];

const MISSING_TEXT = {
  model: "번역 준비가 아직 안 됐어요. 툴바의 바로보기 아이콘을 눌러 '번역 준비하기'를 해 주세요.",
  "model-error": "번역 준비 파일을 열지 못했어요. 다른 프로그램을 닫고 다시 번역해 주세요.",
  "language-detection": "원문 언어를 판별하지 못한 문장은 번역하지 않았습니다(한자만 있는 짧은 문구 등 — 원문 언어를 직접 고르면 번역됩니다).",
  "zh-Hant": "중국어(번체)로는 번역할 수 없어요.",
  "unsupported-source": "이 확장이 다루지 않는 원문 언어입니다(한국어·영어·일본어·중국어만).",
  ocr: "그림 속 글자 읽기를 준비하지 못했어요. 다시 번역해 주세요.",
  "ocr-region": "일부 그림의 글자를 읽지 못했거나 2분을 넘겨 멈췄어요. 다시 번역하면 새로 준비합니다.",
  "ocr-vertical": "일부 이미지에서 세로쓰기 인식 단계가 실패하거나 멈춰, 가로 인식 결과(와 그때까지 읽은 세로 결과)만 표시했습니다. 세로 글이 빠졌을 수 있습니다.",
  partial: "일부 문장은 번역하지 못했습니다."
};

function warningFor(missing) {
  return [...new Set(missing)].map((code) => MISSING_TEXT[code] || code).join(" ").slice(0, 300);
}

// MARK: 선택 엔진 — Chrome 내장 Translator(인스턴스가 실제로 있을 때만 사용)

function hasTranslatorApi() { return typeof self !== "undefined" && "Translator" in self; }

const nativePairs = new Map(); // "src>tgt" → { state, progress, translator, message }

function nativeEntry(source, target) {
  const key = `${source}>${target}`;
  if (!nativePairs.has(key)) nativePairs.set(key, { state: "unchecked", progress: null, translator: null, message: "" });
  return nativePairs.get(key);
}

function nativeSnapshot(source, target) {
  const entry = nativeEntry(source, target);
  return { state: entry.translator ? "ready" : entry.state, progress: entry.progress, message: entry.message };
}

/** 사용자 클릭 안에서 부른다(모델 다운로드가 필요하면 Translator.create가 그 자리에서 시작). */
async function prepareNative(source, target, onProgress) {
  const entry = nativeEntry(source, target);
  if (!hasTranslatorApi()) { entry.state = "unsupported"; entry.message = "이 브라우저에는 내장 Translator API가 없습니다."; return nativeSnapshot(source, target); }
  if (entry.translator) return nativeSnapshot(source, target);
  try {
    const availability = await Translator.availability({ sourceLanguage: source, targetLanguage: target });
    if (availability === "unavailable") {
      entry.state = "unavailable";
      entry.message = "이 언어 조합은 내장 번역이 지원하지 않습니다.";
      return nativeSnapshot(source, target);
    }
    entry.state = "downloading";
    entry.progress = 0;
    entry.translator = await Translator.create({
      sourceLanguage: source, targetLanguage: target,
      monitor(m) {
        m.addEventListener("downloadprogress", (e) => {
          entry.progress = Number.isFinite(e.loaded) ? Math.max(0, Math.min(1, e.loaded)) : entry.progress;
          if (typeof onProgress === "function") onProgress(entry.progress);
        });
      }
    });
    entry.state = "ready";
    entry.progress = null;
    entry.message = "";
  } catch (error) {
    entry.translator = null;
    entry.state = "error";
    entry.message = error && error.message ? String(error.message) : "내장 번역을 준비하지 못했습니다.";
  }
  return nativeSnapshot(source, target);
}

/** 이미 내려받아진("available") 조합은 사용자 동작 없이도 인스턴스를 만들 수 있다. 그 밖에는 만들지 않는다. */
async function adoptNativeIfAvailable(source, target) {
  const entry = nativeEntry(source, target);
  if (entry.translator || !hasTranslatorApi()) return nativeSnapshot(source, target);
  try {
    const availability = await Translator.availability({ sourceLanguage: source, targetLanguage: target });
    entry.state = availability;
    if (availability === "available") {
      entry.translator = await Translator.create({ sourceLanguage: source, targetLanguage: target });
      entry.state = "ready";
    }
  } catch (error) {
    entry.state = "error";
    entry.message = error && error.message ? String(error.message) : "";
  }
  return nativeSnapshot(source, target);
}

// MARK: 일괄 번역

/** texts: string[], target: 번역 언어, source: "auto"|언어 코드.
 *  options.hint: 페이지 lang 속성·OCR 언어에서 온 원문 언어 힌트(없으면 null).
 *  options.hints: 항목별 힌트 배열(OCR 문단마다 문자 종류에서 나온 값). 있으면 그 항목은 hint 대신 이 값을 쓴다(null이면 힌트 없음).
 *  options.ocrHints: hints가 OCR 문자 종류에서 온 값인지(라틴 글자의 "en"은 영어 데이터로만 읽힌 결과라 더 강한 근거).
 *  options.nativeFirst: 내장 번역 우선 사용 여부. options.isCancelled(): 취소 확인. options.onProgress(done,total): 실제 진행.
 *  돌려주는 texts는 입력과 같은 길이이며 실패·미지원 항목은 null(빈 문자열로 꾸미지 않음). langs는 판별 결과|"unknown". */
async function translateBatch(texts, target, source, options = {}) {
  const { hint = null, hints = null, ocrHints = false, nativeFirst = false, isCancelled = () => false, onProgress = () => {} } = options;
  const hintAt = (i) => (Array.isArray(hints) && i < hints.length ? hints[i] : hint);
  const results = new Array(texts.length).fill(null);
  const langs = new Array(texts.length).fill(null);
  const missing = [];
  if (!TARGET_LANGS.includes(target)) return { texts: results, langs, missing: [], warning: "" };
  const src = source === "zh-Hant" ? "zh" : source;
  let done = 0;
  for (let i = 0; i < texts.length; i += 1) {
    if (isCancelled()) throw Object.assign(new Error(""), { code: "cancelled" });
    const text = texts[i];
    const lang = src === "auto" ? BarobogiLangDetect.detectSourceLanguage(text, hintAt(i), { ocr: ocrHints }) : src;
    langs[i] = lang;
    if (lang === "unknown") { missing.push("language-detection"); done += 1; onProgress(done, texts.length); continue; }
    if (!LOCAL_LANGS.includes(lang)) { missing.push("unsupported-source"); done += 1; onProgress(done, texts.length); continue; }
    if (lang === target) { results[i] = text; done += 1; onProgress(done, texts.length); continue; }
    const native = nativeFirst ? nativeEntry(lang, target).translator : null;
    try {
      if (native) {
        results[i] = await native.translate(text);
      } else if (LOCAL_LANGS.includes(target)) {
        results[i] = await BarobogiLocalModel.translateText(text, lang, target, {
          isCancelled, onChunk: (chunkDone, chunkTotal) => onProgress(done + chunkDone / Math.max(1, chunkTotal), texts.length)
        });
      } else {
        missing.push("zh-Hant");
      }
    } catch (error) {
      if (error && error.code === "cancelled") throw error;
      if (error && (error.code === "model_missing")) { missing.push("model"); break; }
      if (error && (error.code === "load_failed" || error.code === "load_stalled")) { missing.push("model-error"); break; }
      missing.push("partial");
      results[i] = null;
    }
    done += 1;
    onProgress(done, texts.length);
  }
  return { texts: results, langs, missing: [...new Set(missing)], warning: warningFor(missing) };
}

globalThis.BarobogiTranslate = {
  TARGET_LANGS, SOURCE_LANGS, LOCAL_LANGS, MISSING_TEXT, warningFor,
  hasTranslatorApi, prepareNative, adoptNativeIfAvailable, nativeSnapshot,
  translateBatch
};
