"use strict";
// 바로보기 웹 번역 — 번역 준비(모델 파일) 상태를 팝업에 보일 짧은 말로 바꾼다. 실제 상태 값만 쓴다:
// 진행률은 실제로 받은 바이트로만 계산하고, 100%는 모든 파일 확인 뒤 완료 표시가 저장된 경우에만 "준비됨"으로 보인다.
// 일반 화면에는 파일 이름·해시·내부 구성 이름을 보이지 않는다.
// 입력 m: 엔진 문서 statusSnapshot().model 모양(cache, cachedBytes, download, done, total, runtime, stalled, errorCode, ...).
// 내부 단계(권한 → 확인 → 연결 → 수신 → 확인·저장 → 완료 표시 → 메모리 불러오기)는 그대로 두고, 보이는 말만 단순하게 묶는다.

(() => {
  const BUSY = new Set(["permission", "starting", "checking", "connecting", "running", "verifying", "finalizing"]);
  const mb = (n) => Math.floor(Math.max(0, Number(n) || 0) / 1e6); // 10진 MB(1MB = 1,000,000바이트, "약 640MB"와 같은 단위)
  const pctOf = (done, total) => (total > 0 ? Math.max(0, Math.min(99, Math.floor((done / total) * 100))) : 0);

  /** kind: checking | needed | working | finishing | failed | ready
   *  action: "prepare"(처음) | "resume"(이어서) | "retry"(다시 시도) | null */
  function describe(m) {
    const out = { kind: "checking", title: "확인 중", detail: "", percent: null, bytes: "", action: null, actionLabel: "", canCancel: false };
    if (!m) return out;
    const total = Number(m.total) || 0;
    const totalMb = Math.round(total / 1e6);
    const bytesOf = (done) => `${mb(done)}MB / ${totalMb}MB`;
    const dl = m.download;

    if (BUSY.has(dl)) {
      out.kind = "working";
      out.canCancel = true;
      out.percent = pctOf(m.done, total);
      out.bytes = bytesOf(m.done);
      if (dl === "connecting") out.title = "연결 중";
      else if (dl === "running") out.title = `번역 준비 중 ${out.percent}%`;
      else if (dl === "finalizing") { out.title = "마무리 중"; out.canCancel = false; }
      else out.title = "파일 확인 중";
      out.detail = m.stalled && (dl === "connecting" || dl === "running")
        ? "인터넷 응답을 기다리는 중이에요. 연결을 확인해 주세요."
        : "팝업을 닫아도 계속 받아요.";
      return out;
    }
    if (m.cache === "checking" || m.cache === "unknown" || !m.cache) return out;
    if (m.cache === "error") {
      out.kind = "failed";
      out.title = "저장 공간을 확인하지 못했어요";
      out.detail = "브라우저를 다시 시작한 뒤 시도해 주세요.";
      out.action = "retry";
      out.actionLabel = "다시 시도";
      return out;
    }
    if (m.cache !== "complete") {
      const resume = m.cachedBytes > 0;
      out.action = resume ? "resume" : "prepare";
      out.actionLabel = resume ? "이어서 준비하기" : "번역 준비하기";
      if (resume) { out.percent = pctOf(m.cachedBytes, total); out.bytes = bytesOf(m.cachedBytes); }
      if (m.otherWindow) {
        const f = m.foreign || {};
        out.kind = "working";
        out.action = null;
        out.title = "번역 준비 중";
        if (Number.isFinite(f.done)) { out.percent = pctOf(f.done, total); out.bytes = bytesOf(f.done); out.title += ` ${out.percent}%`; }
        out.detail = "팝업을 닫아도 계속 받아요.";
      } else if (dl === "failed") {
        out.kind = "failed";
        out.action = "retry";
        out.actionLabel = "다시 시도";
        if (m.errorCode === "quota") {
          out.title = "저장 공간이 부족해요";
          out.detail = "C 드라이브 등에 1GB 이상 비운 뒤 다시 시도해 주세요.";
        } else if (m.errorCode === "locks_unsupported") {
          out.title = "이 브라우저 버전에서는 받을 수 없어요";
          out.detail = "브라우저를 최신 버전으로 업데이트해 주세요.";
          out.action = null;
        } else {
          out.title = m.errorCode === "stalled" ? "인터넷 응답이 없어 멈췄어요" : "파일을 받지 못했어요";
          out.detail = "인터넷 연결을 확인하고 다시 시도해 주세요. 받은 파일은 그대로 둡니다.";
        }
      } else if (dl === "cancelled") {
        out.kind = "needed";
        out.title = "준비를 취소했어요";
        out.detail = resume ? "받은 파일은 그대로 두고 나머지만 받아요." : "";
      } else if (m.interrupted || m.cache === "partial") {
        out.kind = "needed";
        out.title = "준비가 중간에 멈췄어요";
        out.detail = "받은 파일은 그대로 두고 나머지만 받아요.";
      } else {
        out.kind = "needed";
        out.title = `번역에 필요한 파일을 처음 한 번 받아요. 약 ${totalMb}MB이며 이 PC에 보관해요.`;
      }
      return out;
    }
    // 파일은 모두 받았지만 메모리에 불러오지 못했다: 준비됨으로 보이지 않고 다시 시도(받은 파일을 다시 불러옴)를 보인다.
    if (m.runtime === "error") {
      out.kind = "failed";
      out.title = "번역 준비를 마치지 못했어요";
      out.detail = "받은 파일은 그대로 있어요. '다시 시도'를 눌러 주세요.";
      out.action = "retry";
      out.actionLabel = "다시 시도";
      return out;
    }
    // 파일은 모두 받았다. 방금 받은 직후 메모리에 불러오는 동안만 "마무리 중"으로 두고, 그 밖에는 준비됨(번역할 때 불러옴).
    if (m.runtime === "loading" && dl === "done") {
      out.kind = "finishing";
      out.title = "마무리 중";
      out.percent = 99;
      out.bytes = bytesOf(total);
      out.detail = "팝업을 닫아도 계속 진행해요.";
      return out;
    }
    out.kind = "ready";
    out.title = "준비됨";
    out.percent = 100;
    return out;
  }

  globalThis.BarobogiModelStatus = { describe };
})();
