"use strict";
// 바로보기 웹 번역 — 숨은 엔진 문서(engine.html, offscreen 문서) 제어. Chrome·Whale 공통이며 화면을 그리지 않는다.
// 배경 서비스 워커와 "engine" 포트로 연결해 번역·OCR·상태·모델 준비 요청을 받는다. offscreen 문서는 runtime API만 쓸 수
// 있으므로 설정·탭·권한·저장소는 배경이 맡고, 이 문서는 chrome.runtime(포트·onMessage·getURL)만 쓴다.
// - 요청은 한 번에 하나씩(대기열 상한 있음) 처리해 메모리·CPU를 제한한다. 상태 확인·모델 준비/취소는 대기열을 거치지 않는다.
// - 대기 중·실행 중인 요청 ID를 5초마다(그리고 실제 진행이 있을 때) 배경에 알린다. 배경은 이 신호가 끊길 때만
//   시간 초과로 처리하므로, 느린 CPU에서 긴 번역이 고정 60초에 잘리지 않는다. 대신 엔진 쪽에서 조각별 정지 감시
//   (토큰 2분 무진행·OCR 2분)를 해서 실제로 멈춘 계산은 Worker를 다시 만들어 끝낸다.
const MAX_QUEUE = 32;
const ALIVE_INTERVAL = 5000;
const SESSION_READ_TIMEOUT = 5000;

// MARK: 배경 연결

let port = null;
let reconnectTimer = 0;
const queue = []; // { message, cancelled }
const queuedIds = new Map(); // id → entry
let running = null; // { message, cancelled, phase }
let lastAliveAt = 0;

/** 포트가 끊겨도 곧바로 다시 이어야 하는 일(내려받기·모델 불러오기·번역 처리)이 있는지. */
function hasWork() {
  return BarobogiLocalModel.isDownloadBusy() || BarobogiLocalModel.snapshot().runtime === "loading" || !!running || queue.length > 0;
}

function connectEnginePort() {
  if (port) return port;
  clearTimeout(reconnectTimer);
  reconnectTimer = 0;
  let next;
  try {
    next = chrome.runtime.connect({ name: "engine" });
  } catch {
    reconnectTimer = setTimeout(connectEnginePort, 2000);
    return null;
  }
  port = next;
  next.onMessage.addListener(onPortMessage);
  next.onDisconnect.addListener(() => {
    if (port !== next) return;
    port = null;
    // 끊긴 포트로 받은 요청은 배경이 이미 실패 처리했으므로 버린다.
    for (const entry of queue) entry.cancelled = true;
    queue.length = 0;
    queuedIds.clear();
    if (running) running.cancelled = true;
    failSessionReads();
    // 배경 서비스 워커가 쉬면 포트가 끊긴다. 내려받기처럼 진행 중인 일이 있을 때만 곧바로 다시 잇고(진행 표시 저장을 이어 가려고),
    // 아니면 배경이 필요할 때 깨울 때까지 기다린다(쉬는 배경을 계속 깨우지 않음).
    if (hasWork()) reconnectTimer = setTimeout(connectEnginePort, 1000);
  });
  return next;
}

// 배경이 다시 시작되어 포트를 잃었을 때 배경이 보내는 연결 요청(이 확장 안에서 온 것만).
chrome.runtime.onMessage.addListener((message, sender) => {
  if (sender.id !== chrome.runtime.id || !message || message.target !== "engine" || message.cmd !== "connect") return false;
  connectEnginePort();
  return false;
});

/** wake: 포트가 없으면 연결해서라도 보낸다(진행 표시 저장용). 결과 응답은 받은 포트가 끊겼으면 버린다. */
function post(message, wake = false) {
  const current = port || (wake ? connectEnginePort() : null);
  if (!current) return false;
  try { current.postMessage(message); return true; } catch { return false; }
}

function sendAlive(force = false) {
  const ids = [...queuedIds.keys()];
  if (running) ids.push(running.message.id);
  if (!ids.length) return;
  const now = Date.now();
  if (!force && now - lastAliveAt < 1000) return;
  lastAliveAt = now;
  post({ type: "alive", ids });
}
setInterval(() => sendAlive(true), ALIVE_INTERVAL);

// MARK: 모델 내려받기 진행 표시 저장(배경 중계, modelDownloadSession 키 하나만 — 배경이 모양을 다시 검사한다)

const sessionReads = new Map(); // id → finish(value)
let sessionSeq = 0;

function failSessionReads() {
  for (const finish of [...sessionReads.values()]) finish(null);
}

BarobogiLocalModel.useSessionStore({
  get: () => new Promise((resolve) => {
    sessionSeq = (sessionSeq + 1) % 1000000000;
    const id = `s${sessionSeq}`;
    let timer = 0;
    const finish = (value) => { clearTimeout(timer); sessionReads.delete(id); resolve(value); };
    timer = setTimeout(() => finish(null), SESSION_READ_TIMEOUT);
    sessionReads.set(id, finish);
    if (!post({ type: "session", op: "get", id }, true)) finish(null);
  }),
  set: (value) => { post({ type: "session", op: "set", value }, true); },
  remove: () => { post({ type: "session", op: "remove" }, true); return Promise.resolve(); }
});

// MARK: 요청 처리

function onPortMessage(message) {
  if (!message || typeof message !== "object") return;
  if (message.type === "session") {
    const finish = typeof message.id === "string" ? sessionReads.get(message.id) : null;
    if (finish) finish(message.value && typeof message.value === "object" ? message.value : null);
    return;
  }
  if (typeof message.id !== "string") return;
  if (message.type === "cancel") {
    const entry = queuedIds.get(message.id);
    if (entry) { entry.cancelled = true; queuedIds.delete(message.id); }
    if (running && running.message.id === message.id) {
      running.cancelled = true;
      // OCR 준비·인식은 Tesseract Worker 안에서 돌아 중간에 멈출 수 없다: 두 Worker(가로·세로)를 모두 끝내 대기열을 풀어 준다
      // (다음 요청 때 필요한 것만 자동 재준비).
      if (running.message.type === "ocr" && (running.phase === "ocr" || running.phase === "ocr-prepare")) BarobogiOcr.abort();
    }
    return;
  }
  if (message.type === "status") {
    post({ id: message.id, ok: true, result: statusSnapshot() });
    return;
  }
  if (message.type === "prepare") {
    prepareModel().then(
      (result) => post({ id: message.id, ok: true, result }),
      (error) => post({ id: message.id, ok: false, code: (error && error.code) || "error", message: (error && error.message) || "" }));
    return;
  }
  if (message.type === "cancelPrepare") {
    BarobogiLocalModel.cancelDownload();
    post({ id: message.id, ok: true, result: statusSnapshot() });
    return;
  }
  if (message.type !== "translate" && message.type !== "ocr") {
    post({ id: message.id, ok: false, code: "bad_request", message: "알 수 없는 요청입니다." });
    return;
  }
  if (queue.length >= MAX_QUEUE) {
    post({ id: message.id, ok: false, code: "busy", message: "번역 대기열이 가득 찼어요. 잠시 뒤 다시 시도해 주세요." });
    return;
  }
  const entry = { message, cancelled: false };
  queue.push(entry);
  queuedIds.set(message.id, entry);
  sendAlive(true);
  pump();
}

let pumping = false;
async function pump() {
  if (pumping) return;
  pumping = true;
  try {
    while (queue.length) {
      const entry = queue.shift();
      queuedIds.delete(entry.message.id);
      if (entry.cancelled) { post({ id: entry.message.id, ok: false, code: "cancelled", message: "" }); continue; }
      running = { ...entry, phase: "" };
      const current = running;
      try {
        const result = await handleRequest(current);
        if (current.cancelled) post({ id: current.message.id, ok: false, code: "cancelled", message: "" });
        else post({ id: current.message.id, ok: true, result });
      } catch (error) {
        post({ id: current.message.id, ok: false, code: (error && error.code) || "error", message: (error && error.message) || "" });
      } finally {
        running = null;
      }
    }
  } finally {
    pumping = false;
  }
}

function cancelledError() { return Object.assign(new Error(""), { code: "cancelled" }); }

async function handleRequest(job) {
  const { type, payload } = job.message;
  const isCancelled = () => job.cancelled;
  switch (type) {
    case "translate": {
      job.phase = "text";
      const hint = BarobogiLangDetect.normalizeHint(payload.hint);
      // 브라우저 내장 번역은 자동으로 준비·사용하지 않는다(공통 로컬 모델이 기본).
      return BarobogiTranslate.translateBatch(payload.texts, payload.target, payload.source, {
        hint, nativeFirst: false, isCancelled, onProgress: () => sendAlive()
      });
    }
    case "ocr":
      return handleOcrRequest(job, payload);
    default:
      throw Object.assign(new Error("알 수 없는 요청입니다."), { code: "bad_request" });
  }
}

// MARK: 모델 준비 — 팝업이 사용자 클릭 안에서 모델 주소 접근을 허용받고 배경이 그 권한을 다시 확인한 뒤에만 온다.

const cacheChecked = BarobogiLocalModel.checkCache().catch(() => "error");

async function prepareModel() {
  await cacheChecked;
  const snap = BarobogiLocalModel.snapshot();
  if (snap.cache !== "complete" && !BarobogiLocalModel.isDownloadBusy()) {
    const ticket = BarobogiLocalModel.beginPermissionRequest();
    if (ticket) {
      // 다 받으면 곧바로 메모리에 불러와 둔다(팝업은 이 단계를 "마무리 중"으로 보이고, 끝나면 번역을 이어 간다).
      BarobogiLocalModel.startDownload(ticket, { permissionGranted: true })
        .then((outcome) => { if (outcome === "done") return BarobogiLocalModel.loadModel(); return null; })
        .catch(() => {});
    }
  } else if (snap.cache === "complete" && snap.runtime === "error" && !BarobogiLocalModel.isDownloadBusy()) {
    // 파일은 다 있는데 불러오기가 실패했다: '다시 시도'는 받은 파일을 다시 불러온다(네트워크 없음).
    BarobogiLocalModel.loadModel().catch(() => {});
  }
  return statusSnapshot();
}

// MARK: OCR 요청 — 캡처 전체 이미지를 받아 영역별로 자르고 인식한 뒤, 같은 번역 라우터로 번역한다.

async function handleOcrRequest(job, { dataUrl, viewport, regions, target, source, ocrLang, hint }) {
  const isCancelled = () => job.cancelled;
  const emptyImages = () => regions.map((r) => ({ k: r.k, items: [], langs: {} }));
  // 번역 파일이 아직 없으면 그림 글자를 읽어도 번역할 수 없으므로 인식하지 않고 바로 알린다(헛계산 없음).
  await cacheChecked;
  const cache = BarobogiLocalModel.snapshot().cache;
  if (cache !== "complete" && cache !== "checking") {
    return { images: emptyImages(), missing: ["model"], warning: BarobogiTranslate.warningFor(["model"]) };
  }
  const profile = BarobogiOcr.OCR_PROFILES[ocrLang] ? ocrLang : "auto";
  const auto = BarobogiOcr.OCR_PROFILES[profile].auto === true;
  const pageHint = BarobogiLangDetect.normalizeHint(hint);
  const missing = [];
  job.phase = "ocr-prepare";
  let ready = false;
  try {
    ready = await BarobogiOcr.ensure(profile, () => sendAlive());
  } catch {
    if (isCancelled()) throw cancelledError();
  }
  if (isCancelled()) throw cancelledError();
  if (!ready) {
    return { images: emptyImages(), missing: ["ocr"], warning: BarobogiTranslate.warningFor(["ocr"]) };
  }
  const bitmap = await dataUrlToBitmap(dataUrl);
  const scaleX = bitmap.width / viewport.w;
  const scaleY = bitmap.height / viewport.h;
  const perRegion = [];
  job.phase = "ocr";
  try {
    for (let index = 0; index < regions.length; index += 1) {
      if (isCancelled()) throw cancelledError();
      const region = regions[index];
      sendAlive();
      const sx = Math.max(0, Math.round(region.x * scaleX));
      const sy = Math.max(0, Math.round(region.y * scaleY));
      const sw = Math.max(1, Math.min(bitmap.width - sx, Math.round(region.w * scaleX)));
      const sh = Math.max(1, Math.min(bitmap.height - sy, Math.round(region.h * scaleY)));
      const canvas = new OffscreenCanvas(sw, sh);
      canvas.getContext("2d").drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);
      let items = [];
      try {
        const recognized = await BarobogiOcr.recognizeRegion(canvas, { profile, isCancelled, onPhase: () => sendAlive() });
        items = recognized.items;
        // 세로 단계 실패 등 일부만 읽은 경우: 읽은 결과는 쓰고 경고를 페이지에 그대로 보인다.
        recognized.warnings.forEach((code) => missing.push(code));
      } catch (error) {
        if (isCancelled() || (error && error.code === "cancelled")) throw cancelledError();
        missing.push("ocr-region");
      }
      perRegion.push({ k: region.k, items });
    }
  } finally {
    bitmap.close?.();
  }
  if (isCancelled()) throw cancelledError();

  // 문단(문자 종류별로 나눈 조각)마다 원문 언어 힌트를 정한다. 자동 프로필: 그 조각의 문자 종류(scriptHint). 가나 없는 한자만 있는 문단("han")은
  // 같은 이미지에 가나 문단이 있거나 페이지 lang이 ja/zh일 때만 그 값을 쓰고, 근거가 없으면 힌트 없이 둔다(번역 단계에서
  // 긴 글만 franc-min으로 판별, 짧으면 "판별 불가"로 남김). 수동 프로필: 사용자가 고른 언어가 힌트다.
  const refs = [];
  const hints = [];
  for (const region of perRegion) {
    const regionHasKana = region.items.some((item) => item.sh === "ja");
    for (const item of region.items) {
      let itemHint;
      if (!auto) itemHint = BarobogiOcr.OCR_PROFILES[profile].hint;
      else if (item.sh === "han") itemHint = regionHasKana ? "ja" : (pageHint === "ja" || pageHint === "zh") ? pageHint : null;
      else itemHint = item.sh || null;
      item.lh = itemHint || undefined;
      delete item.sh;
      refs.push(item);
      hints.push(itemHint);
    }
  }
  job.phase = "translate";
  let warning = missing.length ? BarobogiTranslate.warningFor(missing) : "";
  if (refs.length) {
    const result = await BarobogiTranslate.translateBatch(refs.map((item) => item.o), target, source, {
      hints, nativeFirst: false, isCancelled,
      ocrHints: true, // 라틴 글자 힌트는 OCR의 영어(eng) 데이터에서 온 것: 짧은 글에서 franc-min이 뒤집지 않게
      onProgress: () => sendAlive()
    });
    result.missing.forEach((m) => missing.push(m));
    warning = BarobogiTranslate.warningFor(missing);
    refs.forEach((item, i) => {
      item.t = typeof result.texts[i] === "string" ? result.texts[i] : "";
      if (result.langs[i]) { item.lang = result.langs[i]; item.sl = result.langs[i]; }
    });
  }
  const images = perRegion.map((region) => {
    const langs = {};
    for (const item of region.items) {
      if (item.lang) langs[item.lang] = (langs[item.lang] || 0) + 1;
      delete item.lang;
    }
    return { k: region.k, items: region.items, langs };
  });
  return { images, missing: [...new Set(missing)], warning };
}

async function dataUrlToBitmap(dataUrl) {
  const blob = await (await fetch(dataUrl)).blob();
  return createImageBitmap(blob);
}

// MARK: 상태(팝업이 배경을 거쳐 읽는 실제 값만 — 번역 내용 없음)

function statusSnapshot() {
  return {
    model: modelView(BarobogiLocalModel.snapshot()),
    ocr: BarobogiOcr.snapshot(),
    busy: !!running,
    queued: queue.length
  };
}

function modelView(snap) {
  return {
    cache: snap.cache, cachedBytes: snap.cachedBytes, cachedFiles: snap.cachedFiles, runtime: snap.runtime, runtimeError: snap.runtimeError,
    download: snap.download, done: snap.downloadDone, total: snap.total, error: snap.downloadError, errorCode: snap.downloadErrorCode,
    file: snap.downloadFile, fileIndex: snap.downloadFileIndex, fileCount: snap.downloadFileCount || BarobogiLocalModel.MODEL.files.length,
    fileDone: snap.downloadFileDone, fileSize: snap.downloadFileSize, skipped: snap.downloadSkipped,
    stalled: snap.stalled, idleSeconds: snap.lastActivityAt ? Math.floor((Date.now() - snap.lastActivityAt) / 1000) : 0,
    interrupted: snap.interrupted, otherWindow: snap.otherWindow, foreign: snap.foreign, permissionGranted: snap.permissionGranted,
    loadFile: snap.loadFile, loadLoaded: snap.loadLoaded, loadTotal: snap.loadTotal
  };
}

connectEnginePort();
// 받은 모델이 브라우저 저장소 정리로 지워지지 않게 요청한다(웹 표준 API, 확장 API 아님).
try { Promise.resolve(navigator.storage?.persist?.()).catch(() => {}); } catch { /* 지원하지 않으면 무시 */ }
